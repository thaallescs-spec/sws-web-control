#!/bin/bash
# Remove o SWS Web Control (precisa estar na mesma pasta do instalador)
exec "$(dirname "$0")/Instalar SWS Web Control.command" --desinstalar
