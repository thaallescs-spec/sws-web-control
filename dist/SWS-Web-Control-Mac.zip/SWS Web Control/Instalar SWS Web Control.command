#!/bin/bash
# Instalador do SWS Web Control para macOS (setlist web para REAPER + SWS Region Playlist).
# Dois cliques neste arquivo. Para desinstalar: ./"Instalar SWS Web Control.command" --desinstalar
# Os arquivos do script vão embutidos no fim deste arquivo (depois de __PAYLOAD__).

set -u
NOME="SWS Web Control"
LUA="SWS Web Control.lua"
HTML="playlist.html"
BEGIN_TAG="-- >>> SWS Web Control (auto) >>>"
END_TAG="-- <<< SWS Web Control (auto) <<<"
PORTA_PADRAO=8080

azul()    { printf '\n\033[36m== %s ==\033[0m\n' "$1"; }
ok()      { printf '  \033[32m[OK]\033[0m %s\n' "$1"; }
aviso()   { printf '  \033[33m[!]\033[0m  %s\n' "$1"; }
erro()    { printf '  \033[31m[X]\033[0m  %s\n' "$1"; }
fim()     { echo; read -r -p "Aperte ENTER para fechar " _; exit "$1"; }

DESINSTALAR=0
[ "${1:-}" = "--desinstalar" ] && DESINSTALAR=1

echo
if [ $DESINSTALAR = 1 ]; then echo "  SWS Web Control - desinstalação"; else echo "  SWS Web Control - instalação"; fi

# ------------------------------------------------------------------
# 1. Pasta do REAPER
# ------------------------------------------------------------------
azul "Procurando o REAPER"
RES="${REAPER_RESOURCE:-$HOME/Library/Application Support/REAPER}"
if [ ! -f "$RES/reaper.ini" ]; then
    aviso "Não achei o REAPER em $RES (instalação portátil?)."
    RES=$(osascript -e 'POSIX path of (choose folder with prompt "Escolha a pasta de recursos do REAPER (a que contém o reaper.ini)")' 2>/dev/null) || { erro "Cancelado."; fim 1; }
    RES="${RES%/}"
fi
INI="$RES/reaper.ini"
[ -f "$INI" ] || { erro "Não existe reaper.ini em: $RES"; fim 1; }
ok "REAPER: $RES"

# ------------------------------------------------------------------
# 2. REAPER precisa estar fechado (ele regrava o reaper.ini ao sair)
# ------------------------------------------------------------------
reaper_aberto() { pgrep -x REAPER >/dev/null 2>&1 || pgrep -x REAPER64 >/dev/null 2>&1; }
if reaper_aberto; then
    aviso "O REAPER está aberto. Salve o seu projeto e feche o REAPER: a instalação continua sozinha."
    while reaper_aberto; do sleep 0.7; done
    sleep 1
    ok "REAPER fechado"
fi

DEST="$RES/Scripts/$NOME"
WWW="$RES/reaper_www_root"
STARTUP="$RES/Scripts/__startup.lua"

remover_bloco() {   # remove o bloco do SWS Web Control do __startup.lua
    [ -f "$STARTUP" ] || return 0
    awk -v b="$BEGIN_TAG" -v e="$END_TAG" '
        $0 == b {skip=1; next}
        skip && $0 == e {skip=0; next}
        !skip {print}' "$STARTUP" > "$STARTUP.tmp" && mv "$STARTUP.tmp" "$STARTUP"
}

# ------------------------------------------------------------------
# DESINSTALAR
# ------------------------------------------------------------------
if [ $DESINSTALAR = 1 ]; then
    azul "Removendo"
    remover_bloco && ok "Removido do __startup.lua"
    if [ -f "$WWW/$HTML" ] && [ -f "$DEST/$HTML" ] && cmp -s "$WWW/$HTML" "$DEST/$HTML"; then
        rm -f "$WWW/$HTML" && ok "Removido $HTML do reaper_www_root"
    fi
    [ -d "$DEST" ] && rm -rf "$DEST" && ok "Removida a pasta Scripts/$NOME"
    aviso "A interface web (Preferences > Control/OSC/web) foi mantida. Remova por lá se quiser."
    fim 0
fi

# ------------------------------------------------------------------
# 3. SWS instalado?
# ------------------------------------------------------------------
azul "Verificando a extensão SWS"
if ls "$RES/UserPlugins/"reaper_sws* >/dev/null 2>&1; then
    ok "SWS encontrado"
else
    aviso "SWS não encontrado. Instale em https://www.sws-extension.org (sem ele a setlist não funciona)."
fi

# ------------------------------------------------------------------
# 4. Copiar arquivos (extraídos do fim deste arquivo)
# ------------------------------------------------------------------
azul "Copiando arquivos"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
LINHA=$(awk '/^__PAYLOAD__$/ {print NR + 1; exit}' "$0")
tail -n +"$LINHA" "$0" | base64 --decode | tar -xzf - -C "$TMP" || { erro "Pacote corrompido."; fim 1; }
for f in "$LUA" "$HTML"; do
    [ -f "$TMP/$f" ] || { erro "Arquivo faltando no pacote: $f"; fim 1; }
done
mkdir -p "$DEST" "$WWW"
cp -f "$TMP"/* "$DEST"/
ok "Scripts/$NOME (script, página, QR code)"
if [ -f "$WWW/$HTML" ] && ! cmp -s "$WWW/$HTML" "$TMP/$HTML"; then
    BAK="$WWW/$HTML.antigo-$(date +%Y%m%d-%H%M%S)"
    cp "$WWW/$HTML" "$BAK"
    aviso "Já existia um $HTML no reaper_www_root; cópia de segurança: $(basename "$BAK")"
fi
cp -f "$TMP/$HTML" "$WWW/$HTML"
ok "reaper_www_root/$HTML"

# ------------------------------------------------------------------
# 5. Iniciar junto com o REAPER (__startup.lua)
# ------------------------------------------------------------------
azul "Configurando início automático"
mkdir -p "$RES/Scripts"
remover_bloco
LUA_PATH=$(printf '%s' "$DEST/$LUA" | sed 's/\\/\\\\/g; s/"/\\"/g')
[ -s "$STARTUP" ] && [ -n "$(tail -c1 "$STARTUP")" ] && echo >> "$STARTUP"
{
    echo "$BEGIN_TAG"
    echo "do local f = \"$LUA_PATH\""
    echo "  if reaper.file_exists(f) then SWS_WEB_CONTROL_STARTUP = true; dofile(f) end"
    echo "end"
    echo "$END_TAG"
} >> "$STARTUP"
ok "Scripts/__startup.lua"

# ------------------------------------------------------------------
# 6. Interface web do REAPER (reaper.ini)
# ------------------------------------------------------------------
azul "Configurando a interface web do REAPER"
PORTA=$(grep -E "^csurf_[0-9]+=HTTP" "$INI" | grep -F "'$HTML'" | head -1 | awk '{print $3}')
if [ -n "$PORTA" ]; then
    ok "Já configurada (porta $PORTA)"
else
    OUTRA=$(grep -E "^csurf_[0-9]+=HTTP" "$INI" | head -1 | awk '{print $3}')
    if [ -n "$OUTRA" ]; then
        PORTA=$OUTRA
        aviso "Já existe uma interface web na porta $PORTA com outra página inicial; não mexi nela."
        aviso "A setlist abre no endereço com /$HTML no final (veja abaixo)."
    else
        PORTA=$PORTA_PADRAO
        while lsof -nP -iTCP:"$PORTA" -sTCP:LISTEN >/dev/null 2>&1; do PORTA=$((PORTA + 1)); done
        cp "$INI" "$INI.antes-sws-web-control-$(date +%Y%m%d-%H%M%S)"
        LINHA_HTTP="HTTP 0 $PORTA '' '$HTML' 0 ''"
        if grep -qE "^csurf_cnt=[0-9]+" "$INI"; then
            awk -v l="$LINHA_HTTP" '
                /^csurf_cnt=[0-9]+/ && !feito { n = substr($0, 11) + 0; print "csurf_cnt=" n + 1; print "csurf_" n "=" l; feito = 1; next }
                {print}' "$INI" > "$INI.tmp"
        else
            awk -v l="$LINHA_HTTP" '
                {print}
                /^\[reaper\]/ && !feito { print "csurf_cnt=1"; print "csurf_0=" l; feito = 1 }' "$INI" > "$INI.tmp"
        fi
        if grep -q "'$HTML'" "$INI.tmp"; then
            mv "$INI.tmp" "$INI"
            ok "Interface web criada na porta $PORTA (cópia de segurança do reaper.ini feita)"
        else
            rm -f "$INI.tmp"
            erro "Não consegui configurar a interface web. Faça em Preferences > Control/OSC/web."
        fi
    fi
fi

# ------------------------------------------------------------------
# 7. Pronto
# ------------------------------------------------------------------
azul "Pronto!"
echo "  1. Abra o projeto do show (com a Region Playlist do SWS) e salve."
echo "  2. No celular/tablet, na mesma rede Wi-Fi, abra:"
ACHOU=0
for IF in en0 en1 en2 en3; do
    IP=$(ipconfig getifaddr "$IF" 2>/dev/null)
    if [ -n "$IP" ]; then printf '       \033[32mhttp://%s:%s/%s\033[0m\n' "$IP" "$PORTA" "$HTML"; ACHOU=1; fi
done
[ $ACHOU = 0 ] && echo "       http://IP-DESTE-MAC:$PORTA/$HTML"
echo "  3. Ou rode no REAPER a ação 'SWS Web Control - QR code' e aponte a câmera."
echo
echo "  Se o macOS perguntar se o REAPER pode aceitar conexões de rede, clique em Permitir."
open -a REAPER 2>/dev/null || open -a REAPER64 2>/dev/null || true
ok "Abrindo o REAPER..."
fim 0
exit 0
__PAYLOAD__
H4sIAPwQ+2oC/+y9bXMbSbYmNl+bv6Iaat0GWiCEKgB8AUX1pSR2i/fqbUiqe2YlDRsEiiRaIMBG
gS8aXk7cCEfY/rKx4QivHbFhO3bWEd7YjRh/uWE7PP529cl/Y36Jn+eczKysQgFktzTj3Z3WTJOs
qsyTmSdPnvfMrN2t3f3bF52Lx3GnF49/8Wf5V9d/s37X641m+jffh/UojH4RXPziL/DvNJl0xmj+
F3+d/6KV4HjSP47Xw+XV5kqjudxcqrWWl5YaYWvhFz//+y/+3863O8G38X7wcDScjEeDYDH45XbQ
HfXi2uC08xHX/1KzOWP9h43GUvMXYSsC1dXrzeUG1n+zGS39Iqj/Jdf/eDSazCt33ff/TP8tLgZ/
24uT7rh/MumPhsE0PRyPksm4M7Z0EZx0xp2gsz/uj4NOkMSTQT+ZBMNR0I0Hp4POeIEQO6eTo9E4
2D3qDAZxIq+Go/6wF18E5f6wOzh9/4feKDiJB/jR6Y4mcVDKNUzyK1VYc2N/HAenx53g+84wHnTQ
ieNg5HoDMDHgjuP3/34U9NIOlY8mk5P23btbL9ono/Gkc/dk0HnHL7WjyfGgUhPIJ2grxii67//d
cYxR9dwo7k46+4MYYIad4DhO0Po4Rmvf9he/6leCmOPvoBeD/vCtgHo46P9wGgdD10vF0mASj4fA
XYwxxcHWiyQoJzHqYQwnp5NODzia9M/icXDc6SdBT8fJliq1YDPpBgdx96hTW1gYjLqdQbCz+SIw
/9aJt7edw7jWHQ0P+oft5HS/HFaDsGLLPtzeerG792hrG2XLvXj/9LB2GE/6w4MRy5V2SpVaMjod
d+P2IeuWfvO3JbwuVSrt486ke4QX5doXlVd3X79+U6oE6GipVjKwX2x8ven6UcogtmT7+sMY33qj
g/4gLnt9qdVkFPhV+mEcDy2jwUwDiz/yH/H+gnPLee9jJscHnW4cnIOIyuO4cxKPa/1hv/ITAOsQ
Dk6HXVkTgMh2ypUFDtl8xPD6o9roJB7axoDePTS4J2OuAJnj/ZJW6R9ggUxQZ3IUDzG/k9PxMBj2
ByRdDyYqA+pBG/B65dIXHVP7oN0djJI423x/nEz0K6YGZBijNgG0D830vfrN6/Hr4Zs7mLzeaMHS
jdbmikBLrOZmu5ucjg/2bvfurD/e3X1xO7lze/FLPOGPMn5VTF/MaAQAB+Nemg8C8gArvUwiAT1W
g8n4NK5kRi617dDtPxkRhy+/MSiWciVsafvbQFI08OVPIx+uyJ5Z24KanwbmZNwfjfs9aNBtZRF3
BSL+3+0knaAcrka1cGmldlEJ7gdhvXbBX8t8t9gI5WkcJ5NRnu7GneHbcv/En/dONdgn5Z2kq5Sz
c7vmT5IpNBkNT4/343G5A2J0D/uOJDvB+nqArgWdYY8V8LC0kpmo0OHbFa9nCkTTBZYtvPuEZ/6+
tx40wkzNRn4qm3Yag06vcyK8MU6Cs/54ckreWP5250k1ePwOC23xm2rwjbwfPBhd4O+n551xXA0e
jbpv43EFRNHtHJN8gvd/HEC3tXj9Zmt79+XGE2DmMiidxejNeBhPyPXOkwF/HRH67cUz/q0ND/ZH
F/J0zCb4V08a4V+D0ehkH0yYf0Ma9g7l++nkdMjfnfOewBwMzkvBVX5m+4kZAOTLcawzwr/Iq+U3
+W2p0h6MzjFlFbfQ96rBmSz0kw4ov2xGlFnh5DWAoIvwLLvwuBRnLqXOIIl1DnKdlUeslAwDOkcv
0Fkyc8x66fXrkv91dMqlbPji5kXcfTEedeMkKbMaSaLUP1HBVZKh3k32+8O7/QPzrhq0oBiq1Cl5
YClmqhDx8bCqVBJTylxeVeU/U9RniOjHNQwR9Nbt7EN76AyORlyxjvrahHJEjeIYI+mejkCDwOno
PAlKG7YQJFktaJeCu8HTTjcoxcN6OzgYdA6TdXzI8kxKgAzHvZ2gK0SG//Y2BPM0Z00HaxEoI0T7
5QzI8qvb52/uVNoqsfmpMsVCPXlz4vePkOez9NLWi7NmKc/U+yc5UUJWdLuW+QHOlGk/Jq1l2skD
AXa+wOPEyJ9peIXjQncBifghtkkor/onb9wLj22G0fLtmsF//tPS6u1a1GrK9ymMOKDrgoTMN9Ln
q1uif94JwjfCaWRk/ROQbRccjavCcHUUKad8wMywdghcFtOHBXA1UwCKfgoNDmqJrgq7XMvgiO8y
hHdR06Z/tx68M3/6TMF+vue++hh1hTAOljA0gyL+eu+fJLIQ3QLsV4PYY1TsIpcdC77qEzExAeZY
ED5+gCz/O1G8f7K2Z3SiVNdLR0bSTHmged+74PvQPIJ2xn1g/nQ8mOKf+6f9Qa+c0QSlMaDpliBu
PTBSVaEALHTDNYsViySAxhfYYv3hYQ04RuFyyVg5t5P27QQ/sTgFw72LN1VppCrKeoY1v62SeADq
h3HthzE18DJAaxHXgdFbIUQWRDfRHZkYOxIzwm8hkFG22ayDYS/VFw4PLqhxo1vTVqQajKmZiJ6y
ekUqwWg7QEkxTDbG/Q4lZ7iS/Rb531qVKSx3Y1oAu/HFpDy5wLjfYUmgno7LB5S+VQiTc4yBBY7j
DnRgKGJjQkgrYlr56x2KAT9HtePORXmlGpT58hxDm5xXwP8jKFnvXJ3euHPuAHlCddBJJrAVu28B
rD41BtbKSNmu6RpMCxiC45SIuliMwiS6JJ9oWemHRX84xQRUMtSzYAWdGqnGKoUZuvXCwpPxj06T
eK/bOQn+BpofdTmVNGmXSah8JWQLFTbLHbkk1uXnbS0BHug++ovAWT0eMqY6sOBPXLleqwPl+LnK
n2ro2u8QziiA9zpP5/rrSMpMLbpMjy30kEAFfuQg859HU6WtjIEJVra9ufFiczsYvv9fac9Tbzkd
g4vXQJ9cEB4Yrxnz/+ImXozjg5hWcUzsmrVz9/nOw7ts8n6w0esF9wF+BeCjYhBcdPtj6ChQFlKT
+H5QosltTLJ601WnHDbYMUv/J+PnGfFAi56ujr4QV9a0+gDEfBN/T3JNHT1QyeYiq5bFUkbd0JVF
7fWWjjn3BQsopiRo5t4n/d/GjgX0h275Nw3dHeHvsFmv5KqB3w18zoFRyt8HsB/GZQF6F0o/Fos2
/AU6XckDmYwmHUIRYF/ki+cKjy5se9pGyqgIRXlVvgqZW1S/0cS4JUfba/SuqmDdr4Lp1bWZnXoq
CewnYA99fdx+ezfjm1nPOnOvLt68evcG01+f1tMKukuN64KzZLFXAfqIUo6DH98Vf/R/ekMoUkDz
z/7fN6R2CGPTH511cNGlYrTWlrgklyL52Zq5eh6qxA0KXJkweBJ4QFN3JBdOpu3mUobXAPXFzD/X
aE5N2WaLt3uB/nSSSJykWLdd0QcgOaoCvZLrw9JKpg++KuyEwOlJrzOxPjJjePbIIcoUqkYGG/n6
c9Qn/Vf7Of77c/w3jf+uLK/Ua816s7kUNn9eJ3998d+PGPW9afy3udwKbfw3rDeWUS5shFH95/jv
fxrxXxtRlbhaNjxaMWHOYDs+ZOUXJhRI8wiAZoWCEfBMWDyqNWp1eXMyHp31e/o5CDIRRX3lBwuz
bxafbD3cfLazWTvu6YdXiKUO3wRzExu0Z/twD2udpxLjDqgJSenZY9Kg9bBzFh+K/zcNGcPZrF65
SVuBHr//Y4JQRNChgw/6cXx8MpJATwdqUpXBum6/M64KDvlr/P6fLvrHnbv8zIASujOhahRINHnS
HytY6FA/ACD0p7FrQoPqCULJ9lWClk4Q7+3hr6ELi0vcW8G82N56urm1vRF8s/kvUs82xgBHdsWM
IAjCWrDNMDt7HXTe/3saeYxRn8W/Dcob4rWgMlgYvcf77dMhI9kStT/pdyxU/BtlZ1kJaWQ0t73z
8/M9LriAOmKScDrUgfT96XAyMikAaoDXLNCoFtzIgA6KjeRS1evdo/igczqYpF/b2e66RhsGP6W5
5FZixsDsZAMvwP9wd+v5M42rAyIAGng29P549+mTva+2nmwWRN61xIPNr7ee7e1ufM0S6OX9+/en
1kIZi3JU4Sdba/PZI6kTmFr37t2bVQufbK2dv996sbf19Onmo62N3U3jERdXE/9oB/BoGJreMDRd
Ck4w4mOSJLhCZ03DTm06Bg/6x3QYOJJOjkEAR/S3vzVrz/peHz7efPj3e1vPdje3v5F4HvwS6uFK
4sNTEHJiEi7AaPqMBoJu/w8wF4ugjd20stRuFdZO+kOTlYFo4NmoVJCGcYNEjO3NHb+0MU2+jifb
seZfvIClXs6lbbzY2H0c/NjEjenMD4LwIF6f2fHV9vOnezu7GwgrvpDw3rc7e99uPth7+PzZ7vbz
J+knnerKwswC4jO2PQIhMTqgWN56BJwCyVjEHcG2YazlkzFCK92jfk/8O4NRp7dznjwcHbNY8lMT
RDa2f/ly65vnOz+h9lQ4HibSV8ztOJmVCHLyE5I+etenfJi6vcLo7Pm4P4m1W9WgN69n53N7JgvR
9e2gLXDLvTn9kfDXB+RePAOxPNl4/9+8/6+eQ4D1KB4n9CC0g/FIMrmOTxjWT97/U3B82qN0oM8A
/YTCVvkI89kfQqgNBo/BPMvHyWHi405k0no65YUpTI4ZZ9AqVTO+EQJ/dYs/bViwtPHN1s7ztrpl
U57OtCh1KB+M+taZCjUj6CDVjL/xf1XVaqVchC7rWNcQ/TkjG+Q/XtZVTsCWfH/JNqLcYyoRD/Fi
Ej/q0282Gr8rozR8TD5+6DditAxNFODDosOhj8UrDEBOI4eRZ0fCLFeVQgWR1wI0/ukf/10hDkXb
YIYhtYrCIRdGoQta2NzexjxZJz8lRD84HHfOoJZJw+xxoWeqaK0aitsBAU9OT6aILtH305O2I3Oe
lPx3e3umuCgYfszodOxTrik1nUyxj1+MvKQKA8G+Hqb4wXPOjweUprzl9g+vmeriCZiKX7VkSYCk
xZy4vfgCykpSPjCJA7NlBznLms0ePJDUgVy/StOvrApjR+ENdRif+wOnI/10rDkNbvRpWoOl3v0s
CWrlPQa2vfqmVWRc+bUNhHiaiI0/v9MneykTDIV4THqrWIH+evylYFaEul8Z4zBtGy1jnw7rCoes
s4k/CHqaIKcDIIeD09h0gQuzVHKpEIRvNIXXw8/QB83YQZc8Gsp0h+0KPNuRrH+WjBFFBT5+/07r
zOYChmSrLH1zPrAl9lRAJRW9Zw4YhUnGVgjKmVVT+biswEC+MTeATeKCio9haWQiv5oL6lZxYYqp
v6Z/XBqoTespTv7005KEyB13zeX+FFD2h6WWetpFWSCxH+XSRi699/v3v6dFip9e4FVrdHQupDI5
QaVWqhTGhYwZCgTeCHoRGOU0L9J8+DS9oUodhtaesZlfzzYQX5c8YT4jOa/0FbUexFxoDY/awfMT
a3nfyOTNM8/XxSbwa/AcaN6vS1Pm72tYsMgNGiAdLgMpK3Zrr4evh4/ikxGsph8x/GuM43zny89G
9FEwDxD1kJbZxRigIp31E0ngw6TFF7T3+CChLuNbUB5QtcEnxpDj8XEfjpUaOMFPV2SfbG7tvoQj
5dFG8OLJxq+fbO3sBo+eq02DcdTGJydB0hmcjT6G0oqxJLH1SSVlaohxNp9FPlSNGsC8yKERCD6L
MPWuZxNTnLqIfSBX7z7++6woX87mxSWaGOfYKQBPldM+Dz0BVsibPS7ZqwbMw00Ksgc1MZq/yW2+
qBQsYKYL9maHjvs9P4u63ytmJAoE2c71i6bxbJvEyJ6kw4DUvS/5YLE39BrdDv0YiPIe0kTCsfoj
1zODdr2TFyIQQi9r8EYh6jx6FbVj1fDzWL238zdP97a/frZnSZ0Yri1WdPrzVCJACvGLdaNK5cjY
/+1gCjT4KVKhX4V0slgvLCT7WedNETgpTGkfJycdJomcYYWrJ6cUfE7P5nczqIj50lVJ251R4AcR
xcnEc+4UUMEPdIt8XvqckyB/lz4vpX9/V5pNaEZxp4ltWxK5+wPi3nm1MqMPasq4VqSodJ2Mquat
6IfoRPqlGBRHXwxKX4l+6iX4VtR1lF+rM9er7W7VtiTw000MO2atFi/UolVjBp+my89gJ5d+SeSN
d7njipqvdgRTE5aQcWDXmziqrq5N6MgJaGFtvpbX7XSPYs2Jnc6nh1I3Hh2r0wbePx2vqyFa3wYX
3yipSVZD6fbj9u2nbckNv7IqNWtK93OEJXBq8ZhjhwN29H2MNYaQCDQk51oQcQRbEr/ioPxwMh7c
2THBHAQcwGk63ua+m/gajDzxVdZ0ZMYxYsvM7u0z27+TUZK8/8NZDGmmwn2MlJwzYRUnOqKbdErl
zfpcmcmEFlNuPZ9GlO1bPDxi5GNGWGjoemaQexOkHWFlDf3NHYNcznQypbXXDP2KhFEA5NJr0Obi
ztsp8tQhSEe5urW86AGUyOEbr1B3dCoTeMuj5Z+kD23DpH7/r+HBwBAYfoLz6iw7eVCX4/Hko+hD
R/HFw9EAWW7dLK253Nj6Nf5XqOqHul/K2FgCjuvzGWVNXO4iG7V+8ZX8y/g/c76RW7fr0YX9D5q0
AVwptP0O6f8nISVl4iSTj5xm0meT/1z/ME+yrruTp50xdiP5MCT5nkENk5AnGW1TGwBBav1k+3DI
JHHoiuPD4eYQWoVySMnD6hIL3h4eqBnZNhvSKEpnPB4CdVrQTSQlfZoZi8nMFcpeQOT1kyO2abpj
+5DOMX/O2xVhPdMfso1g5/kz/mYaG4ITZ5LWeoxgWzxmftuiRJ0x7yUGZ2jAvNzeQpACBgx529CL
DWsUFQZbnx4Iwg2GmP8OI8HBPtgsd60iRMUgrebkQ0eBZcKtxUya5e6jqo2AEhTMMax+s29682IC
PyKMppjP+Q2wPT88+qFrDEMuJxnSL09GSv14r16rz1/dvo1dYLe7bz739qJ0K/mNJLlFc/s2Vsuv
sFq67f13zN9zGeKV4oUDOiwPK7Og1RoHgDXUzUaF+zA4DYZyUwFlXBd4+8xswhPhmrrF5NmpP69+
w9jZncpnqgMJHPXFlLlZbPL+D5PTwajiO1uPIBWndm98XjrRJVVql7h3o9TDZqB3JWzlqJZUB7Af
kvOErz+vepTfLdsOV6oelmW5biVmsT4iRGUPHI6m75eoUaozT6I+pWpO5BkFRLSq9BvEXM3sC5mC
UHGbDCYj4fmJ2Ctqhqd8v9zZhwdh23wpMd578v73hwi0VsT1MBojDETiB0Poi+vA59TKMLlZYDb3
FFGX3YpEdkYvR6By1YCR7UiFG7bsNgbWAjMKrm6w6Ypbbh1VdmrjmnK2e8G++zu3ZWr8fbabe8U7
ptKZ/f7VLdQx3cwR0mWp3wOB9Kol8lVHNWxXyQmN6x/CQvnnlUdMQlA1GTLpCgRQk32pVVlusR2C
96y8upIHMa4pz5Y1Q1MIDpv0LR7wTlfK8HQwKGW3g5g1Ir9YlItApqrUfvW5uraJfqhvXYx5jBWM
MYrz+/M3nztPc6q0ZaRQIcMA3kZvS20h4aqgaTwmdog+4Ee6oihxUFMG5QcY4Lk+hgQ77oPZDw+r
TmTbral1tzyemgzsQ3VySUYR1W5CgLD5PVQm+Pdk7VDwMGJCFq/JPOpM4zquWXgbZs0ghIA1N538
Uwne/wcsvxiOvjO4MduQRO//MOz1ISc60Kn5dSRp4SML0X6mj8ymPGGbGKwCsa5LNk8JjPY0YZAN
Mq+UTVTCCi7VZlF2qpJaH0fBCQWqesjsvyI/4l9vfEVDaQxwxBHyu/WiLQDWk05incSy6VCLY+9U
QcGh3TbR2U/KpmiloFxPzMqyXQTQsOz6wI6BnN5j6MBmsvdyTi+hm1e35Ffx0p4yakGzio6brXcZ
hRa1iNAP6EpnomDmsQWzrqVFXQoZ3pDlDClfCIbTYNxEFMsggYBeVaZrFrGVa5hKbndTgRPTLFYE
efQPi3+n2thhz9l5UMhVFrypInvhSIW7WCeWnS/7bOeHVABedzt5Uy2ZTtlHIaD8/OTZk6wpMzme
TZdWyDBQw7PIQ6vZL46N6TfOi24dqnyAXv3w+dONZ4+e7xjXOF+pj1ycEuR+hokIJ3xWqgW749Mf
mEU26NMdMdJMMKSq9/rGa6g6gBwDYzCJDBgU5RMCm/AHYls/2VP4z38UsDy5B/sojxmxk0KIFEwM
nykFz5jVqDmobquMlEb0J3jICFOJ5UUj7CALMtja3XwqKoz1BZSHNj/SMPCKJBWCzfF9QWYm9Qe0
3TmuBSZugmKjnsQxZLhnI8Z9Opr6gsDIx1Dnu8c979gJ60hPbT2qlD2Td/VkNHqLTIW0uDUAUIGr
Eb/Ieyv2wdssXOT28hK6TLSTSiXx5xLk2LvSHl3BdANn/MGltIpM3IwqzzZ/tTurHiTh2ax6L7Y3
v5nX3kPw/ZntPXy5vfdgY2fzUQ6CylTSuRzxxGgVDLVMf2bBlf7MgusgTA4HO6SUAggsufccuRm7
XyO74unz57uPdzY3/146ZYQ983pBbnSxZ5aXA8+3z0bnc8GnoPeef/WV1zdW3tE0zhtVfubVHb01
CYhKHqQvN/H2gdhT0pPEUxCfnmJiYXQ7w61jHVFsoVl8WRh2gP6z9rkIcmEcvz85cs0QdvlgmNH0
ebaPHP2Q9g5iaaqD6nW36aG7o8PDQWxWi1j6fvfFmgvzKq7UfQpf797zoalZ9sbocri0tO2VO8Yi
9aIIIISWz0CsL7e24wOUPiqH+XME1DV6gseBG/OsyothZcGLCnmnUMzrtc4EO+6fNESJDvrw6+8c
jc4RW05Gg/hpcjh1AoFJtUtlOzR5mylUyWdofH96fLIT/yBb9HNz3RkOIVK78d+hSFkOtNNRpVXs
X3bzu+1fPLEem7JJ84Z8ZWFoPrYOO9SWjgroqhJMsSOEq4JeStOLXDBMz9qzIhACte7jzqwv3zFq
sVtAzNbGrdyA0tirDJmJAaB7ebVPvdGc6lzdmcl2RnMR4j/QRY20041vXj7Z2UAoaDTu+JK80rZJ
AyJ3Ez2kj/oJMpar8kfghDwB9kYG2aPA5Bsko9/CgTdyme3w0dWC9/9m0jd7HSZkvaLWwKjilg9x
lCQg4w+Q8UiBGGDeehlauJSIsejpzslKnwZ2kXAzhaeuIInidIDdFhyfzd3eff5ib3Nj+8mvJVO+
3iREGcApz9g67Y7SznOc5ZHEpjWF93eN+sXdpOCsjkHcGW+ZvqaHWrjeZ1PD7NtsZoAhokcxNtzE
BUvLViu5VTQvF4sTr+qki/OnhqjnbqpX4Ml+46+lceEyKibxsM6t3PVKYSoS1YQJMFdmMg+dw5PO
8f77/3AceAqm3QeRYyy9PpWTF6PE2mNmzJmhz+pSfXlel0RNTu36EYOqcIAt5Gbm0mY7pD79tCvO
r28t5qvrOaM3fY5pY2bmssRz+menyUqOd/JJKz9ZKFNOBS9HrL2p8BwST9Lm6XbqiB6bApdkNnoQ
IOam7zFROUIxYdKI7VjqTPBW3A3EuyWp1INbsLaMIcwm76Ut6kQtyv4XOW+RGWT5/tyRz9mwaLaF
4Jp/jIEMDk9JyUjjR4ijk3p3TTqlxi6QxiZK8tyFmrztn5ThJ6/cUJ7deG7Tetpn8rjeyOV7qiBV
Bi1HwnH/XTwuZF1ZWHPwkmW77YItgNL6WWcQH2eMNdssEOFOv9AV6BsrqO9UZpJAWsKaHaaEWEUe
xnL7ujKzP09BmEGj5Aoq0wuOY5lXJUsJP3GXyft/+XDr+U8TqXmD1R72xaxgcd5P09/C/A0fmIp4
mHBSnevDbfOAfrAlGwQkNxEhn0UtDdTWRuNDTVGc3rRSuKmAQ//lKbUVs+mgY89bdo/Czc2+z2pg
N5aYEKXkmZ5KDYIqPQEu4G/p6E6EknqoZc+s3Q0KlwlFlIQuzYY71RPokTlhiixPsAoG738vmye/
4TDlu5xAYhq3p0vbvNFeetAzFTFmdMkO0Boxn9ms5hlPSHndjo9HZ7Hrbzoz5hTV7kgzfTwq5HCw
ontBftdctaDQnhxvXHyu8fydoAotDfsAKWcx3XXHoi26KJV0MZ/9UbCZwlSs5KzHaYkqDQnDs20V
pXXORGFZvJhMKzDVbR54sev9OvmeHXZRjtuspCt7SuzfMUtbwyMkwe77f8KWH1E7QdFfBpvqc+Pm
sZPYHKwtG7H7vzW0BaLr9GtmSeP9WbzrJ1TOw2VJiu9NuD+DB99qZfFOm2o8UmMPbLXb5645nn8n
ZbB7FmfmOmzN1YDgL+EekLHaz1k11vCdzAoo2KyC0+fo9lBOdN9Ef8tZXy8+VY0ZrPaw/Knnzy7k
s92fB4wj9WnmpFnyBudYAeakAItnZs3n+TztdMTAEuyYxeG9elRffsmUMrzfS6GSuS8auxxK50Y5
hd9sm65LpS3LCz+VYU/FGAuRw7+mt26kXKJ4NB+QXv78+YsAjuadza9fwoHOHPNnz3+6ichD9/4+
hpHOPyQ9QP8U8tM/JQXGO6/wKO6+1S8PsC8QkW781BSjuoQ2GYbMLC09MtcccOAy79vM2Bdub9P5
uK1Tdk30+thdEJTBbV5gN3VVk12snKqIdLJ0Z/ITA0qdsUjS4eiMRzdYs6lDgxQhA7u0k3hwsCMb
pgs2dOqutXSsOygs4y1y/oxjqgRbBy/lrCk40Ufn3nLkCWtZEPdwyvXsLbb55gDB3ws47s7srscB
WAxrVUqv+0Od3W4GH6i4cBNr2jI8y4VUf+3F/YupmYDmcHrcH1sn7JwtfjP1YtKP3qMgmziwkYtr
93iO91H3ChZsRgSecpaBPQR7vsWiY5licnm2MtflCFQdSfDGy6n1UTXXKTl1Nndww3886BM96A9P
9a6MtE3hy8Xuj9N9cO6jGYlR3yey72B2/hSQLGWgC1j+UWi7Fgs6FxatCpSMoLMLRUCuy/e55iF9
T5l9dFyXzhjPSuWF6bVL/karPHtGRFay2mLpipXzTfWV/PLPPZ078nRVORogT5nCwFwgbNKHwOfK
lNPLnQFrT1046+vhCy4Di4FWvmEKON52+92B20CdIL0Rx8MF4/e/P+n3RrkTaueqSlRjMgfHgzub
mEA+ItI1GXdFpDOTM6malCcZpQq4xxl4ctsMSGl82ZYdDP5+FePsQ+7qVAUND09XQYelgWLPkHPP
O4WShStTyQljky7reyBTHfRwOF1DOH26aGa0bwJMuSjJHI/91J4g15QGvQWMeF/CWV2CF8Evtzir
oFVptWyWIHTrt1M7RAzPTL/IO/ymF7QCwYrOnRkztaR9KZy/LcVxu8J86CQzUFNMfmV3pSiwt/E7
MTDdctXcTHL9f9Cdq6iZqyNpoWnbRcmd+bNqJxrx9DxfWkVWz8OjzvAwljxyU9u/DmE7Hrz/j4HZ
t/iD+BDackgn/AHMzNRUzrvI5ORmGh6iJdkK2PTAba/i32MGMqyu/mktv8DisSb5lYkHIy6gjYrB
4RHCQm6Pbtkpq+m51D37WPf6LyastCG0Nb3VJiUeN1yTplrmBrJq6ptk/jnksUjO7EYGwyGpvQ5N
hondlVLQEapnMh1muJq1TfeLDMC81cFN2dGzBHNmGVganqnWA+Fv+a2n76U7U1v0i7TbebENPV2V
AtdYN+Y9Kl/gCPJc2PDHKpg3qmRE33SN6xSNfIqWRktc+ucOjY3bDxu3N5ZHxhHMSTYZ9ZIamoYh
xC0oWsfP57/+fP7rf+7nvy6tLtWWVvE7jH4+//Wv4F/mDMFf/PnW/+zzX5daS61ld/5r1Aqx/qMG
rgH9+fzXv8C/e58+ev5w99cvNuXUrfsL9+SErgEUxPXSyWTxwXaJ7yAc8Os4nkhGLHbTTtZx09nB
4krJvmaG6DrOSYzPefRKyW72XS+d93uTo/VefIY9BYvyUGUWOC5yWUygEoLxVHHrx1ge6HtdH45y
QDsnJ4N48Xi0DyVuEarlIl4s4pYQlvYaeocNRdmKN60y6U8G8X3jvb53Vx8X7pmYFFxkAAXDqfY9
St+7q6/5ffKO5dqkDEaSFhf3D9u36nH9IAzX8HRCD1b7VrgcroZdvpCzFG5FnajXiPgMRWnSvnUQ
8X987vWP27dWO516Z2lN4HW6zBZFlV6re3DAIocjADzoLDd7fEIa3Un7VrfeWI32+YxL6obtW/FS
Z7leX1u4WvjiEqnOsO3b9bWTTo+7FvEXrrRbxLUTfNjn3pHxIt5cLXDeq/uj3jsO5SjuHx5N2kgO
ub3GO+4OxzAWem1o+GWOsrImuffmmcOorCFYNMZ9E+dtHODYi4ccAG/aWTxAiGfwrp28g+P3ePG0
X13U+dQXVehah6M4eLlVqm6P9keTUVUu+akmnWGymPD8TkEF5vBtf7KolAJ1sDtpD7Hjcm3qhS05
6ZwsHmEQAw5kUbuLcOUw4YkxwwmxcwsduYTnmSywfTCIL9b4A7PAY+9o8qPW6fFwzUMGNvPf/QK6
H92eNHqgYJ4mTDXnkTOwE+6mfuq79E8iLvfF3YVbWs61JR21ExLWTy5ww8MJWie6zrUxTqA884KQ
dtjCZ6J5EWryITomFy1cWcA1JiU46HIAV/oNvbicmkISTiUtQ7qZLsS3dqZvgVHr4NPb8trZE445
0iPRIqdByVKopGNuYsyRG7gjwwmO7mqHeA2THrkKWldusbtaqIE7xINLDykRqsIwmJACcAgrAdfC
ZnycIU6sqYqiTmafWzTapyfc0dRJYmAA6UykBw9uF+fTnpQjdKzaOjuvNtHXSmZuVjA37NSiJYxa
2FozC40DqwecU5Lt+RF2HUjnYkz6+bhzMrVMpGvuJa4Ywf0X/QQdwwbhS9PACnGUotRyEIM2WCf9
04Qt54ErFNi+g0t/QQsTJiPIz5KyG+J67NGTrIzvISb7B+8W7blBMqbF/XhyjjNb14QqF2VDSXsf
eCV21g47JzpHippF8ipBjKwyIqPNH+jkOCZ7nZqCBgpXlzAFrahoCuQZHe/DbbAIdwx4RbeN8B0P
jeJz4iAH2MkxyJBOM7fccDzPNNWYfg/ig0kb1AC0JDil9NJbh2NWnq6YW7jXdjRHTS3TUrB/OcVm
MSa64/yxrKKJWX13OP8QSpT8ocK+CD/QaAccKFj/2Pvu6OYQd6Ku8cciTz6ni25RGWrSDg/GQYT/
zG8lFXbTMYgoR/JhL6pHzZtxCnQCsQqUAE+T8spws8tFmjO87QCyNUVoVC/gxa5jIIRgRVe3379G
pxE3m2uaHIkbxyWjbe3EZP3heN+BHCYxjXRk0B4tdlTewCfb5/HYfPCH0dYzPy4R4gLU9r6Q3ZDX
qYa4pxIj1mKGzDNywKfFsIDoR2Sck3ft2krLp5mI5G6hgnlfTo0ENHo4mmb0hyN0B1QhaXImX7qN
JKyth1sb27zNl6fKdFH+/e+R34ZDvpGfQZEZ20iDybST5KT+8P0fsD1KZej+ZMjsPfFXYyYuMwyx
C/zbFXyrexCv9pZUzzmC6+a8jVgyrsqqy/8wtMCoUK2Wj+Wg1u+OvIVFCZBdmWs5EXsAxQ9BkVy9
cDlfj+sZWJ0phmtHowG2PB+QUTtEYxMqVsskXpPOZ9n1+HC/U45arar9r9ZoQco5ASeK9a+QrJy+
W8QF1RRQ5GamRfnBjY/a8lT10FTX/rjPZrGxcnWpXj9GlhJH24E+8reSFhiUcc+ZqvrtpSZWU4Uq
JVnDbG6A/5gTJbOMMMKlrtvGlbx5Ro6nb5pXC8p2NNeMhCE7KC8pVLwZmqPOIePIzgxUmltgxElW
1pEbLXnMaIV6yhRDaoZLYeeGqgvasB2czZFWfP5H3cjphDlR4rElr0e+cjslDrJ8SXtUGw0vC7SK
lCdeKW6rt8b8ZQfgo8+xs8V3bZ676rRv9x7G0giSBEMSTmdAvlLu98aAto8ZBZlaCGJjNQjIS7ap
9NToHq1l5TgX1wibb5GBexMV1hUWyFXvkV6wS7+oaMfxE6qdAt3HqgLOTQerHMXx5BnYQl7bmCWh
DeVw8rOjT0EVqvfS8Szd+lqYWggqWJs+YbWM5j2TcsEboyhast+t9mO+elSGPmTnJsLcFOtCc5Wf
vD5FuDDfLb15DDmcVnFnaC0F+g4tCO6F9yemUTQxZoV6GDHCfVrfdljV1cp1lRJRsUK4chOF0JJp
D5Rw6UR0074WDTDDjA6iZtS1n422MEe994r5y8C+4SByrxR1nr5kkJG+WQHJgrNP3l1arJD1K61N
ma5r16DI0vcU35JOneDK2Lh3idt7xKPSyHFd6CBr5tvi6OCA0nOxQZieRoWFQ19QL8Vuo+X02YM+
9vFrJtvUwRY8NKOkRj3XZyqvD/oXcW9Nlkt9bWz4o1ld9az5Vo8a0YrFoFG3pkawwFiyp3TKDwjm
bln+uoNw3Fk56RzEi1iNnUXREsxqrvi6gPxFefvrchjWb8+Q6bVwBdeewHRbBObWfrsoO+zaLcuG
5BIJT0PwWdQu3WXXsrtZJvi0BR8fO+YnbCBd/3mrjVZgxu5e+kBLR1r9ls6QOcNR1n8z9k1YM9g3
Pz+YDJMfYS+ldpKnqpvVYsF9iOUjpuRMy2fFWD4fZNR4HeXmZ5zxfDltRulCZMbdCY6nwVpTRfun
eiR8WVjP63XNKVsu47HyFmmhcrd2jTRJjQSJvRfpEFRSkyPkgrxt16c1ClP9Ft3aRiSmL08GskSm
nbEzwZwMsBPt8gYCaFqVb66IKh/YASF1O6uw2S+GAvPqM09V1WGkKkP9Q+Q5iWSd/4LdzScbOFgE
53BvPMIfmuE+uWtOEMdm3t5phxcODU6HHR6N7VwW7/8t0ju5k6vHDGK1KfCONkMffyp0EKDFBowo
EJPQcnvATUGIKcS696KcjgoYN0ZPxsU8Z4GjLu+GbojLqxndrtAgypXlae2iZQemdL2KQhW58GBN
78HNlKdYSNol46PWX6WgRAkVaOZYiRMms1YS48u4qQUMa7f1hXxjNe8LH3+ssTVlLVi+pFZyse2k
p9xg8d/cwMtzBrP+swqvcukbmKUz6ll/hLFLQ7VUuYHXvImubmTNBua8VR+3eM5ZqYFZW14pvtBZ
Ez1EFA/BqtU9lBZ5U3lriWTVWrldyWj1RVpHTlREIlbxP2lppq98hY7aWuvsqLok3vLsaoUyNXDz
Zi1EeGectSiamoBqR2tegUVdbm05IxOqj3RilrMYDVfDEF3A/fbsQ84Dg5o5x6nWo7em2kA1unsq
OrOp553ygu/EIV5Mbb6kUV7OjXjWiSCV825jWTxTHeEAolqTXalLV8SRZi+X7JEh0ZfGPfeIuAyQ
ksVTQ7GjVk+W4R3ecjroTdkVGLsZZSuy/MqstbyElFFMxV9C/VBAFlHq9m9HVjMrnr2Gj2FPrcng
Lidks+5yKu7Tsyvukml4stxz/h3j0jWf8+JrddoTs5QvPB1gsKMSKyYb6qPGYXUR6bl4oGyZVtoZ
cRt5nczpGlJkmFWRSc1atZ9939L3hos4C439qfuf8qNf8kpYiyczmsj/llPYqU8qFvLaqe/nL8Ru
hvaxG4SK4EkMST2cSeDMOxh3+pNp+k7lcY6+Xew1HYcl5gz1rsykXrM4lPqy5LY2PS2W+layWugM
yrPIKSCkyPS7kAZWFYHZCZ0ZP1QTYdqyNyLAXyir1hGas46KlDPkSWh6xL27JnuEuQX41eufYR+6
ZHUg9wL9d2+MioIUC7zJfiLHRGm80Rm8L/qOfAb3TBKUIHcqOTjqtivdfyHJmwaiq8NSZqJL9//0
j/990XdIAXTFe2Ic1XYuX8F0AjysdN/klrqqSjSl+4uL7cXFe8Ip7ttbgIElefbgZSGS/TmQuLTX
JicH9/YFOIwxQr53d//+vf1xWvArHjljTivA8jGl+fhEUKmdQS3bpjegAmTIFoD79jZXXNWxr2jb
T3uu88yp4QPI2YAwHFKQqOoQkMiYkh0ioieYhH/1vwMXeHvfYMiegJBiSAEVQ4VmUbLwDkcBYxNm
8szLA3/ypJ0//Q//p41LaZOKT0Dihs7S/ckI3CZtXfs2rxPPBEdFQ/tDdmj2lIcbDY0apRsa40U3
G9y/+r+DFxvbdmj3eVnZeN5o7t01M1a0+OSIyhxFUGiltO71GR+QSeW6LMeag/pddpU/1qmaODze
r1m6vz19iHQOXQXUKtZNunbFK1m6v3F42hnLJj63I/VP//i/Fa9nWbdqJKld6tP5FIJEvOURlPrG
Svd386fjFrXnJOhMluRcSlyKeqC2bPBjVNgeuSBHSshmjKSNFvVw4BMeoCBf9juUCbotUA8TsreA
yClOtdkdgzBRdjr3UCzGc+WucHeCsQZ2M6dgyTUfx/FFzEMjXALqDJ7qdIdCapOvD8WR5AhH/Uql
+/q6M55Hc1L/69GPZR66yj0ARtyQqew+f4hQ96MN3DucXffXLkKPmj0qUzmemxP6UdAlIwQGHtns
e50Tb08pbWp6bvXEeTtQ82RI/k//5t+m5JSRoVkWte22c5Ha13G8Oy9tcdfH+Oe/C6RCJvlf/z8O
Wd63CVmq21w+LmRcFj8LFmf3bIbm3bvB7qkcpkp/T2BOgcDGFBWhSph6vA+s4L5ZFwnN4f7735/F
sKoOB6N9uQRcrCymgPpXK5RxtMP6fRwjYj1R2Gf2/NlXW1/bJ6iqvCpy4m52n7rXfc3b7IP+yknc
epWVO1zb5KE+Oe0YYI+fP3m095R3aiP+vjZrHzCg0acxkmvNx8L3ZMQiF5Ce6DboG6gb0kO5qXvO
7mJA1Qu89c4u3I5I9Mh5SJ0BPWl24749vV+s/mDWia7ciUPlIlNi+gBXFuP2wkyx6fNaWUxyYnGn
E87FKi1crS14c7OJ7ec4QCGdGzgJEdGhoy/g0dFVPY8bT6/e4PD/zrm75Md+1xulFsM1qXpiT5PS
wxD03C/9Y2cilwYtLpa0KLdi7UrsFFbKhjk9wd9KLODtCy1gGsEWIyZpaJm1zExc6jUF2MeHUwWv
2np0Mpkz9+V1jke6e57HFSufHvN8Erh8wO4LTop3HeUZi65PGmzzRp1ew0As2YOvtnquxnknwZ5M
u7kX283IIp9SBAEjYAolvezEPKwZ8hO3Saz3Xj0CxBosCWxkNV8/06v0sNh6o+4pb3blXaibOBcL
fz54t8UToyqZyX65u/XEm2q3Q/zgeIJLS2gM9g/Kn/aTr+RMcrwK/uEfAjkaHnv+FP2B/PGUR8LD
bYn7ZxIJy2mPjnKfsKIaWI7YeX2c/3JbvqDAEj8nBMqXS/UUmuCbw9sx28ArNVhdcqYT73Ir1UvS
tNmJdxR8GfBoNh4WeifAmU8V7yHBUNoFL5ny7LCAq2uIBcTz38mFY3rB/NR9NhwxzorsynbouOJK
Jnx7RQabv3gmpo+pE7zGMSGvsWUweP0aLIwsFfalXslpN+alnTlFLlu3fJaCN0g4q+AEdiyyblzG
hSvlWuUuziQvH2MZCtvlZmIQEXS0L3FkAn617auhvhrKK47AJwx3u2ABcYyGdsmXsfwtleBPgetx
BHvXh0xKhlHgac0Ql4DwGcyax2B4eCD31KfHCK7JsVA6I6YSjz2oyfVl0h8tkc6GKXWJIy7MFkZJ
Oh+3IYPBaaiH4YYhuVSi48mtUnClkGxvCIdbxb/Uv+R17biDg1YnRHT5EhuT8VYviGoL8fTNSfPB
VYXkhvEsBB5rKAsg+4yV9epNRSCOU4BjH944BSerwjHaIMUTsQNuVBZSXvCOZdHvl241man4rKym
gNQUHZNO2IfuqrpSyc6UjngQDw+xwVZPBVNI5GqO43Thd8c+VGU6uAy9f6agg6BXk6P1jKlh32Vb
k8n6m78JPvWwjYHLk8wa8SiPJF5HUWed3/ZxjhK+lYotGNsHGSC8KsDGwyOc1FHuyQc3z7yeYBOH
sJXLCW/tUsUlHelYDsq4wVhRsCbqmbkrqUTXVCn9ppjgyz3ynv6a2WBcTmrm/i6WEu9QTX1NdEk8
NHd9mUJrC17Xhtd2LBhmu4QYZokvszPQ58kcaz7g4xtAPs6Bpqotr7PAEyHgFA06E2UcZzI8rng4
cLdgUNyY+0ju4yhKexadoeDrOzbI9ksv+lgzUAZTvXPtgrj+9N/+L0JQ7/9HzpDpha2adl7JaGB6
f+UhbnJ99ybZ7tEhXeLbbL9EGtfsXSSVPPq0BxP/fa+3yYPFn/DktyGWfQnXOXffQqcoeyQt2pG5
1yYQT46oRQcxbkA8DagII4QwUOVfjGMMQW/w7rhNLcbI7fBwqWMYARf2KD5MY6qg4JwJtUF5Syq1
l3tBs1X3xYMcYYDB7LBYuW+xOWvVYpC6biuyBpS52eOH9R3GZpIj2moq+HdQ3JHrKTgVvG7LnsQ2
cocXQEM8lR3+cCEcQiTLFTc6q7J1TtimmJfSDTwY87Iyg58VsDN3jDaJDFZpKVV0AGLcUQGovDcH
xqwDKVY7OcXRBz5vpkaTqq7//H8FpF/SkNQ2l5S4xSYv7e0utgnzbJm931LBd2nQ+DLKdLBUMsge
ppc0HXvHQJRSzqu9yDRT4jk7SDNIpPdGUPLCNalF1NfEkuaFRVLre6S/lUsyXDsnaqlXamqqo+Sn
WUTKdymcnexi2enIKxWhCL8qKYxTEYp3MyWoEfUfJEMzDENE6TZYRka2bs8Trl+mt7Ra95N3NMc8
EWqBqlTqJglvf2SjHyGX0QAn8qalc+AxiqtUg3KyevxxxTSPG5oS1XgnknqMZ7d2xjcR1mMrrD++
rC5tZ7v08QW2apwUw3ptIzlppbT255JyvNG9590VVqwpwDT+CcLuJ0okXfYql4jpnGjKU6wvmXwe
wqjSbme/jDBgV1e+mvfyLJyfPZFmtg6eA17ZcjETK6goEp+Ihi7XnpRLiBlUFYKadHQVeNUYKLhJ
NdK7raaMLGWZWuzTdeeICDx+V1hMV49akzzOGDxEXC7GB77mzgmXk5Z1V2ysD3TC0VKu2o1OJq6R
3gU1TD2mGX8FUnG3mI1bPvHYM5xsfXGo9EkHfZ5wVSfz7/OAd19g4t2JnDMvN83135hT3+X1vfQt
JtlwcuNvMhw8S1n3rTeqJi6nSt455U73Zj3tooXH2yUrMFlN93lEVvphbcrLZRwB/TWjdgpQ8xK2
4ZpqeN6t5rjt7BCqHY6XNke2n+BIUUzQKdUNq9INqRL25VhpeKLlliMjpE1nAbpS8dvJf6UFkSkh
JoVTOVPVS9OeqCyYSZUUC5yXFOvo4bfNzxXe3LlT8drrpy31zYil221caIYTungn4/v/iAvEOqln
iBaz0mepcTesU2dAOmEpv1VbztNGxAdkZ/4auXAxz7w0x3+XhXTFi1zJEGVeqUgJMx6o2qChh4pF
YDIyZ9uRBuK8dSK6TfYw/FLWKzJtpBdAma7DCaJHb1ab9btiomYmwQchDmJ4wqw/sGAGhRpl4qTg
HW+pWbOGNe1HcQwyKU//QBon3caLphKAvbHXZtBX6L1V6ZEv5jkk7V2TGT1QX/JQ5C/9F+3A9z12
J+6Kyi/TDmKveNX3Y8oI7ppyXyArqC6eHwFUjF3i1i0aatJT2Bb12pRkN/B4u5SVLh7pXDpici7n
dWUYlOLw5b7QvaHldN1YtmQenXoFxqG61ViUoPV1z5EtnmCt6HdEXU+XxiYicefGrG7/FK99cYJ7
/TeLwfjH6QrCx4r1dUW5UBBOJz8l/8hfEoHj53Gb61CkT3oYA08bsH73TwnX64deaIxPX4I/YMo8
kTJK1KQkWlGMUo480Gic0jHyZ1WPrSrEMM+7HTl0YzTewOm7Jb1CWZKUgBbnaIqzjibeJDotsnWL
EcR2X+aBza/NKS6pKBqJSYWeqSiENq8yaXiq8j2vTav7KOaMNex8WWk54AtGXaem+xtxFvjoGxx9
A7/mfoyT7ft0wSZydRlaky0f7ZJaCyXXBADbHKQ8Jbn+fekveFFXPYPaKcX72k3BTCU7O+XSfikz
pOHFDPh6U0XbvKi/0UrD/VzXUP9L/HCdkai+E3IltWNS5stWMsYgncPpmBDyEh0rMewtUa7md1jy
1dMSoFiHPpNZBYLDjQkTUVKhqPRi3C1xGhu1m9VThNs0rooxaSRHOlgvYnqaYR8Y9pzYG37vSo8t
+zP8Shw5EhoTv7Pk99obHpy8cMrCDLkvlWeJD+m9S9+qFNkXqK7quSpLlzfFUklywUrX4ggxqOt7
Mu0UynlnSDNpg1fWnZW9f6zoPjaf2eGOVLl7BNkdC3P5Uk30f8eQYvKiIr4A5oiFKnyTvY+tUHC2
MT7QQLKmhJdiWJkPztOAMutA6Z5gjWDHX0bwG4pPv/k0P4tlsLS1Z8ulbYNPr+v/f6waN6g562Ye
NeVJcyaHy9fL5Bw5EZqS3LRTzClDqkIIRp06YWbdZhoWTbmph2m3EKx8LyKZqbmj72r7ukWgZwm3
XQuos6uWZ9A5RGF6uMpeUgIIOCI9ZF8tVSS+1NH8kvhY/GKaJ8sn5/Q1iZBTWk7auCY0BSdeLokA
E4d7KUXaM502u+eWGoqFQr3NaisGw8wQva5wJqC7vbnz4jlSO+RqafXpFcV2z8/He6MhA8rvyCxP
BxNNAyCPtmFDaLgjuZ+UX2vYsYKDbOU0/tQc/lQ2Jtkj9uO8v4hfXcVJKVUXJpCpylN2tzeeocfb
uMXX6kV+JomEe6FRoEYIARnWnUajCSby/Suc1csS0Rv/q2adTF413xBXXMiq4KVHBGdzUPw8C3ND
uImvii7kTPm078jMAaZ3N0skb3ZQXpvsplwM6wwtaGh/Ukvgt4rLjYrxZRMzrk1pIDINuDN6K34w
/izV6lyXbA13U2Alvc7JKr7owZmWYkaAWArtFMFnGewaJVh0YM8YuMymuPTh63vGZJMUHlyUFm/G
WxG439PdlTOLib0zacmm/KAdLx3obC2bC+RN1BzQcptsFjRTeTy8WA8CImH9CUNf4zRvK7tpkigE
f+1kLqAqu+ygT43h5cHOmhspku1qaJcqeYJ2SL9I1XH8nVWPfC+Tn/DU9rACgYLTjOrIa3CQr7L3
R2hK09laZn6uRB5kmInc07ZTxD+g4u7IDoXyW9hPcNRyp23q+EiMraCbGGSIScY5zFrCNelkoWCW
F20TQ0lybJZP4psWcxhty31DSKMpp65fo9FLRCC7lPXL4bgjl7zocfhpghXupanX60YxSc/K93nD
fQQ76uYSpnTgCvBLrib0G0kLvKBqB3cTIetx81e8UPfh86eBZcKKBEumnzrypnWduXFD2mte2x73
S0uD9ohFjb7517Okp3QHsJIQPsNZU2Cqf/rH/yl3OQvvYvvTP/7P2S7mMzTy3bE9yKVtOBj54oR+
VQ1a9Xo2NQ1I2sBNTjtTWaJO5WAGjUxzVnSH09K85fLniJVuvMFz1F11h3O7Xjm8TKjAm4N7Mgdr
PsXD9Y9b27tgTpSe4/gH3HKzuXvXSgHx59jUVvp3cBmHvDNJV9O3dqZ5d0654ph8/6AXqJhlRCqL
UYMKUJ2M/ciMxDgRfcyyfxYt9vLNL+0VGW1zB0YldQjz5AN69o+oy5WZL5+7WxMEi8TeiqVCi+YU
tknL1Vs82+6RDVXWPL4OpYX8oe2uTsRG1YlN8s/Ga0ChNiWzfIwfgls/S5MvrdqabmPIa4LHUtjG
Raw2Op7aAyCImdoCUfIbsAn01zeRZtibO7wFei7vPgNbdi4UqexkxFjN2TayaZJ+3sal74aGfe4T
qkuSlWynDILTyNU8OzXnOZtpqGpD6HVqoqaZVql56raS5BFa7jtnbC1w3lh6G2z2kq0u+0zmoO3T
woyDTA8y1RHLRHgO+FRkHHfextsj3MwxGiuC/XFMzYEfqYTulQo/iUL7Tt0LYu7COXV7FZegUDxf
vekJczHDP9OEOZ9C7wYTpnFwVPU85eXi0HVl7vSN5T5PM30fME1e760dtmmvkneJVSqUsaTHONA5
sDfDHnbotca98UhO7VCAm7wqMilcdt7hpaSqbyqYNu+SowUvESlGTUfUTDsTbAZG5Or9HweIt+MP
mxAEJAe8TxZJCUfMeD1gwOusn7z/wxkCFBllTp3OHHE5TTv+rCyBa5/dmE1gYDEmDSbwKHMKOYiQ
b/Wm81D9xkw6vFEWFf0uPVXdKybn5IEcOOGSbBTiEzExE8l+f8DdvCj4cMBN0NsgTl/5U8Y9otZ7
Lpf8IgMQKQSPZUu0zRGYBaamO6fX1DtHhs7bg3syaT07nUyQczPeHe2PY9c4T/oYdE6cj0i9QvJ3
N+4Pyk9qepyG7Qf6WbkODRYmFoJJqvEzYj4zyHfLnbfXpAve4xbAxLXIA9H0YQ25tp2ny3a8mvbb
tDi2Q7qfq70YrFTMuCRYwDm5w/QTh4JsefDnJV8rxbV1I8bqn/D3FKTFdf0gmSX8fSdY4bqk1zmb
BiIhTEe7aU6GxrQy2zyCqapZ8+I6xmhOaJvHHy07siVncyRbMmVKaS7HvAXj5XLMLnZVhBGbpXJJ
9Bf2id4f0H1ie1XJ4DPDJOxFcC9koH6oXJIg5K1VQlIlLJs240KHfd2fktGQP83pp5e+CWJtNGsy
uU0ABcaTSZxw3Pag81tu50ImgLoXa6XKVIA9pzxdOuW45F2dZ4R6pm5OFYcX5TptPANZbvFLlQXP
uHrwfPf9v94stOC5s/OB7Bwsx9indJx8xcsmhzIlXC/M3hp7uSw6Tbqd1JlUQhRSktksvHZvFw/I
MzEv17JgxItWQM3m7F2RKCaCPp3tZc49BPOm2RmnkdRY9H+UfRQfdOCrLGdifLKng6Mrp+5HvLsn
ZhQGnN9yIq3rGknkpjiczYeL5Up6yC9VZN5jXzpOrDszMyLRGNLhLKgbUVGQ0HZQ7FjsZbFzHW60
s1fsgss9C4JXFjOnJ6Ru84C5kDiyfTb7gN+kTOhMuFABpuOzqpnnSlb5xDUSQiuGSm48S0UzZAej
FOsRozq+Zad/xab2mT2e9tHahdb8k5OjAYjbMfUQg7bJc4fCdMKjzfTasjXeuZzeYus2a+slqB2z
NxT7AnE/C0T62WgALxG+diTFyCYNJbqtEBfaVab7rSER29Hy9R4Luk7tFtY290GmHi2yuHkWuxSf
wyZs4j+9Peg0RulS8sD5wn/+o9g78816zwXt4Hm3T8ue8sDPMTbxGtlAn7fjnbkOmJx3/EeS8uMi
dvzmbs1MCQ2GZEosSpHsLNhd7NPUk5U+qGhLmz3zlTk5pqn80XouW/O6tFSbEKqmr6usOZs3riwC
xU4B3CRSDLc0mrRuoXaq07G8sds8StgvhUCYCDCjqHr4tFvVKz7R3dy1ZS8urRijMcvbHJyv58FJ
qatKqjVE4TSqAvTQFryY4OupZS/TzCXrYNx69v5fPtzydzobE2A05B2PqSxLR4//4E8re8GpqsRq
16aL3Gx41u/546qbGx3D+k+oK+GPKn3bP7qqiyFlq4vLXLZMEL2yoyh/CADvwzruqL/LnSwgpwYM
7HECY7MXM7Gz4EUiaZ2lT6QFNuddMnXXHJt0V6/n+i/0/sfG9P2P4c/3P/5F7n9cztz/2Fxu4iBH
3MQXhT9f//jX8O8HZBNx1//ik62Hm892NmvHvb/w/Y91cNwlc/9jvd7ExY/1sFGPln++//Ev8e/h
6OSdnBiLTO0Kgr5htIjz6aFlv+jgEAYoXF/DT4YjGI6C8s6Lzc1HG7sbwddPHzzWUxblJOU+TuMZ
jROqYjFukZycJO27dw/7k6PTfThKjnFmTxwzRHAXMdcfxiS2WgBfUSDNJiZwFfdqCwvbONUxUYDi
pEULp3SCIWY1Oh13Y3mz3x92cEYCj5FHm+d9vWidv6GKLcAh0afflwDgeWZ6Ujw+7uOM+R53Ap5h
XwXvBkdIFFdbA8gA5xHTwMBIenKseSKVsAuzjUSxL4JslxKmB5m+cCC4A5xuxZjOIAGI69DP+Mkg
lcbwcITkEGRCT45wUI54hAHDb27Yy/UFLcIopp1cK+oCmvJwYLuAwfVO0a0/Qy8CHdyClwPesRN0
F7hHmjMKHfNoMVzdmKR4lskhVH8AMqZnyD9hJX6UWAZ64+gLe2dse/wmSO9Pkgy1obl3SLYmfaDj
I15OjrdyrzqaP0bML1CMTBLpN7oGGgvoN1IcJKODyTmn2lAO7rmCSQzSQb0+CWpMohkq+SAMwY4v
7D7e2gl2nn+1++3G9maAv19sP/9m69Hmo+DBr4Pdx5sI7b/49fbW1493xQTb3N4JEOlnesTu9taD
l7vP8aKERLWtnRI/LGw8+3Ww+SscZLSzEzzfDraevniyBWCADjV8d2sTFtzWs4dPXj7aevZ1NQCA
4Nnz3eDJ1tOtXRTbfV6VRk21hbRa8Pyr4Onm9sPHeNx4sPVka/fX0pGvtnafsa2v0NgGT4La3Xr4
8gnCpi9ebiOHbjPAsBYebe08fLKxhQh1Da2jxWDzm81nu8HO440nT9JZerCJjmw8eLKp0J79GhW3
oVOzy+lfD4Ed9OFJlRXhp8Afm7/aRIc3tn9d5ZiBm53NX75EIXxE+PbpxtebOwvla4YNvD98ub35
lP3CWHdePtjZ3dp9iYD618+fPxJk7mxufwOZtrO28OT5jmDk5c5mNWDfpWGAADp21vj3g5c7W4KY
rWe7m9vbL19IOhvm8FsMHX3cQNVHMmMwGDhpQPvz7V8TKHEgCK4G3z7exPttIk1mfIMo2MHMP9z1
i6E9EMKuN8bg2ebXT7a+3nz2cJNfnxPKt1s7mxXMx9YOC2xps99uoM2XMmROPHqlf27tLFiqrMps
BVtfBRuPkMuEbpvCmN+dLUMLgrKHjw26az+ren+1//7TsP+a0/Zf9LP99xex/1YK7b/W6nL0M1f4
K7L/mBD552qDi3q51Spe/2Gz0Vxq5ey/KGyFP9t/f4l/i4uLwS6UcDXMYBnsj2lZiJGAHYvUrk95
RIxo6g3e0kGL7MHOI/sdhwy97TAD8pxvS5UFgQgfKLe9DUVnR/5LagrgjhIkQ1bpSR1Qcb93aAzM
v7V2Yq0X368RjIB6MeC1ZDRwkJmM0+wPYQ6orfVKbUw94AVNnHQO4zdlGqCwPx0wY4j2R6n5ebdC
8MHNTd8PMHXZUKGxK8MLPoLFCygf0+hdXPzkw81eAvlQy7e4Iz/e+P3wvlj7VyF9FBNYB3cjK9j0
/2MYwmYAH8UWVvr92AYxV8tHtYkB8COZxYB0Q8uY/rEC81gAfDQLGdA+qpEMeB/TTga4j2gqZwb7
MaxlAPwgg3lBZNNzpCTy5ojz0fgtLzaTl+u5fwtWxCKgi7MeJxSNCOwyHWLiBG+Vqa6nx+Q752Bh
Ax4I9y7AUQJaiEXQSK/txGJYCx7FE65H7FlENxJh/XEXiUxIdhV2JrlZ5XXR73iiDzmmg2SBbIr2
Jync9tXGGBuBDvWdij7cOsobHGM9XTbgwTOxSZpTESf1vrbDWiEjhAQFwxL2B+F0EHPXMt4nb5Mc
TI4PaR7YlvbOQtrWfFyjkwgMagETv5yUZVqP4JUKizD0U/K+Y5w1TAaIPBi9GAv3ckmrQ4jnBHHa
sbBdnKMhYVYMZMHM6ON4ACYX2PyfZOaMyodvY91VpV1MeBTjUR7AAk5/QCwYKbBVzNX6scmHrR6b
lFLzXc5YqeJSDS2hj/In3pky++9wflRyul+FwFtP5Izkmr7Tv/nJ/IkSptIh3x7zyOAqJWZnYmse
esX1u3nQYqY6RE1XtiTK9sCaPi7YUV2Mxnvo6dtTpvpeXiGNYeET4OXBKTaVB8wgxJyhjMWKqCDA
2DtzXdmEaa9Ijx6PME/YBmMJOakJmG9jyVNCSW7i6gRRa+kC/wWmRekRlEFqSci1ZmIDLVlIQi6j
Dnc3ShGBhSP9J0dQcCDT0KE1obqjEZVGzByIB88Q5ppAx1sxBZK2YJqz+hahIa/gtE9kQS7LBcn7
/cl5n1L3hEuAYhmjRtZGPB5y4voTo1n3YzO2HbAL3s3keil4EiGOJI13PHUM705GenUqGmKHMwPv
HzANxrSPxF85hpLQDUG57T5oaQ/Ay53qfmXhE/NZ9zgzKdi9Qi/P5AShEK+0/Y5sQkLH9uUPTu8n
n6Dhcgfnl0eV4HfIJNnXP4lAfv3EQTZ/3DGA+RHKCX/xXBU9VKiDgwEi9uqTffduP31ne2T++CKI
FiwQd6IPG1mQl4LYjcE56WvfkKClmRnEsobsrVG/R570DrAGfaZF0cCYmlAglvyzv16vRq2WosKg
UhLQQf2fSInv/RKf4OOr798wFdJOQ7/6fcWNIl1A2IOj2ek6FhmPwsd2w93R4/hil0NYv1z45BWO
4nizXqL1XKq+KoXmIeRDpA+hfGmYB3xhraY8hlqrZR6k1pI+aK1l82BqrfAxNG2tmgep1dEHrbVv
HkytrjyatnrmQWrF+qC1DswDa10t5CjXDhxnZXpH1Ke4eNV7Q3VX7Sj5zEVizAMaBTwnyejpEA6i
ZZ8eY1NKcJHq5XqYBT5/1+vDkku+q+W7oQDLF1UtULErjFm2yivLpdsXpeoF9lMusoeU8UfxxcIn
LEE2ixO3Szi+vlS13ZeSKMKSAJ8t+Zv6nVIVm0cDYTRMiaX0kzTIerKQEv5JGXRgOoX0/1s4m7ZW
CxIlHa4EvZYwL5JEDUCa2d7k3QmObTgY7U1GeyKwL8oa1eVHw4n3WIBDlL2ZArUnywrrHqbxW8gk
jFiS0HjGx6K+H2bfY5DEtLbB5WevkA4uqpTlKGnzPEd2DicqjIIyz1ENwk8r4IjQIXgKzbq2wJ6C
9telH1OTxjt7zKj2bHNlfa4q9Coax1zqu1cXb169e6OcJuEpCuuELW1E5H+LkaJVtYQdahxh+2Ya
2JTWtf5T/zm94yue3EJFkfoM0cutbzzrUJBn+gLVLyDyKpb2f7kdaPB9lzaf4pzOFAHJAv0hBK2q
fWWZMHafFKrWZaUqpSj7kO6Ghqe0QRm5gCvr+YcUZFLZEACuPcP2L0WQKAMHpN3+0FIIThHhqYnS
7dpCbmE7bPLhEFIPsk2J5Dv8/k58OjuxldqRHTZt2Rp1CZGrCW6epyNJgIVVFONENaXyLnvUx71Z
5kpsKOXYcHRknjxXzBS1wdm1R4hldAQ0BQkpGhUfsZ5f1RdX39z5rOSEpFnCkLNMFi4ovbH4L4LP
bt/+ona3fWexqGqkVdMXTRUbn8CMQPJ+WW+DgFeOW45hTOB4zJ5yFHim8IADyXB3DyYpdgxl2B9Y
1gHfGC7x6PYn74hEQzeqCy8W/HMWTtfW4n20VsHvMQdS3SptXAdSfs1s1stnyogBXuiNy+4Ky08/
Dt1Hu3Dw8Ytg5fVr8dxpY8NpCGyXRwvgiDx4g3pkQk2PlLFI6CTjqcbW3WOOIVQ6qpqV0JnIFVAw
X8x18rBoWCFcqk6zKrvaLES1uugfhLZ5NOoF35E4tJ1y5bsKl5+aTHoQk/jhPLwdg2X2cWKGdl8c
WsfYqzZxAyUvp0JpGaS9vz1okF5PjjruBS6OEb8UzgtVtyz7iIOLxTFlgBsEmLVSCDes5wGHWDi6
EtrBSjV42xl+38fbRjo7ihvR5wLvKMcA5wnL0MyCV+1NrNrgs89eP+gfvh5opdcHOPvhsmwI4pZH
JIuY00XzPjN9Vzij1LwvQNTV1WWmztSIr64C6cBYOvDZZwseZUPw0MAcii8N3OU4nTyZzywdebzV
J5GqmwOfbnJlM4BqsKSEz0+w01RddcIrO92ukMQ5EW0XmjESHDe3RAVn9cjU5eqgu1QYc8eNheNT
bptZxOWCZSjChOwklTLhYrOuvoVieZAEKBGUnzz95eNKzTZyBNescXxaiVk1Js65ed/1WJCHMOAb
yBiq95K8vaoMPwmWF8PQcmZXGYr5wie40CxcrcL1yRWMnw3+DFavqvjQaPIhWpGfkRaSD60WH5ry
2RTSDyt1PizJq6bUa+ADWwnr8rgirSwJsKbUCRt8ZT4v6+e6fGjJh0iArcjnJa2xyldhS36GdQWr
rUQNQg5X5Kf+XRdg0TJLRzJIUzOK+KEh8CN9Jd0Pm1KjscyHaFV+1rXeirbSFJQ0ZORR09RkneZS
yA9LRE8kf4ery/zQiojXZigfVuVn1JAPK0R+s8XPjUg+tBraylJzGY+t+rKA5M9oReosR4TcWpI6
q/I51A8CeSniq2aTfzeaIT+sSF+WlqStFfmw0tJWVgVLyyFH0Qr5d7NOLANvHPOyoLK1tCIgI/kg
6F9ZImKWpF5zqckPoeB4VV4tLSnAprQSRpxYGkrSFoG1GiusI1gO60IQyzIJrVVpvskmw1AwvSLE
sRRJjVYj5IdVjn5lWccVaitL8ikSXK2SEQfLdY4/XG5gzGiLdVZl/MvNFj+sNPEqbJKeQ6Ta88Mq
URmuyqtWU9qSaVtpKsaiOhs1bYXSgVVpJQpX+WqZsxhGDfmwJB8aRGW4QuxiQEvSCQ4yapKEQsFY
2ODow3pLMQa7nHVWV1mnGQn2BDHRch2vopA/w5b8DGVeIoEfCYmDUqUtIXHQG15FQq7hkoDFdFzR
qBSG6KmRYhTxrE3LwVSlpMpiuByc+zAHnZ67F3f3hEN9Rw5KBZIizCoLRtQ5vV8YHQRUWI2qjWqz
oiGqfXU7iBMzq0RLrZqJ4nEPMCs2qytFKqY1yuKu1MIxjcMqa1Wn++qsVPm5d5we7KLqqe7bhSg1
emWmWCNVTE25lcJyOaXTb+seYVcWFlLfEkKXaqvqbmd907UF9MqAywBLr7paXanKMoiqIHDMdViX
1VIF4+ZTxLvnTD2YDHYe14PVVWq4cmMcN8jFDDMb7JuL5ETv6Rgpc8YTLx2gzoXFnfiu8gilFRh6
rQ7O4FW9GJzJjBET/YOiWhT3Ba/vc2vkjG/3vGmRhgr7w4+m/aKPMi8ilM2rdb/P4pviV4O79bB6
y4lMdVyJPr3uBOkrU/LNKwvwDTVyr+S+uiGagdE/siq3cRzaubqHpZ66DI0PQ5zMOCPuVUpHb8Rr
qLSY1sWmleK60bV1gdtZDTemK6u70pJrOkitZ8bkLwlOq/AEIMGoy9JQ13k3HbAvggY8JjgNz+tm
FlTkQPnq92x4EeGFs+E1HDxV3mdDCgFpxQGaXw5qv4crNNoldQ+ULyqasxPgLVlX4pPMOjZ/mS+Z
hemRv2vzExw90nmbdkJ++owpBX5vvVmvlh7RPJiMRsAPlWYGzbtKrdbYRR6LtYvTylWfSTg3mxEt
Hd94gspa1zhXmKhB2R92B6cwoguMLmnaKPxWPyaONSnDeh+Ezfh0gDeRNcPIi6vS3vdYrzhzk9y5
UIQYQ5SuBjsqOQLMcrb+XCnRny8c+gUyoW9FwQcyervkZjCRPAvpv1mYxzfyXKOouM8q8ozClsen
jMclKKVIrjpQPN1QTC/jfaIvxqDJCGk5Ddo4mm9xcpyv2VAhSqTemS0lnEIVxfjHvuPkfKe5QCYX
xSS/nMMz6hJGMF54R+X4mdSzIvOas0uxzRUGOdydialolCnfARds8RhCXikqTkOBZ6HzlRwE6rsi
xVEOqh3E1u1hKL8qoTEYvjiw/3O5QZyLqHYDnUiY3d5+XzvmUfs0rrKEn7LKlPTN5Od8aphHOWOB
SUA6k4w7iVON+ExlXxI8/3vnsNQO5TUobc9QUuZLzqXoEYvna7a8cOqVAZBXGIW00mbm6o2Cuj0z
weuzmEcKLKVV+80h2hC213Cz4ncj09aUoz1qT2UpzHOOq7uGhJ/Ekp8RSEAw5fKSjcXUQDqFzXnq
nmdY3MSeB9jjuL4H2MT/baoGLpY0Xm6bb4Egae1tDa0IcuyCkUPXJWVB/DKeD5+usXeB73e33hxn
l7gxfvHFM+3SF1+0rXNoHMeGSUo/08Ees21wSspsU3vDG1UK4nzkL/MiIKEP5IFgwlWnd2yEqhO/
Zl+SQFe0mlm+naTb70/2B+qboSdmEaLtp/5HdaZ+UQ8X8eMAEeAPAJWCC+sAFwIc/Tb+5wbM7sbK
dLXGKk9z0L9pTzchmml2K7iI4CKAC8T3Qi8H3RP0KtAZQPOeVjkNcNrNVfE6ze5dg+AaZrD0DYXi
EqiKY0vsbFrntIGXaZJXxfnFxFb6VOjjoqNGXEICrklwTYCjUU8rnL4V+iSiVR6HgP84QFSj74AG
Nh0Ns3vXIrjWgR61n9WP5gdmZYllBYpEqsSEMydu6eo0ZI5AyZRIULozrGTPQDU8VItqif1T5iSZ
uL0E9lXDEg4JTdmL7zNbQUKz+NKv9u9EhuPf6pDFE6VVSt2GLGhRjMl8gKdleR/WRSVNG311y3+6
E75ZN/wRp7mIxxVXy1QJnRYCT+s03N9wVz8Rp+xDqhSppHNQnmFtN8G7hGod6nEQDy4HxClLCRXa
ifAMxK2AhZOOSVzOZRuDtyC49pkJa10zdcIlrps4o7MOJ87PwMhEVDCj0bwZFZsJohs4d2aXWLYh
T2807OoVU63KrNapQlmtVMRE3I9mFImqkSnSl4M8AesL+ECZDhOpqTKHIlJlEJWratNZS0zBZZvs
VN78SJhLlYyh9JNoy8boHXnxwbxjED3N1aZEE9vmW6vSGbXv5e5XiyssyPwbyTpWeQ31sSs7DZgN
yczI2EjDALf68RzLgIlhh0MEihMDRINbCQ+gSSh3TBxi8O4aQjNI+XEsQqkpg+++h2GlA1JXpbpS
+TPjOA2HK5qLR0uNR7pkdDXPfgtzweV5PDRn+kVzq/prOFexObdiZk6K7Ky8Fh6841FTXuoUk0Ot
IuZn0NogWDwcnR4eiQpoFTAe5wq2MI7F2Fgwbqx8uFDo2UwAYMW8P8GGMwsCZvnoVX52mGuDgyl1
eqYUZ7k72lJl90TiWdd65AwndNRLIFfZ13tqcEpY1YFnSJG5QCdyQhRPO21Wpc1Fr5ZSTqYsMwPN
ZFrWYxqXK8XWXaqSX6viSpu+eA93MvDN6kGrXpHb0Cl/t542bN2yetc3XRKLueLX9s5Unt8xU8j0
iZ65HrOQmNvGXDdNSmIunuTj6VF1htYCH9kufLxHVkHHQnka1XTCmZQySYvpjeKEvBPZIpC2Nh8x
rOaBCW8qHmyfyZq65jV/yvUcsNKOZzmW4VUZLuXZZ4128HyMs52ZqPWjcsY/KBFKPBXSnGGBJlvc
rW8+9eQ+ns4YQiD4SjJyO+QZ6nxoLT6GGGJuCi4SkEv6kqpno9Ec0rfGCFNFCDZQurglPywqHmIi
cXKFmMTcaqTgUkhRAaSuV9cZmd9TEzNmns1vMrt3NL9JhZ8I1mxivQ4gkLT4wYHmKmj97+KufvzO
diixGQYHo9TSfHQ6tiwU2mIiW5TEj+OSks0cgAW60VTVdWPC+CY9wUTainFlVE5N5R/iGMozk290
Mhq8w/HmffEA8qBkZgB8xXS3DtfBEW6pxjVzmgwAG3ykERdVOlPvqrgE2hUl2lu3bkHCgjZ2cHn5
MSVkrktS6pnU16wJQfOAu8lgfJwe4gevMbCsPV+9ltsXMBgd3u2QEYwOTaoCZYvdPYj+vYPOAiEW
D2UPIeXcJLk7Tu4eHiBCivRgCFKtXjvpHVgjmsr7nuqCTAnmBU1QTmhPa96BZAxUTcqDxL8ZrdZY
Mw07ROVpOErUlCZhXaLHrapJlaCRy0yFhU+wM1ei9xIDrmr+QEjLMqItiG2TtDklo0J+aD6DJA1U
TX7EqkR5JZa7zB7SWEbQvWqyH2hTBwyrh00NmkuwnNZqJBFliYSzObFk+bUlPZQQd509bEp+hPRd
Mxkkwl/VVI1QgvhSb0VCzC0JLfOxJYFv2sRsSfIHkF0AgJIQwawDScMIJXNBMhXkkXkaIccdSWha
+i/h84akCxC0WNvsAjIdAFAi5ZGY6SuEynyHSCz15WUJVVc1OyMSE5zmeSiZDxJslzA3TftIjPOQ
OAyXxWvAypKhEUqGhCQlsHOabtKQDA2ilBDqMlv8ynQMZAJUNeUjBDVwUiTLQCLqLMipiBqCAZbW
NA3+FcoHmVF+bUmahvghhIokys8hB5oNIokAMo8S+ec8ikdC0jSWVyWML3kmkuNQNQktkvxBH0og
1TAmABRUSfoEPSyBoEUyMGQeJZNlWRwgMuRlSRog0thh8Yys8AcnCskKnBT2RvIZAhnj6oqkSbAj
DUmx4KRIuoH0WhpZlbQH4odf2Y+oJVPGSYlIppotsSyZFUKHq5IKQfgcnjxK3gVJMIqEQCX1gh2W
5JIlWYl1wWFLsmMkrYTY5V8yeHEWSRKKLGiuo1BTI2TIkrwh/iQhJSJkhcwhlBwUmX9Zf+IQIp6j
pqwwQYN0nQ3LqpY1syz8g1+FL9BFRccSyUY8V5LAIX0XT5QAFCoibkg7EWFFpJOI6zYi9YXCBySF
RRKvUAMAZXFJJo2sBQ4+agitCrFLaSFGoSeZW+mh5LUILxL+JxyhzvQP5yPYE57p88uIeKNNaQxP
kxAgdaUhSQGLzBzIWhIqEVYnyzTQIa2YXskikxUjFEA2DKTL3Ak71AykyMyi4luYceR4m7AnWX31
uuXhgg7NWhP21LAMSJiSMA2dCOVCDctF+VXwIWtO+JH6A5VRraooAEBhssLbJLFHsqLYOSEL4ZPK
52X1BauGwcmKlPUlK03pLBCZIYyr4Ui/HhmqFIFAnqjMTGWLsJnlVSOsQpPUZdlYqylrdcXIB+VZ
ktIktCFrbmXVrkYRACLBhOs0QrM6AuEPwi50aQmzUR7SMFSvdCz9EvkgWWnCnlSYNA09ksGpMBF6
pxQAQJUULSueVBKFZpHpWlpeMVJNWIqsKuVHMhxdsMu6uoFDEX+rkVlBIuRUfAt9CUerN4zojNSt
u2wYjvBmzfdThiAAhbEIYTgRr2xZxGTk5IiIkKaRNUbQNpykU/baEhzKuly1gkqJZcWsVdUomk2j
VoikEK4jTE84aypnyYS4+JesmBQuqoI8suJbNBZVZeqGxQuD03Uv/ZAhCpNriDLUtGJSuYSwQxWv
TSPLhC2rsCIPUdEmHEbwL+pBc0l5DXEYGkEo8kckUagdsUJIuJzqPA0n4VeWjXDUtNDVuvJADnlV
tQ7D9ISTC6eVMa6EhkUKKzXO+5bhsaKFSaxApBPFKTWDppF3yjYbwkBDwyJF11OtT4SjVG4YGWtS
W5UDtzR1zm2cUC8JzYBUIzcbmbndkaq9mjeJ+OSWTWSiMR2NkOmPNAIhQnZFUxca9Vrwjcn8QMNu
A8cPY2MTqYEjHcE9QIf0tCDVAXE2GDiI3ZkDEGzQPaz45g4NPXVHczdTcPGb8Iv/97/7TRTCML74
TfRF5zfgUdg+Zf0zbmR73nA1XvVq+Y0kMERO6ZGFJMQvi0YYuq7jOvMcX4V1rdG0C0l4hTIjSQ2V
ZFGhLFlcQq9CRXBwKISGQhChLWqlKsiWl6vcqS8ZRUGFtmgLy47Lim7hALYEoEgb5SdBy/AAhd9w
vE9/hIZPi8ory11lvaw/EVJ2sEsKWWe5ZeWKclqrShqtK7RWg/RyySJUlrJwXx1XVPfAK/ZFNAjn
Ft4pwkr1LRmMjsMq2UbNbRiJ6/Fi+ZC+s22saBui9q8uGSGmGKKYUt7VXDGYlcWtumw6m6IcrzSt
ydBasfaSrFTTUKSEEapd5YRDaDXbUJNaVw2fM9ZBaDi2Wh/SeGSxoVQkiBCBKkwk9GgxiqRJ5QjC
LYVNi9Gi/Vu1fEAkt2h+qoQ0rU6i4tvxXEFxwxpZRp1cNjxcBbJtvJkunUh4rGBXmGPDMbSgbvmu
cAvR36PUhHSEJFJLbBJV1UNrl4ZW0VDBo62tet1YMqupbtdQ00pG7VXT6iwmoho5/htaO1HEqObA
r9juqincMhhX6SJ0L2I6iKwIk1Wx7BFcZAhOpJAo1w0jE43pq6pAyxlFy7ZDQraRbVx3BkSp8F22
+rxQWOjM97ojR1kpdTu1xvT0lnPDkKhUW42MLiQsT0Rq5DiDiq6G1XVFm9V5k6HKYJSAIzPxhrKt
vqXOAlGwBGtCwGo4WyamE0V4FLz1q6sF3baSiXamOXjGd7/yxYXZN2OEgewpvWAJ9dgnU255uMQg
RyZ7LgBDZ7R4V8sZn/xxcugHiNYZHhKHGF234odFCQ0Nuegu44MsU8V1Tou8jBFee/pnq33+ValG
uYARIExHhnQgklpI0Vb/PMlmmMQ8ISh25xoN04jvgmw9KwoIO6HnyfiilKsi4bjX6dFLiRuuMEpm
E6XOQNnrk0z24osTyOvhxCHv8CQ1yWCQrdev0j32+UqB5NNmABN5imMLSBFdz2RLHZ5I8tJ0j1/l
4b1JJ3GqqTtTTd2kg7ieip1kpw5PNGfQm1cLyk0u959+rmrKUTzHwej7VKcp1/p/96TaXlpNiS7f
yZSUTyTIwl3hSuPr6yWl/ZLLRicur18aJtSXgST0mgWk8ZCi6J7dVf9y+BbbOYcCSTRMVmkHt5NS
NQVemUql3MNRWQkOg2OEC6OyX6ZmbD1T+E4hgeVpNcWWdb5eSRyoizSwCfd8KrDkqH8wUX10EB/g
hDnTeOAtAktsfieUZQjsIgrr2zjOsUdOFk5B+VmgM+vEvKvruwVz9McUtPvr0wjKLAmTJPjB3EGz
a55qQui7Qq7EXRzK57qj+AAHlfESR5fXIgfAeSxMAbr4SX4q0lCKRZWpC8uC43KHIigcprCOivml
C0QCNINt1uf0asaMvnljtmH01/OfbsIAq4theiQLm/yduLTSrPosXyz7j3dYocJoYKuVyfPP1gG4
XF79jP7O4M/VetrJIsh6bMssHHiVfcL1Dk1xYZBXHvQ3b1654m9cvwtO0/g8md32XGQ78Ovr3m6S
PIz1/mKYwW3BPgVNPMrXvDeFS5HhUj9Is3ZsLNnwIXM0EQ1gkyt7PWJR+dUtQnCMxYwsK6vwK00/
v8UImp4S5gcBXdiMOTvmDLFsgFC33kGUHZ0O39qYnznNKJEFOszGNSVnyAYqRdFBIr1RbaqScSoh
RW8/ck3PBLNOAJZ9pxXTeq4Ot+ppC2YbnlZOKzEGzB3sjBAf9ONBz0SIR4j644QRs0Ujm/oB3QrH
TOmpkgfuDEcvD07dJBJmFQdFqrC5vc6miOoCk9EEs1yUW2I0PildtQkrJtas8AyI3FkJDoLxkBz1
08QYJNXwRKqhy7Z36Net1NxLzb3GSyat9CrI/7ui9aDFUIq6e/NK3uX+pUWgzy/NLhKwDK2ilXxb
V7KN1PSIriyaNM25PUIpGmwrc3rEItyQMq9HKMMNKs25PaJ9SYfw8tweoRShNWY1F1UvYcbSolyd
XSSQMg32ek6PxCUESw7bbGb2CM3BBKMhOac5FonmdbrJWWtdP2v0OdAaBaR5PYJHDJYu9gPNwRG+
s8Grqj7KBNkxWBw1ZJ9R6JXRibY9imQfeVU84Kuze9QEkTSqtLNXZiOARbBCZneaOGpKr+fQEXtE
RwzcVfNmjc2tVmksz5s1zCqdNYKjpoeyFApwtCp01Liq6mKoV0OdaK9H4lKBhyuM5s8a6GglRTf8
JgQeXvmdBnivCKz6MFckSLuQlmlN9QiOU7q1w9bsHjVAtivVxlLaHJxH8Fxke9RYshvR9HGZSw+P
GRwtCeFEXhmlzmI6qpoXoBc6rnx8X+JF00N3lhlcMpqW0pEZP9hT3ZGVFPHoyJVR9uR61OTqx6wh
oDCPjtAF8AesbiBSB4cKLWLc7zRXf2Ra4yO2rDekNYfpLI5WZuBIAhGrUTo28d+tNrKju8msYfqJ
FEEjUbZcBYl6aFwmjoT6Xa8dyjI44pqoL8/lRyteF3TWHKF7Rdw0mdZa0iM3rjDPj5pF/KhBykYn
2dGWacwjdZ+OmtWmba6Fx1a1mWkuzFJ2a5qy6cLMzFqraNZacjhGlcTshi/eu5UMAvwumB4tVZuR
P7F4hwAlpYiMbBmPwFHLG9dUj5Zn9YguRXBJLcUe0Y+5uuo3h7rwGzbtIgFm4dBuLnlkCyRfu9ZI
2YRh5gNdIemZ2cjItZbSUdMMnwELEXRpc3WvC2b1A2XL/kIKM2uNHZxaa1GWsjGlBZTNDnBRR3WP
jriso8zSXs3yo+Y0PyJ4f/WHN+jRalGPhLJJ+410RdLRHmo1j2e7Lsg+p0sEFZqtXI/ccjdrbUU6
2PDGlZFr4VKRXGvcaNZYjNqIaY4EACbf9JsLc5TdKqDsVpZnkxaKeTbfhks+jsgOfCIhArJdmJL9
+Vlbmp416vIpKTsuypZaWZ4tMjw0kJbZI6AyjHI9yi6uaW1kOYMjzkgeRw2RtHa5z9KPmhlCNrPW
IsOIchzSLS7ZI3eJkGMzsxzDbI+aBbO2lFv9zaLVv0SULOsktdyskTuu+D1ayvAj6VGeH4XX46ie
m7WoaNZWOGtAR30pXSOeoPOElo+jxjSOcrMWRdM9iqIbcEiSu7fYjeznejBcwtFkhkM2pzlktHIt
ZTcaORw1Z+EoJRuDoxZJr5Ed3XVSRNSDRlWrSYJDijJf9ns44iCm6aiRoyNF2hQdNTI9iop61MzM
WiOcIWm9HrHMdI+WM8qHXf2uixZHYRZHywU9CjM4aiwX4Gg1h6Oloh61cvqR4iivHwkdeZRdL1j9
WZ4dFfDsKCf7WWaasqc0tkahxhZlKDtanabsZpSVIuENelRER+Fypkc+E/0kKFZFhIhy3WERn4iK
hFpuyhqt67szS6XN8MOq0lR+6a9m2ePq9WTdXLrRlC3dpEcFOGo2r1VpW3kxGxYwozDKC7XlIqHG
Yh5Z/3/tXelyG1d2zl/yKTpSaQiIDaq7AQIgy5DLaypVzkQ1UWWcUskYkKBsSCTAAKAIOJXnyHP4
FZwXy/nOcpdeQMrRj/mBtimy73ru0nc5y3fwhZSndffswU2tvGD38qZNLaQo79Vus/2Iom7NNtvr
xxRlVYqSEkX9XtM8esSCHW8hec0W0jt7kKKi94h5lPRKFOXDOorybkRRt6ihaPjgqPVKfYRiKhQV
2aOOIr0sGjVesMuj1n1w48+z0qgN6kbtLCLAvjWcKM/CsuKjCHajyswubWp1M7tMUTyzVb/xtcKN
iy6FwcVlhuTiYFrJ9o5BxdWoCGZka8M0ZzHFd2Jbdp4EuGrgFc8VFMDMTAEFOIVp2oQkxEuVlIRy
lDQqoYgwQkjuMFCMgbWijUyNUS9mgFMx+swYfiD8P6v7v1v3f6/u/9qU5QKtS73ZFET5pI4gkhCW
9OQOO4gEPOcsGgmVS8y8deya03J9wQD0EWSSxZBpPSRYgyABK/mwiP+nIgi2ysi0FFaUcyDQ3F2z
CSbpN1EhBRWGwjv0UcE44JWB1X/FMmzYGyeal1KTEwmMnQYE9YgJ64SsxubIYtVBJ6ES6Ex5Ob+z
r61mdqa2SGfmp8Wpl2i5LBFFBzsa3Rh1jIKfJ60mYn4q0EU6JqAFkE2k27QGgIwIrqK+IXCYy7vb
ENe6TKthTa3JmwlE7tCc+OP0d5pJp7gCalcEzYHi1YfEgc4Y/tVpLNjGyIN79YMxicvoy4RkAXBN
dDeP6jd9L+cAiJ0fvCCVMAkiAjgEkAKQWpo81q08qj0dW7Y6k1x+q+gSiXAvVJUW/Qn4yBMTzL/t
Ep38TeYeCxvfnL5903tr6CFXExKAOuxqZ0wrNpGhFa2HxS4nKkKT0roU3S6UDIDSEdrOsrrGnKHP
BaS1nAsA4nkR52KTV0YjSr5m6Sv8O+RJ8m1BP90EuuH0npdTFUhV0E+XfnqSqijKqchE+tuCUhQ9
+jmVVET7t91eOWWPUnZP6adPPwNJSagh3/b6HlqdOpXBTL10/Xrm8cEDXxugLQV9KapPUTL+QhDe
cKxBRVoJXhBCHoATcVgGl4Q/L9QSl7uuwXrX7aSCQyFC5smc97oQE/FIQRGPkhYX91TjaGaTDiSZ
pWcCEf7VNXtOgmsjxcSKi1RvPu/KkuwaITkj62JXZx8LtcjiamBQxWYQJQavhUF2uNNxoGB32YjY
sFv9TZEQb25Dv0FQ4RLdUVEzWd/cRpgiiKIAxhNRBRJOPTL7fMrQ9sAEihHIK422UxQxQvwLh05n
TWTLbWwqNlT4dsw8TtAFBNOAPI7MVr/AkakBS5iSgOkL1OBTHAZbMyNecEpRHkwlVHNLmMN+tKSr
CPeHaCDVslA/wUWRNYhouLmelUQvFAeojgJ0tVBePJ+9JVRISxfRRF9qnI7UZjq1LdJxHVPtPr3o
g8oI+2a9eRo0UTVxnJowN8Z0hFv8dlxbYfu5YLa66TUWsM0HVEKrJLxNq+0ulcxOcmTycis36GOr
Upp3oOnePLUM2jKDu5LU5HonHYYQsvGwvnlaGmYtxE/6scDEHBzIoDf3T4h4pA7mzMGi+JfQrfCv
qi+tMIIOmjKwbzKgiLnOTixyV5Mb9tC24uX4nGu4yOk7ynGngJ8+gn6KXlsX3eidFuK2z1YAMcJn
86+Szb/H2brLINy+B13KBGcm+lII0pZ3nh/4PJ3FSEfBrJwuSknprRWERKlpnWonTjn1VkqLEg89
BnVtZewmLiT6zdO4DaWvxNVLnwv9T9GDdmW8/w0bGqr87huD9jjY2f7S1HtEH5Qm7x/ph0qln9IX
lfob+qOE7RKVV4V4oVPJZ/LuOfpsj/cQThp3/J3ymafGS5GDi/Hgm3w9XcC9JGelc8X46oYAeMbm
pYydpJmXKZzC0Tg5ZGgKHLBF5/Ed+T6nksjfGYHNTLFmTErsBPGVxiaS5LqMAUICMFItkHtzgh2X
S52Se8I5NlDe6Uj3UD2geX0+OPEyB2SktE2nm9vZhrBfqW3iIo0qpL3+5DDqg8D7t8DlMJ4v2ov7
gR4c/bE0o4nFeoFz9uNFOFupi+wUvBeqv7cbGnloQ2/tPucTJprw8qGEnTwskbc/X0geFmIap+Zv
3oYS3aNj6Q4z5gAOPp5w7Zz/zNdOPt+Ed1Q5yApCzCufx8hcIaIWwEvTjjEe0aVx1aKlabxpH8ZM
iaccKgBS14ihL4U8itK/v0KpNTrE83zyB5lgwXjvXw+4QPrcxdlkp/BhetfE8aEumsKCFD7arxSY
i8uJoOm4Bro7e4vczgEVyhE4EIpw76J7PN/hrS7G5R4V7n1QeufTVPw+wLsvTly6h00rFWEX7/pg
sZ+IK4mjgvouFuv14qbSgih93JimKN/H/ZpgDnpMT88AfBj0dDeeCvpa6nmtqzh+T11yXEj95e6M
u+I9H1Lj1HFnWKE8Y3yzO9ZsN3lCnfHkdcQPkq9JV6V1KapFq2DbKVdPJ7hqMJaX98mGmwmZldA9
eL4Ov3BfCPUd+VMlhKXru5t5MqjF3pOK7XMtfa2okFDrrkeD9My6nV5T+Xw7+u25wURyBll7VsAu
AMtLh71H+iHnJHKtq0tV6bKvyjwy6zXptkk12rmbYR5z7Hoz4CuviG+Vy36m/uVAiHWjuYcseTBT
1spS4Ntkc1RmnnhZ/PrqnmLPZdePKMIWcqF8C9vJ7q+8h/O6ARRPkmvzymiTOvVTVxC5/dQ8YYgv
gXoLzABSrXBFDpyxj4b8k2oXfhl4kfzuJA/9SDrwrSpXF7rx5LyAhAtD/sVuiehXn391M/kFcQZ8
nHfI+IUTpV1NTiIhy5H2JBPJc081H+lk9uSvIj0dallpv5DiyPNZV8pD3rTfdwUN00FmL6QnMej5
4tLB0L3002HhXsgnQ9/XkJ5lSnOvU2RSy5DLoqheVHZ6NoyKJwWTwjWEXBpB8bzvW5EOoduURfVC
JSSqG6Iiqb/IO8XAWmn1JWleFJVKKdB1AUnkOBDKXlnUYFU89/VlQgAUqYYVqtJcxyekjAL7St2w
Q8y8gxpCSNqEHpQxBt19jYEIrFfpn5RVdWyMg35KWRmt7yYJchQaQUX1+7Ukk2iZ1H2JQGIqknOe
zBxi1a4efKbl1fx0cyoseHefZfaieGrE8yMe/4af4O3HpDGO89UsxJVvqrQWe+8wLVl+sdsMgJHZ
c5dcXLB2CFc8b2i8Ya7KeHvomReU222n2zAA29/9lV/G4CSXLgz14gtamXS9qFnR1HoMhbQ2HoVz
K3+CEPyFimuCg7RIEXhclwZxe0aTW+KnHOcp/d7Sb45ny9ntqEOQ1MaakbBNHHbAZkrLm3D5llsJ
O7cQDO+riy1txh8BtbxmZ+kEHLkmgzo0mwC+p4K5qwXKpsf0HU/JxTLTeDzdvh3h5jy5IJPhTTvl
39t222+I5nP5IPTyo79LPn7iEwYMhQOX1W6z/OEKltXoeIojMaPImcqpdavB+VsPDWcket04g082
5a09akxkr4Qr+DPa5+iG5fxwYkrU5THztzIRyqB9R1c5YseStWnJEwsuog5dvYI96TjxcteFAHXD
OMWRf7qUXHK2I2hSFddy4a2sM2greR6B2uMp5Kd6fVYvMqiSFo7KtS5GZj1J/gWF0w1vJoZxwL3+
mSXft3dLwPcI0NDEU3M0Xyxuj5goO7yZ03Jz7PmmQ0dOxrENnydpIvbMCnCLfxnbliI4KJPQjP3V
a3YA4cp/FiR5cvFcnzyR9JlltqDM/6NBlpOxdDVIcyHuSSJuKR+knYnJlAopPDOiuDwN0pbwLwvK
fKUSZGRzWgtSwhGoQZYiy11G6xY8j6Xdd6ZFPJFuyZSwTIOMeOsr6SRHmgRZe3MbQ0nhCtQgG0Qb
Q18/hz2adldVZn3lJ0JufSXv7h8LynwDJMjyZTaGfkRzG0PfK5mNoZ9BnJtoDxRW3FcAl8oESr1Z
A7Z88c4vDu57D5cW+bQORW8At4P72aV5mjEpmJjV/rJYzn4FLPC1vAPxgRz5XdffoZQaAEHITaMl
v7xYDHR5eP3LMd45H4BRNLuXE71B9NvQeSTfjY0IsRHWYz+oX9xW2A9wxiYc0bA2eHsAGxSKPEqq
Y94YzZSTHJM91SuT3ubbEdbCMD37PLXkg84sLhrHudPPVHgf1AciwXBQeSujvlMOgPVe/3NUPUvP
rNaGggYpuNEPlTPkcqzLP0+3+HHN4YvDk2ogLF9DuSpUwAo/oAH5urZvUA3tpyrfXsmsNFjn+/v7
E3L/Pv+wZVDn/1x28HF11ne0QZIs9YWU2dFKOooLHR11x2HNvN3JymRrkdtx5M2vIJlfy3WVyYPN
L/MBupyi4NxtDnlpldUgvzLlfnsz9Hjbc8L9xK9iEcVSXYVkt5PpsuuXy9wnyv1GmFWa57aYqHlc
nVFW2uGzLNzQM7+sx13h1v+oK9wOGh4UXHXBxuN3sXK/uV2rug8H22Ie7M5GkpLoOrPUyS6x7k7+
JJJVej7cOn3P+0ORS86h1jq3YeWVbduGKdg2g2HyB4+QQH/Q8Ocprk62vH839tNAGFCsoCQ6kfes
XSnYDHJXqftuI2YY+x+o2cZqPjtbOTSqXXI/Ke4kE+fCZFpm86tIKnCCbO70aiqziyqziS3PJt2m
sgFqycCVx/VV/tjywq4OCzxDV1N5TTM4odIckDKGehGOqNLq6iJsaeXitODjxMDLnsEh6MHWxW0p
TpTXLMWLpPuYlZla2g5ktQT8FDOdfZvysC1BA//fbaqlO25a3OzHt8ldUwGQMmOYr9kNn73u1G/g
zRXtF/AEwbMb7hQEUmoC0RYqohkc8HEDrz+0B5bns0rDjDZ8GLxXVhWWopOZztuKVq333coDwFgz
1tucJ2KEj5xO0/soviSkymJXvY+Uo+1g2jd9xBzvv2FRlWA5oshLVeGRfYJHV/yqEOZQ23DmpB6M
R1pI5c08rIZjslDmxiLRwfCeokhI6GbO9xDt0wX5nvXP3bldWNmOo26q4uBShf43KJR1BVqkV33F
WnIsB+9+2RZsnkgRrmOuukSp0KkXixD869d/BTd88kHZAghNnbOMezBR7lk5ZlpW9VZBLjMCXimT
4C9XrD5AbUiSb4gVMTMXHCp/zrKk9mnhc9y0WXew4OkU5Mnr82xrU+cNNWw4dbecOn+YnlKevLEN
LTgz/Aht5GOwBPF3t13bpjxrrtf1wnHwVqYh30FDfQH1dDS2P6wa5RxbqWE52M55+G2pIlWqWfIn
kjlC2Jd1LsjHzJQ9Kc7mmMIqsiFOU2tDPia3nZx1n9fLuytVMT5i/9xrmX+06B4dmmLT6sP3VMkI
cP+48VuNrXE6btumzYCD2LqZi78GLlzIjWLzDblUk3tWUl5n1wG+KCzwVhS3WHiYKO/wIKjQp9rW
ptgEJG2edWtTlGt6ONWzXic/OW0/b22e9TsF/fUyc01d3GIV/VVVP8BxvGPfWV77nERv5CJ9Reti
G+zYFy8oD1SAsBy25qTz8sPdhDup3UjAc3TIsfx+kFxNdiy5Hp067nTzOXp5RXsjKa+0WJmEG5Dz
yyW98E3NlEsMU7WT1ycW9isvdSoMhZeIVFe9UGrKqsuvyIHuDdRyZNrM4CtzkLSodPTzkU6nI+Kv
bpShj4mfy8Sn5ZeUcGmdh0IsSiOVe/ps2NGmCDil9sBOCbTWOsbmvS3Y+ZleHCfRcLrlepfv8v2M
3Bcj7Bf/vdl+1NKc1Nmk06zZWJ+b2fU5b6zygHf8E0QVpl9E/GHy1ETIe/Pkxz//619EO1J2JHq+
pxzJFx0l5UstKOMY6rnEisbS8xq/qDK7sH81nXoVTj32tbym+apdIwSPD0+1TC0UV2Vo8aSpOzK5
oz5v1NfXAepdfAm4XS9H8QoKrQ8kvl1Qcvh1cyf/EVt7cA2a8H45Y8dbNuX0HrCKWGJ6CdBixtPZ
Mt3i3xENKPUmHJ6scbLE1k0nHxxYsM6tmRmI3fs/5GywwKbM+z6uWT9y4MrwQXkFNk2fTNfiycfJ
7JoF56Kvf3XNvhFBtSESMnwi9wgJqkhGFSIohuGKJto4i9nFJg8H9Wi70xu20bCj7IgyAkj6KOe/
zlgxmJWVb0UDWYVweHupYM0sYvtCbasSb4aD6QItCFHTkjahLWtobooGvIdxxMamJ3eWGXHjW/fs
s0A6gGfD3dx3EifBVof7AJQH2Q0lCsllBKTz6aKgLodX1BEUgpXghenu4ECOywsPtEKUvhOXcSjj
lj4+TsqyJBkmdXpOWzKbEt7j6GgK/TJCXFjkG5SrZ4flTNnd7YspoHl580BzpSwkxIUJZyGec4cm
QFXDlXsGar1br2aR8mMqzS64S1ZyCmcZF0bigtbhQHSqs4SmCA8X6CInnMsrPjX4yHt8hbREzsla
gXIyFiJVzBCN0HXVrR2H0ESnHLWFftELyxulYzuJiCHRKegQvfMjsm+T4/0dmXIQ/cuyOeCBdYd1
Zyf3Cya+a0khsUlnq0MY4a3CCZ7qNnJHx4NvWXX0o6vmawceqRq4JprWqW2e7e5uEMHmYfyJn5QU
RTlQlLEYolOw1C/ZuO7c6WCSNtFXpo5lNnizSAOL3tikiF4XS8sjZk+8FLk81VT5eX7epZ884QMI
tqLlh3N2yXde+rMdih997VbSq+UCAJcKe44MYc1wsAtFoe3NxeI60JuFnOWaNWunC/lMJx8XMzqX
kuDbCYH1sqN6vbSO3oJHPJd7mPktxkLNhS4VhdaynARnkUBrurJf8WbSCPqtuXS/cruUBpN6uf5V
uL/4nkCIsNmOHc3udqzFrnQ5tQtRRh4v3o3Rm2P5ggVKGl1+/mnT4qCivr374Qx/JijVYAqRjsjp
8axNO+ZLvovMnELfZMXA5WNRMaactOqfJ6JxnMK89lw4A+5stJKk1baS1JxE53cwURvLymeMuHMn
qPLaJZ4J0lyCskRKNI6wgJlaClsIBAyV0l4auuKVBRuAu3bU55P7edNYHoSkRQNZG6wb6YF1ECxx
J4pz7PCOg0gcFwIbHyK83M6R62zfhJ2dtSNSqfOEvNuVmpDNT32dB/at4Mhgfx7vym9bhCmq7KQ6
D3qhMtR+ummSTyD8D5Id6XmD6eqlhIdOF+rzTN9NZfr6+RFN4y+4pP0k+TucJNUFrTpHMJPILvqB
nV3SPWqF55RcnO5NN8n//k8y1/Wd/mzd0D2V/5jzhZX7hPhRXzjxgID4tzbVIB6NVnn+cZwFHue1
wRRIMfWpNQK8hJoKXtZX8LK+gpdNFVAEN1Z0Ad3W7gcXDL1uohcUdCIZon+Go9Sjh+5xI/tPNNsY
2Z1vwOL7WqI0wT+Lnjid1+nWQFewX7ae0w0luA1hToBRnIFFw3cHmpOiII57hpxn2U+2c6GOgx6E
hGTNJHUwXADdIO6Wl1di6eeSnDhEE3LL8nFGLHjSebylcyJDWfy6oVPciZ9zx3Qv0Ek20W+9buzL
EZQv8ZOpLrbYmbe7M7a3M/Z0Z739OG+L20jc5FIjy9kGcaHl6OHu6LOd0fCoF35d6HfSbsZal9fn
6VR6txxd7I7u7o7uCUHt+FPs+k8R51B2XmDnn9ZGpsroE+eKTJRgParEFjvzdnfG9nbGnu6st1/J
2+JGYq6MGiaLzJRyqVH0cHf02c5omikaHUyWzY7JIjOluciO9W9jdHd3dM8R9MjJEp3QyBL3U26w
n75Oc5bTLPn9N7pEYUv90H6G+24Y1PrAOnEUQRswjS5SeawGuiPIztJwdXiRMIoNSZfxq3xF7eEm
wXJ4Vgv3pT1nMRpoawO7p3Bs6eAgE2x7QU9ayY5l/I1J1mtZwrfGwd9hy0zX+cUyurIT7/WXpGUm
m5AKSMp2HW9exfKAE7ELey2SSMxqFjSHTxbt13CzqaSa8q1toxp+AuWIBNOOfVB2TVc2aGbeB/t9
gWhN8pzAYHctwuVDsa5g5ycqsg5NsOn6OgwMy73Bs7pVMZpbPCBtPjuc7Ohy7i6I+ulQvbPrw173
jQ0UIYgKK4G4l/5F2B5oj5BN4h/RGmjKoJzuR8+JrGpsG9L4qcWxHgwY4pr9i4g2uziUGoAb/eSC
efZRoOunKtJAqYSYTQmoNzdebB9PN5E56V4k0LLc0kQBp2xBDaNT2gnNNdVhYLEH629EjMhv3TRx
FoBOIZpP0mDRtUZsg08lt3muGQaOFfKdWOg710ZgcKpbI4ep5ReHWmQky/eZwBPyE/vKxKRCyiCh
mv+0gk/xUKVxRMvq7pKqhA3lEqJLhUnS76zFZhcw/fr9t/xPv/9WnKh46aOJ2JklllJ0oQHO1CNl
WxkSXTKLfXFHDZrifA3mJrRUcIhWlaZ2QM87koBcTc+FZZRq3znfeSzDOxQMI5urONHfKGABL9Op
U5xiJ9AYQPXHZkxVMztpcT4wwbx1zQyAaSCOzvCANGDwOpKPmNDArTMkuSSVXSgSXUL5prKaSyUt
ojlYdylkTHOrXYu+kvo5yasyGXyn3LSU3fU5FbXDg2DumoLQzhz65ZsK1NUlZxozORczSSMmPI30
WvnqnpH/JHSwEmENqQTSghvJFaDcuExW8ppIP9QvR0iIPauEV/NHobi0OJqcJciUZ/Qpkrs8xy4N
1UHSxBxQ6veuqlPPkOkfR2ASC+qamEONkmfT1CDM6O8n6dPSgFfrNv34hnbqO/UpbfatJ6TQ69Aw
nTlj6VjwqXtcCfHFrdK8QGBt5/UZOGZUjH5Sc5fsv3iF5+FWJ6C0plzRwgYAsLrwtJJhsrqczSrJ
ObSaWF37llNLcJBcuzF4Q+QDuoU2MZtTWCGx4qHmiwMtaZ2NeG142qBHinNwTbAjpaJNaORUIixL
vV1BQwwyNR01d5xCra74wKnVxIFIqvvYSNfRlLV1daj94PLclnT2pwW7b9C/uBGf+M8qeLWcVT+l
88BR6WOcmVpJJR2Fes0FS/yI1fnx63jKK5eH/XV/cx88uGY+amFFUc0Icjvh5Thro7vgnb6EkdX7
+YycfsYE7bi0uKlTOQo3npEpy3/LyucXutIcJRWzf9g/+2f/7J/9s3/2z/7ZP/tn/+yf/bN/9s/+
2T/7Z//sn/2zf/bP/tk/+2f/7J/9s3/+vp7/A1d1peAA4AEA
