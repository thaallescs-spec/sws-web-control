#!/bin/bash
# Instalador do SWS Web Control para macOS (setlist web para REAPER + SWS Region Playlist).
# Dois cliques neste arquivo. Para desinstalar: ./"Instalar SWS Web Control.command" --desinstalar
# Os arquivos do script vão embutidos no fim deste arquivo (depois de __PAYLOAD__).

set -u
NOME="SWS Web Control"
LUA="SWS Web Control.lua"
HTML="playlist.html"
BEGIN_TAG="-- >>> SWS Web Control (auto) >>>"
END_TAG="-- <<< SWS Web Control (auto) <<<"
PORTA_PADRAO=8080

azul()    { printf '\n\033[36m== %s ==\033[0m\n' "$1"; }
ok()      { printf '  \033[32m[OK]\033[0m %s\n' "$1"; }
aviso()   { printf '  \033[33m[!]\033[0m  %s\n' "$1"; }
erro()    { printf '  \033[31m[X]\033[0m  %s\n' "$1"; }
fim()     { echo; read -r -p "Aperte ENTER para fechar " _; exit "$1"; }

DESINSTALAR=0
[ "${1:-}" = "--desinstalar" ] && DESINSTALAR=1

echo
if [ $DESINSTALAR = 1 ]; then echo "  SWS Web Control - desinstalação"; else echo "  SWS Web Control - instalação"; fi

# ------------------------------------------------------------------
# 1. Pasta do REAPER
# ------------------------------------------------------------------
azul "Procurando o REAPER"
RES="${REAPER_RESOURCE:-$HOME/Library/Application Support/REAPER}"
if [ ! -f "$RES/reaper.ini" ]; then
    aviso "Não achei o REAPER em $RES (instalação portátil?)."
    RES=$(osascript -e 'POSIX path of (choose folder with prompt "Escolha a pasta de recursos do REAPER (a que contém o reaper.ini)")' 2>/dev/null) || { erro "Cancelado."; fim 1; }
    RES="${RES%/}"
fi
INI="$RES/reaper.ini"
[ -f "$INI" ] || { erro "Não existe reaper.ini em: $RES"; fim 1; }
ok "REAPER: $RES"

# ------------------------------------------------------------------
# 2. REAPER precisa estar fechado (ele regrava o reaper.ini ao sair)
# ------------------------------------------------------------------
reaper_aberto() { pgrep -x REAPER >/dev/null 2>&1 || pgrep -x REAPER64 >/dev/null 2>&1; }
if reaper_aberto; then
    aviso "O REAPER está aberto. Salve o seu projeto e feche o REAPER: a instalação continua sozinha."
    while reaper_aberto; do sleep 0.7; done
    sleep 1
    ok "REAPER fechado"
fi

DEST="$RES/Scripts/$NOME"
WWW="$RES/reaper_www_root"
STARTUP="$RES/Scripts/__startup.lua"

remover_bloco() {   # remove o bloco do SWS Web Control do __startup.lua
    [ -f "$STARTUP" ] || return 0
    awk -v b="$BEGIN_TAG" -v e="$END_TAG" '
        $0 == b {skip=1; next}
        skip && $0 == e {skip=0; next}
        !skip {print}' "$STARTUP" > "$STARTUP.tmp" && mv "$STARTUP.tmp" "$STARTUP"
}

# ------------------------------------------------------------------
# DESINSTALAR
# ------------------------------------------------------------------
if [ $DESINSTALAR = 1 ]; then
    azul "Removendo"
    remover_bloco && ok "Removido do __startup.lua"
    if [ -f "$WWW/$HTML" ] && [ -f "$DEST/$HTML" ] && cmp -s "$WWW/$HTML" "$DEST/$HTML"; then
        rm -f "$WWW/$HTML" && ok "Removido $HTML do reaper_www_root"
    fi
    [ -d "$DEST" ] && rm -rf "$DEST" && ok "Removida a pasta Scripts/$NOME"
    aviso "A interface web (Preferences > Control/OSC/web) foi mantida. Remova por lá se quiser."
    fim 0
fi

# ------------------------------------------------------------------
# 3. SWS instalado?
# ------------------------------------------------------------------
azul "Verificando a extensão SWS"
if ls "$RES/UserPlugins/"reaper_sws* >/dev/null 2>&1; then
    ok "SWS encontrado"
else
    aviso "SWS não encontrado. Instale em https://www.sws-extension.org (sem ele a setlist não funciona)."
fi

# ------------------------------------------------------------------
# 4. Copiar arquivos (extraídos do fim deste arquivo)
# ------------------------------------------------------------------
azul "Copiando arquivos"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
LINHA=$(awk '/^__PAYLOAD__$/ {print NR + 1; exit}' "$0")
tail -n +"$LINHA" "$0" | base64 --decode | tar -xzf - -C "$TMP" || { erro "Pacote corrompido."; fim 1; }
for f in "$LUA" "$HTML"; do
    [ -f "$TMP/$f" ] || { erro "Arquivo faltando no pacote: $f"; fim 1; }
done
mkdir -p "$DEST" "$WWW"
cp -f "$TMP"/* "$DEST"/
ok "Scripts/$NOME (script, página, QR code)"
if [ -f "$WWW/$HTML" ] && ! cmp -s "$WWW/$HTML" "$TMP/$HTML"; then
    BAK="$WWW/$HTML.antigo-$(date +%Y%m%d-%H%M%S)"
    cp "$WWW/$HTML" "$BAK"
    aviso "Já existia um $HTML no reaper_www_root; cópia de segurança: $(basename "$BAK")"
fi
cp -f "$TMP/$HTML" "$WWW/$HTML"
ok "reaper_www_root/$HTML"

# ------------------------------------------------------------------
# 5. Iniciar junto com o REAPER (__startup.lua)
# ------------------------------------------------------------------
azul "Configurando início automático"
mkdir -p "$RES/Scripts"
remover_bloco
LUA_PATH=$(printf '%s' "$DEST/$LUA" | sed 's/\\/\\\\/g; s/"/\\"/g')
[ -s "$STARTUP" ] && [ -n "$(tail -c1 "$STARTUP")" ] && echo >> "$STARTUP"
{
    echo "$BEGIN_TAG"
    echo "do local f = \"$LUA_PATH\""
    echo "  if reaper.file_exists(f) then SWS_WEB_CONTROL_STARTUP = true; dofile(f) end"
    echo "end"
    echo "$END_TAG"
} >> "$STARTUP"
ok "Scripts/__startup.lua"

# ------------------------------------------------------------------
# 6. Interface web do REAPER (reaper.ini)
# ------------------------------------------------------------------
azul "Configurando a interface web do REAPER"
PORTA=$(grep -E "^csurf_[0-9]+=HTTP" "$INI" | grep -F "'$HTML'" | head -1 | awk '{print $3}')
if [ -n "$PORTA" ]; then
    ok "Já configurada (porta $PORTA)"
else
    OUTRA=$(grep -E "^csurf_[0-9]+=HTTP" "$INI" | head -1 | awk '{print $3}')
    if [ -n "$OUTRA" ]; then
        PORTA=$OUTRA
        aviso "Já existe uma interface web na porta $PORTA com outra página inicial; não mexi nela."
        aviso "A setlist abre no endereço com /$HTML no final (veja abaixo)."
    else
        PORTA=$PORTA_PADRAO
        while lsof -nP -iTCP:"$PORTA" -sTCP:LISTEN >/dev/null 2>&1; do PORTA=$((PORTA + 1)); done
        cp "$INI" "$INI.antes-sws-web-control-$(date +%Y%m%d-%H%M%S)"
        LINHA_HTTP="HTTP 0 $PORTA '' '$HTML' 0 ''"
        if grep -qE "^csurf_cnt=[0-9]+" "$INI"; then
            awk -v l="$LINHA_HTTP" '
                /^csurf_cnt=[0-9]+/ && !feito { n = substr($0, 11) + 0; print "csurf_cnt=" n + 1; print "csurf_" n "=" l; feito = 1; next }
                {print}' "$INI" > "$INI.tmp"
        else
            awk -v l="$LINHA_HTTP" '
                {print}
                /^\[reaper\]/ && !feito { print "csurf_cnt=1"; print "csurf_0=" l; feito = 1 }' "$INI" > "$INI.tmp"
        fi
        if grep -q "'$HTML'" "$INI.tmp"; then
            mv "$INI.tmp" "$INI"
            ok "Interface web criada na porta $PORTA (cópia de segurança do reaper.ini feita)"
        else
            rm -f "$INI.tmp"
            erro "Não consegui configurar a interface web. Faça em Preferences > Control/OSC/web."
        fi
    fi
fi

# ------------------------------------------------------------------
# 7. Pronto
# ------------------------------------------------------------------
azul "Pronto!"
echo "  1. Abra o projeto do show (com a Region Playlist do SWS) e salve."
echo "  2. No celular/tablet, na mesma rede Wi-Fi, abra:"
ACHOU=0
for IF in en0 en1 en2 en3; do
    IP=$(ipconfig getifaddr "$IF" 2>/dev/null)
    if [ -n "$IP" ]; then printf '       \033[32mhttp://%s:%s/%s\033[0m\n' "$IP" "$PORTA" "$HTML"; ACHOU=1; fi
done
[ $ACHOU = 0 ] && echo "       http://IP-DESTE-MAC:$PORTA/$HTML"
echo "  3. Ou rode no REAPER a ação 'SWS Web Control - QR code' e aponte a câmera."
echo
echo "  Se o macOS perguntar se o REAPER pode aceitar conexões de rede, clique em Permitir."
open -a REAPER 2>/dev/null || open -a REAPER64 2>/dev/null || true
ok "Abrindo o REAPER..."
fim 0
exit 0
__PAYLOAD__
H4sIAKIN+2oC/+y9bW8jSZYuNl9LvyKH1bVNViVZzOSLKKpUs6oqdZd2620kdffMrapRU2RKYhdF
spnU29RqsYAN2F+MhYFrGzD8cuca8IUvsP6y8DW8H2998t+YX+Cf4Oc5JyIzMpmUNN29g2tv10xL
ysyIExEnTpy3OHGi9rD28C/f9C6eR71BNPvFP8u/uv5b9rtebzTTv/k+qIdB+Avv4hd/hn+n8bw3
Q/O/+Jf5L+x4J/PhSbQRrK41O43marNda622242gtfKLn//9//7f7je73jfRgfd0Mp7PJiOv6v16
x+tPBlFtdNr7Cdd/u9lcsv6DRqPd/EXQCkF19XpztYH132yG7V949T/n+p9NJvPryt30/f+j/6pV
7y8HUdyfDafz4WTsLdLDySSez3ozSxfetDfreb2D2XDm9bw4mo+G8dwbT7x+NDod9WYrhNg7nR9P
Zt7ecW80imJ5NZ4Mx4PowisPx/3R6ad/GEy8aTTCj15/Mo+8Uq5hkl+pwpqbB7PIOz3ped/1xtGo
h06ceJOkNwATAe4s+vTvJt4g7VD5eD6fdh8+3H7TnU5m897D6ah3yS+14/nJqFITyFO0FWEU/U//
9iTCqAbJKB7OewejCGDGPe8kitH6LEJr3wyrXwwrXsTx99CL0XD8QUA9HQ2/P428cdJLxdJoHs3G
wF2EMUXe9pvYK8cR6mEM09N5bwAczYdn0cw76Q1jb6DjZEuVmrcV973DqH/cq62sjCb93sjb3Xrj
mX8bxNuH3lFU60/Gh8Ojbnx6UA58L6jYsk93tt/s7T/b3kHZ8iA6OD2qHUXz4fhwwnKl3VKlFk9O
Z/2oe8S6pd/9ZQmvS5VK96Q37x/jRbl2v/L24bt370sVDx0t1UoG9pvNL7eSfpQyiC3Zvn4/w7fB
5HA4ispOX2o1GQV+lb6fRWPLaDDTwOKf+I94f8O55bwPMZOzw14/8s5BROVZ1JtGs9pwPKz8AMA6
hMPTcV/WBCCynXJlhUM2HzG84aQ2mUZj2xjQu48G92XMFSBzdlDSKsNDLJA56syPozHmd346G3vj
4Yik68BEZUA97ALeoFy63zO1D7v90SSOss0PZ/Fcv2JqQIYRahNA98hM39vfvZu9G79/gMkbTFYs
3Whtrgi0xGrJbPfj09nh/r3Bg43ne3tv7sUP7lV/hSf8UcaviumLGY0A4GCSl+aDgDzESi+TSECP
vjefnUaVzMilth26/Scj4vDlNwbFUkkJW9r+NpAUDXz5w8iHK3Jg1rag5oeBmc6Gk9lwAA26qyzi
oUDE//u9uOeVg7WwFrQ7tYuK99gL6rUL/lrlu2ojkKdZFM8nebqb9cYfysOpO+893zsg5U3TVcrZ
uVdzJ8kUmk/GpycH0azcAzEmDwcJSfa8jQ0PXfN64wEr4KHdyUxUkOA7KV7PFAgXC6xaeI8Jz/z9
aMNrBJmajfxUNu00er1Bbyq8MYq9s+FsfkreWP5m94XvPb/EQqt+7Xtfy/vRk8kF/n553ptFvvds
0v8QzSogin7vhOTjffqnEXRbi9evt3f2vtp8Acx89EpnEXozG0dzcr3zeMRfx4R+r3rGv7Xh0cHk
Qp5O2AT/Gkgj/Gs0mUwPwIT5N6Th4Ei+n85Px/zdOx8IzNHovORd5Wd2GJsBQL6cRDoj/Iu8Wn6T
35Yq3dHkHFNWSRb6vu+dyUKf9kD5ZTOizAonrwEEXYRn2YXHpbh0KfVGcaRzkOusPGKlZBjQOXqB
zpKZY9ZL796V3K+TUy5lwxe3LqL+m9mkH8VxmdVIEqXhVAVXSYb6MD4Yjh8OD80732tBMVSpU3LA
Usz4EPHR2FcqiShlPl758p8p6jJE9OMGhgh66/cOoD30RscTrtiE+rqEckyN4gQj6Z9OQIPA6eQ8
9kqbthAkWc3rlryH3ste3ytF43rXOxz1juINfMjyTEqADMe9F6MrRIb79h4E8yJnTQdrESgjRPvl
DMjy23vn7x9Uuiqx+amywEIdeTN1+0fI17P00vabs2Ypz9SH05woISu6V8v8AGfKtB+R1jLt5IEA
O/fxODfyZxFe4bjQXUAifohtEsrb4fR98sJhm0G4eq9m8J//1F67VwtbTfm+gJEE6IYgIfON9Pn2
ruifD7zgvXAaGdlwCrLtg6NxVRiujiLllA+YGdYOgcti+rAArpYKQNFPocFBLdFVYZdrGRzxMkN4
FzVt+m83vEvzp8sU7OdHyVcXo0khjIMlDM2giLveh9NYFmKyAIe+FzmMil3ksmPBt0MiJiLAHAvC
xx8hy/9KFO8frO0ZnSjV9dKRkTRTHmjeDy74PjCPoJ3ZEJg/nY0W+OfB6XA0KGc0QWkMaLoriNvw
jFRVKAAL3XDdYsUiCaDxBbbYcHxUA45RuFwyVs69uHsvxk8sTsHw4OK9L434oqxnWPMHn8QDUN/P
at/PqIGXAVqLJB2YfBBCZEF0E92RibEjMSP8BgIZZZvNOhh2u75ydHhBjRvdWrQi1WBMzUT0lNUr
UglG2yFKimGyORv2KDmDTvZb6H5rVRaw3I9oAexFF/Py/ALjvsSSQD0dlwsofasQ5ucYAwucRD3o
wFDEZoSQVsS08tcligE/x7WT3kW543tlvjzH0ObnFfD/EErWZVJnMOudJ4AcoTrqxXPYiv0PAFZf
GANrZaRs33QNpgUMwVlKRH0sRmESfZJPuKr0w6Lfn2ICKhnqWbGCTo1UY5XCDN1+Y+HJ+CencbTf
7029v4DmR11OJU3aZRIqXwnZQoXNckcuiQ35eU9LgAcmH91FkFg9DjIWOrDiTly5XqsD5fi5xp9q
6NrvEM4ogPc6T+f661jKLCy6TI8t9IBABX6YQOY/h6ZK2xkDE6xsZ2vzzdaON/70v9Cep95yOgMX
r4E+uSAcME4z5v/FTbyZRYcRreKI2DVr5+Hr3acP2eRjb3Mw8B4DfAfgw2IQXHQHM+goUBZSk/ix
V6LJbUyyejOpTjlssGOW/g/GzyvigRY9XR1DIa6safUjEPN19B3JNXX0QCW7Flm1LJYy6oauLGqv
d3XMuS9YQBElQTP3Ph7+PkpYwHCcLP+mobtj/B0065VcNfC7kcs5MEr5+xD2w6wsQB9C6cdi0Ybv
o9OVPJD5ZN4jFAF2P188V3hyYdvTNlJGRSjKq/JVyNzC+q0mJllytL0ml76CTX4VTK+uzezUU0lg
PwF77Orj9tvlkm9mPevMvb14//byPaa/vqinFXSXGtcFZ8lirwL0EaUcBz9eFn90fzpDKFJA88/u
37ekdghj0x+ddXDRdjFaa20uyXYoP1tLV89TlbhegSsTBk8MD2jqjuTCybTdbGd4DVBfzPxzjebU
lB22eG/g6c9EEomTFOu2L/oAJIcv0Cu5PrQ7mT64qnAiBE6ng97c+siM4TkghyhTqBoZbOTrz7s+
6b/az/u/P+//pvu/q2thWGvWW412Pfx5nfzL2//9CXd9b7v/26yvhqHd/223myHWfyMIWj/v//6n
sf9rd1RlXy27PVox25zeTnTEym/MViDNIwBathWMDc+YxcMatkDkzXQ2ORsO9LPnZXYU9ZW7WZh9
U32x/XTr1e5W7WSgH95iL3X83rs2sEF7dgD3sNZ5KXvcHjUhKb18TLppPe6dRUfi/023jOFsVq/c
vKtATz79U4ytCK9HBx/04+hkOpGNnh7UJJ+bdf1hb+YLDvlr9ukfL4YnvYf8zA0ldGdO1ciT3eT5
cKZgoUN9D4DQn2ZJE7qpHmMr2b6K0dIU+70D/DVOtsVl31vBvNnZfrm1vbPpfb31r1LPNsYAR3bF
jMDzgpq3w2129trrffp3NPK4R30W/d4rb4rXgspg4e493u+cjrmTLbv202HPQsW/SXaWlZAmRnPb
Pz8/3+eC86gjxjGnQx1I352O5xMTAqAGeM0CDWverQxor9hILvlO755Fh73T0Tz92s12N2m0YfBT
upbcSowYWB5s4GzwP93bfv1K99UBEQANPLv1/nzv5Yv9L7ZfbBXsvGuJJ1tfbr/a39v8kiXQy8eP
Hy+shTIW5aTCT7bW1qtnUscztR49erSsFj7ZWrt/vf1mf/vly61n25t7W8YjLq4m/tH14NEwNL1p
aLrkTTHiE5IkuEJvXbedunQMHg5P6DBISDo+AQEc09/+waw963t9+nzr6V/vb7/a29r5Wvbz4JdQ
D1ccHZ2CkGMTcAFGM+RuIOj2/wBzsQja3EsrS+1WYe14ODZRGdgNPJuUCsIwbhGIsbO165Y2psmX
0Xwn0viLN7DUy7mwjTebe8+9PzVwYzHygyAciDdHdnyx8/rl/u7eJrYV38j23je7+99sPdl/+vrV
3s7rF+knnerKytIC4jO2PQIhcXdAsbz9DDgFkrGIe4Jtw1jL0xm2VvrHw4H4d0aT3mD3PH46OWGx
+IcGiGzu/Pqr7a9f7/6A2gvb8TCRvmBsx3RZIMj0BwR9DG4O+TB1B4W7s+ez4TzSbvne4LqenV/b
M1mISd8OuwK3PLimP7L99SNiL16BWF5sfvovPv1nryHABhSPc3oQut5sIpFcJ1Nu68ef/tE7OR1Q
OtBngH5CYav8BPM5HEOojUbPwTzLJ/FR7OJOZNJGOuWFIUwJM86gVapmfCME/vYuf9ptwdLm19u7
r7vqlk15OsOi1KF8OBlaZyrUDK+HUDP+xv9VVauVcjt0Wce6btGfc2eD/MeJusoJ2JLrL9nBLveM
SsRTvJhHz4b0m01ml2WUho/JxQ/9RtwtQxMF+LDoSNDH4hVuQC4ihzvPCQmznC+FCnZeC9D4x7/7
t4U4FG2DEYbUKgqHXLgLXdDC1s4O5sk6+Skhht7RrHcGtUwaZo8LPVNFa9VQ3C4IeH46XSC6WN8v
TtquzHlcct/t75viomC4e0anM5dyTanFYIoD/OLOS6owEOy7cYofPOf8eEBpylvuff+OoS6OgKm4
VUuWBEhajInbjy6grMTlQxM4sFx2kLOs2+jBQwkdyPWrtPjKqjB2FM5Qx9G5O3A60k9nGtOQjD4N
a7DUe5AlQa28z41tp75pFRFXbm0DIVokYuPP7w3JXsoEQyEekd4qVqC/m/1KMCtC3a2McZi2jZZx
QId1hUPW2cQfBL1IkIsbIEej08h0gQuzVEpCIQjfaArvxp+hDxqxgy45NJTpDtsVeLYjWf8sGSOK
Cnz8/luts5wLGJL1Wfr2fGBb7CmPSip6zxgwCpOMreCVM6um8tOyAgP51twANkmyqfgclkZm51dj
QZNVXBhi6q7pPy0M1Ib1FAd/umFJQuQJd83F/hRQ9o8LLXW0i7JAYj/Kpc1ceO93n/5AixQ/nY1X
rdHTuZDK5ASVWqlSuC9kzFAg8FbQi8Aop3mTxsOn4Q0+dRhae8ZmfrfcQHxXcoT5kuC80hfUerDn
Qmt40vVeT63lfSuTN8883xWbwO/Ac6B5vystmL/vYMEiNmiEcLgMpKzYrb0bvxs/i6YTWE1/wvBv
MI7znS+/mtBHwThA1ENYZh9jgIp0NowlgA+TFl3Q3uODbHUZ34LyAN9uPnEPOZqdDOFYqYET/HBF
9sXW9t5XcKQ82/TevNj87Yvt3T3v2Wu1aTCO2mw69eLe6GzyUyitGEscWZ9UXKaGGGXjWeSDb9QA
xkWOjUBwWYSpdzObWODURewDsXqP8d9nRfFyNi4u1sC4hJ0C8EI57fPYEWCFvNnhkgPfYxxuXBA9
qIHR/E1uc79SsIAZLjhYvnU8HLhR1MNBMSNRIIh2rl80jWfbBEYOJBwGpO58yW8WO0Ov0e0wjIAo
5yENJJypP3IjM+ikd/JCBELgRA3eaos6j15F7Uw1/DxWH+3+xcv9nS9f7VtSJ4Zr1YpOf55KBEgh
frFuVKmcGPu/6y2ABj9FKPTbgE4W64WFZD/rvS8CJ4Up7aN42mOQyBlWuHpySt7n9Gx+u4SKGC/t
S9jukgLfiyiO545zp4AKvqdb5PPS55wE+bv0eSn9+9vSckIzijtNbNuSyN3vse+dVysz+qCGjGtF
isqkk6Fv3op+iE6kX4pBcfTFoPSV6KdOgG9FXUf5tbp0vdru+rYlgZ8eYtg1a7V4oRatGjP4NFx+
CTv56JZE3HifJ66o+WpHMDVBCREHdr2Jo+rqxoCOnIAW1uZqef1e/zjSmNjFeHoodbPJiTpt4P3T
8SY1ROvb5OKbxDWJaijde96997IrseFXVqVmTel+jrAETi2acexwwE6+i7DGsCUCDSlxLYg4gi2J
X5FXfjqfjR7sms0cbDiA0/Scw3238TUYeeKqrOnIjGPEllne21e2f9NJHH/6h7MI0kyF+wwhOWfC
KqY6ott0SuXNxrUykwEtptxGPowo27dofMydjyXbQuOkZwa5t0HaMVbW2D3cMcrFTMcLWnvN0K9I
GAVALr0ObS7qfVggTx2CdJSrW8uLHkCJHLx3CvUnpzKBdx1a/kH60A5M6k//DTwYGAK3n+C8OstO
HtTlaDb/SfSh4+ji6WSEKLd+ltaS2Nj6Df5XqOpHel7K2FgCjuvzFWVNVO4jGrV+8YX8y/g/c76R
u/fq4YX9D5q0AVwptP2O6P8nIcVl4iQTj5xG0meD/5L+YZ5kXffnL3sznEZyYUjwPTc1TECeRLQt
HAAEqQ3jnaMxg8ShK86OxltjaBXKISUOq08sOGd4oGZk22xIoyid8XgI1EVBN5eQ9EVmLCYzVyh7
AZE3jI/ZpumO7UM6x/x53akI65n+MccIdl+/4m+GsWFz4kzCWk+w2RbNGN9WlV1nzHuJmzM0YL7a
2cYmBQwY8raxszesu6gw2Ib0QBCuN8b897gT7B2AzfLUKraouEmrMfnQUWCZ8Ggxg2Z5+si3O6AE
BXMMq9+cm966mMOPCKMp4nP+AOzA3R79sWsMQy7HGdIvzydK/XivXqvP3967h1Ng9/rvP3fOovQr
+YMkuUVz7x5Wy2+wWvrdg0vG7yUR4pXihQM6LI8ry6DVGoeANdbDRoXnMDgNhnJTAWVcF3j7yhzC
E+GausXkOVF/3v6Oe2cPKp+pDiRw1BdT5mGx+ad/mJ+OJhXX2XoMqbhweuPz0lSXVKlb4tmN0gCH
gS5LOMrhl1QHsB/i85ivP/cdyu+XbYcrvoNlWa7bsVmszwhR2QOHo+H7JWqU6syTXZ+SnxN5RgER
rSr9BjFXM+dCFiCkkfap0MxwgcIJ+/xjafKh1BUQPkeNatgjlkFfgY6INV+GmkBNCcR18KptRFl/
DWOFe/EEbOZkiBU5PvITvmrPD9aTgxIvTZjskXoiJOyDuhEhgCP8AXINThg2KtyBbm2uQ424UI8H
kV2z8DaBKexvefDzQh4uRmhUvE//G8gvgjfmDL6mLtjFp38YD4ZYzD0oPvw6kdjdiYVoP9ORYeNS
cJYHqpuYQCUbTILVcBpzJwSMqZSNJgGPKdVc5cM9sJXqDdYQLThGrvJBkP2WRMO/3rvSYCbEAjhi
rf7tRlGctnV3kvvPIzkZpsVxwKWg4NjGtvcO4rIpWikoNxDdv8ydB5EqVW9WE2nDsO6ccDJ0YMON
BznPhNDN27vyy5rjWTpesDxA2IoOrNqBX6KwS5YyO6FrHESsf8gotKhFhH5AV3pzBYMnEX/888ph
BAlDMBOg62VWk4PFvvBLO3L7pCjh4yKYZCKKGYVAQK8qizVnNZXXwi9pBsNZZ9/hT7xRHjk+HY3c
45vpEZQCT5NZrPDE6x8W/4n8scO+Jjy8kPWsOFNFHsSRCguyngY7X/bZzg+poNR9ey9+75dMp+yj
EFB+fvI8TNaUmRxH8U4r6MlOGCl9dNPwLPSj4me/JGxMv3Fe9HxH5UcoP09fv9x89ez1rvFf8pU6
MsVyJPczTEQ44atSzdubnX7PUJ/RkDbjRMN1EE88GBrXjnJjydVhMIkwBRTlE3af4LTB2Wuyp+A/
/pOAZXoVHHY74baKFII7d274TMl7xdAzDRRMzjNIabjovafcBiixvIjtHkLVvO29rZeMK0o8SOWx
DWIzDLwikV9gc3xfED5HBQJt905qnnFuo9hkIM5mGe7ZhM75nsYnwHv9U+hc/ZOBkxvAejtThZxy
f2CCY15MJh+wnZwWt1oaKnA14hd5b8U+OCc6i3wTTtSN2ZKi5Cf+kigm9q60T38dfXUZp10prSIT
t6TKq63f7C2rB0l4tqzem52tr69r7yn4/tL2nn61s/9kc3frWQ6CylTSueTh4ZYCtOlMf5bBlf4s
g5tAmB+NdkkpBRBYcv81NtD3vsQW+MvXr/ee725t/bV0ygh7Bl+C3OgHzSyvBDzfvpqcXws+Bb3/
+osvnL6x8q7G2t2q8iun7uSDiRJT8iB9JRNvH4g9JT2JDgTxaaoJC6PfG2+f6IgiC83iy8KwA3Sf
tc9FkAs3W4fz46QZwi4fjisrWXe3ns9PewextNBBdY3aGL69ydHRKDKrRcwxt/uicgd5PVjqvoRD
bv/12NQsO2NMAm20tO1VkmsgNXUFEPb/zkCsX23vRIcofVwO8oe91X81xeMoGfOyytWgsuK47p1U
Adf1WmeCHXfTwVCigz7c+rvHk3NsAMaTUfQyPlo4Jm7ioVLZDnXfhnNU8tvo352eTHej7+UcdW6u
e+MxRGo/+isUKUvWMR1VWsX+ZU8o2/5Fc2tWl00sLuQrC0PzsXXYoa50VED7SjDF1ipXBV1Jphe5
HQtNiGZFIARq3cWdWV+u98pit4CYrcVduQWlsVcZMhMDQA9cap8Gk2uqc3VnJjtJBlGE+CK0xB+G
0zKM3cotx4sS5XTRUSnQOarwoLizypx6imFabTTVTNCGIhpKCuhQ8rowiD6aZUSsbRDdSw6WquR1
RQwQljA6arBpCSssTAmRZc44ciHTGd5w3bQumQ/uBepMFJx0vq5KNjLlBwZwfvqvnm6//mHKTl7N
sHk0GHAj/s9Fqli5PpYSUxGNY050orAmEZTQDbcl9k62/eFNqWppoLY2mR3p7v9iPGhhvB6H/utT
hi6beL6eTWWYPMqxEHOkwvdszKbx/kkIx6nUIKjSC+ACWnJPg/xK6leQ4yj2oAUUXWqu4hU0sezq
j6AePWX0CZNDeKNPf5BzCV9zmPJdDveaxm3iRhuSMUhzKFJt5WapHK6oEfOZOHBH5CGaZCc6mZxF
SX/TmTEJyvoT3URzqJDDwTobePmAdL+g0L5kDixOGXj9IQuFluagAVLOIhpZOK1/zNnx1LchXcxv
rBTEKZqKlZzMX5QQ0pCwIdtWUcTEUhSWxfakx95UtyFWxQ6Tm+RVdthF28fL9jNtAra/YgCUOrVI
gv1P/4hoWgnKBkX/yttSS4lx2dPI5KyUM07D3xvaAtH1hjWzpPH+LNpzYxWuw2VJiu/PGfrInHJa
WXwKphpPq+6DrfaHDEhnahkpg4MpSEeXYOtaiQ4tl+GVM9V6SokId6RRZgUUxIEisQuVVeVEj41j
tZy10PHJN8qLajHyp6Z2W8kHkr326P0bMnAhDUAzOMcKMIfwLJ4ZkJbn89Su4LmMcRgFefE0C05+
yZQyvN/ZnZS5Lxq75HtJRrmA32ybSZdK25YX/lKGrZGpNyGHfy1GRaZcong0PyJy6/XrNx7cA7tb
X34FtwfDt169/uHGO/PZ/HUE1Yp/iOdd/xTy0z9ld8lJBXQc9T/olycIucd2IX7q7l3dL0gQND09
ABkcL9nA+C6W+KDl+xyYXykDxmI7U2idFK+axDPmC5TMqrHpfATkhny/NvaVHs9MvOt4cp46N7JL
3EniwywmFlkMucqe5couU1tsg/XSPET6Sn65+YmuHbnlSX5qmwBmZQED1wJhky4EPmdBZHI12dNR
Z0M9JAXF4dMfjnAkjb42vmGoBt72h/1RctAhxjYk0jh4s09/mA6NgEszSV3Ld8kTMwkecQzVmIV5
o7hvdsaKSOdZhAOw0VKemycZpQpYSPQ9JOFApDS+7Eqk0WfZPIpSWrTyxLpKJAu/VRZ8yxIHYNyC
UlHsj2BJOWrsbrnqsoJWfGjZLL70BEOyxMVKXeqgzpC2lgdt5045LhC3BUzqzuf3TdZ94Q5+nBmT
KSa/snFUCuxDdCl6W0K4uptIpv03GmuNmrk6spGZtl20HZnPrjRX949j5mkVoaOnx73xUSSRD6a2
m8BzJxp9+veeibT9XlTzrqSVgZrN8F8NOnnYO+gx/IvHvsV1izAdBmrjqSd75lBmhqe1/B5XNNOt
2zLxYBgnmLzIcWfOV3JR5eVEBqSZ1Ab2se70XzRDaUPIaDE4LKWTZLhwW9MGKDPkUUI4dNORERPw
mIgNlA29MbyCx+jGxt1u46gKOoLu63SY4WqcAa0aGYB5q4NbUE+XiagMxVsaXiotgfAP/DbQ99Kd
/K6Ok+OH4sQoAuY9yl8gEV7OL3ITk0oZvcOobqpkGPtijZvEaH4PSvfBk03wXeqD95427m2uTown
gxNn4jpkgzx1PYkFLTL15/w/P+f/+eH5fzrtVq3d7LTXOp2f8//8C/iXySHxi3++9b88/0+rHuKy
F5v/p9Vi/p+w0f75/pc/y79Hv3z2+uneb99syanrxyuP5IT2COrWRmk6rz7ZKfEdhAN+nURz2WxH
NPV8A5nuD6udkn3NzecN5MmIznn0rmSDvTdK58PB/HhjEJ0hXKkqDz4DTJDItxpDwQLj8ZH1dSYP
dBBsjCc5oL3pdBRVTyYHUImqUNSqeFFFlliWdhq6jOJcxdtWmQ/no+ixcbE8eqiPK4+M4zSe9QEK
PvTadyj96KG+5vf5Jct1SRl0d1arB0fdu/WofhgE63iaMiF1926wGqwFfb6QszR3w144aIR8hooy
7949DPk/Pg+GJ927a71evddeF3i9PjeiUWXQ6h8essjRBAAPe6vNAZ+wQzft3u3XG2vhAZ9xScG4
ezdq91br9fWVq5X7HxFFAZuxW1+f9gaMWsVfuNKgirSjfDhgWNqsijdXK5x3/2AyuORQjqPh0fG8
G9Tr99Z5x8HRDKr3oAt9ucxRVtYlrMc8cxiVdXg0Z8g3et5FAo9BNOYAmGm5egg/5OiyG1/CnXhS
PR36VZ1PfeFDyzmaRN5X2yV/Z3IwmU98SfLsx71xXI2Zv0VQgTn8MJxXlVKgiPXn3TEibtcXXtiS
8960eoxBjDiQqnYXPvVxzBOD4zmxcxcd+TgYxmSB3cNRdLHOH5gFpj2AzthFrdOT8bqDDBzmeHgf
WtfwQpzxVEtPY0ax8MghtO6HqRPvITde4Ty+/3DlrpZL2pKO2gkJ6tMLZPiconWi61wb4wTKMxPE
doMWPhPNVSioR+iYJNq8soBr3M9KoMsB7PQbevFxYQpJOJW0DOlmsRDf2pm+C0atg09vS+hmM1xx
pMeiRS6CkqVQScfcxJjDZOAJGc5xdLsb4DV2iLGhpnXlFoOrlRq4QzT66CAlRFWo5HNSAJLwEHAt
aEYnGeLEmqoo6mT2Gf3VPZ0yWLIXR8AAzgiRHhy4feQnmpZDdMxvnZ37TfS1kpmbDuaGnapawqgF
rXWz0Diwusc5JdmeHyOgSToXYdLPZ73pwjKRriUvkWIW+U+HMTqGAPGPpoEOcZSi1HIQgzbYBcPT
mC3ngSsUWJKjj+6CFiZMRpCfJWU3xPXMoSdZGd9BTA4PL6v23KiMqXoQzc+Rs2ddqLIqsWrdA+CV
2Fk/6k11jhQ1VfIqQYysMiKjyx/o5Cwie12YggYK+21MQSssmgJ5RseHMMKrcG6AV/S78DHz0DCf
4wSyhyCxUYZ0mrnlhuOZi1Rj+j2KDuddUAPQEiNLzUdnHc5YebFibuHe2NEcNbVMS97BxwU2izHR
j+WOZQ1NLOt7gvMfQ4myyV3YF+EH6oqHOwLrH2cfEro5wp046/xRZea7EYzgqjLUuBsczrwQ/5nf
SirsZsIgwhzJB4OwHjZvxynQCfjAUQI8Tcorw80uF2nO8LZDyNYUoWG9gBcnHQMheB1d3W7/Gr1G
1GyuM38OICJIkAx6nZ4ZkSQznNDgYaJFpE9O+8fVnsobeHyHTI/GB3cYXT3z9RGbk4DaPRCyG/M6
nQD3lGDEWsyQeUYOuLQYFBD9hIxzftmtdVouzYQkdwsVzPvjwkhAo0eTRUZ/NCH7oHhZKnRqx5PR
wONO6ygFi2hu0MY8WsceOhIoZpjT7OigVw5bLd/+V2u0wNMTdi5q5G/KdeddFddxkR1z7ZoW5Qcj
iLXlheqBqa79ST4b0mJlH9dTnmDjmGTWg/T9S4nU8MrI6q6KbbfdBO1UqEBxISynffzHbeq7B/Mx
Q7A+KpU2ruTNK65vfdO8WtFFptv/VCX410dy0G6QEFP1ssusJ4nuk7yHqjrBOgbdCp1xZibjoyxn
d3m36hW6HJvucmwZeb10AUIpDWHG2e+WZ5qvjuKFPoDlfcTetMFZ2D9ewkGvZZl5Lky4UPotapzl
HCwKxiW8roBLUu9gcL7LcBtFDNdwGgcjhiUsSukEqyircoUOmI/XiZHObcSImd7aANzuY7Kwm/a1
yI0MTz0Mm2HffjY85hqlwCnmcRL97BsOIvdKUedwWYOM9E0H8gUrZH750WKFS0hpbUHhXb8BRZa+
s1zY9nyKi0aiwUfkfBU7rJETHuBc6+ZbdXJ4SC5UbRCmw4excGhBDlLsNlqJFMRdhCcm/mHhpA1P
8ZTUFDiOonnK9w6HF9FgXZZLfV0IWSw0WV31rNJXDxthx2LQMOmFEaxwP8cRVfIDDK5flr8ewH9+
Vo57h1EVq7FXFW5rVnPF5anyF/nWb8tBUL+3hDfWgg6SZULhqwJz67+vSshft3VlhimpBx1OSzFs
v+3RyM6rZLdW3Bf1/ujEQn4lbCBd/3ldj7pjRltv/0j9SFr9hibUNcNRY8qIWDPBXNWuTejCKrTp
avL5yXwc/wlaVqpdOQLerBYL7sfoS6KALtWXOkZf+lGqkNNRRmMjM9DHReVLFyIjZqY4L4e1dgi/
DIzRH2jHuLLQVU05IJndrAaYsXOdRVqoo67fIE2uTN+9mux/fVwkJLGh4mPsx37o1vPYT6rfpTPM
iEQQlzylkrf+Y8Qicb3Bf97e1otNHBhCEqTNZ/hDY6DmD036pkoX5+l6zPY6Oh33mJcosRc+/RtE
OTECd8DM26ri4B39L8N5z0DHPFo9Czod5kRIojti2CgcepFG55XTUWH8RgfL+HeuWSeoy4t5GmJv
NsN7FepnubJMlSVKlmdK130Uqki2uXW9hCRTntw17paMg0h/lXAbKBi9jBR/c448/iiJLmh8RAKG
tbv6Qr6xmvOFj+u3cFwRKcaqrC8oi3Z5q9FZbEnp6TWsIaNV3aLN/AIzyyirNyqzu4WWvKSeKM7o
iFGTA1Wcd2l16Jvw6lbKtafJLlzU4jGDtyvxYwojSUvxhU6aSHMR34JUK8GVFHlLFO7FoyOpc6+S
0Y2LZHeO4YYinPA/GgEP7ydp5gdcHYxwmIJhyh3jOCSKuKJTbA/L8SXe5iN5Am67dmC/mOG2Qrt4
zMTnuR5HveiJC/RDgTMtTB1A3dBKWym74PTh8hPwdD45ospUUOdLjnFmHSdUxgA57yBpZUWfgSe0
15PHhLcb4958tkLRfl1Tfd1l3u184UVXkx2VaKZZpy+liJUvUmacVV2CVfNe7IPsiBy6TDRnwqy7
n/IjaDslrCaa6VHofsspUpTzOpK81uB6bQoxlKFfBJpTQE8jsP7xUiLlLtKsN5wv0mjK4HM0mnjS
03FYgsxQYGcpBRoCVwrKksz64rRYCupktYMl1GORU0AMoel3IQ2sKQKzE7rUG6yq26LFZZiKS+xr
BlHrOa21SNpj10s3ux49NHuB3CnCr8EQ91EPZI8OO2nof/LGyDxsmOFN9hM5IErjjc7gYxGg8hme
3zhGCXKYUgIneiHPj99IEIyBmNRhKTPRpcd//Lt/XfQdfnB0xXmiV9x2Ll/BdAJ8qPTYxOgkVZVo
So+r1W61+khW+2N7pwewJM8OvCxEsrAEJK7gsIFb3qMDAQ4lmZAfPTx4/Ohglhb8glcjmGNLWD6m
NB9fCCq1M6hl23QGVIAMiYR8bO9mQOK9A0XbQdpznWdODR9AzgaE4XKCRJWvQPnf/+8GEfbmkhQR
Wr64MgR4yWLmaOLRxWbmyLw8dOeIbsjHf/xv/wOOHW0/3d7c0SYVbYDEUPHS4/kETCVtXepc24lX
goo//v0/mBHYvBm3GgEVjmQE9G7ebgx//3/hJs4dO4LHTCQ8u67Tjx4a/BctJeqSKWGLK6X0ePPo
tDeTkwNJ2tM//t3/miH2zFIlQy/liCS10kuP9/KJQ4qoKpEZSxdhYtyS+DQRGJOVyH209lyTnNuS
0My4ixY1b8qUp5Tky0GPXFBqmcwsNosdaS+uLVnKichKF7QzlfL1qdiVyXSqmVl6rK97sywhFNT/
cvJDiHnv9dPNHWSOxSUVtyUHZ007c6nyIYdwGnxLZ0OTDdnumSc1BB//8b//N+lMZBhudgWY4NfS
4//nf/7X/7m3aQ6nzLLUa7u2Yrv7yIZQPHzo7Z1KIgXahJ45S4SYTeWKEtRujm5CVR6aiY+pMw8/
/eEsgrJ7NJocyC0tovwyRsPNfVXGAaGNxziMZq1VhFW/fvXF9pf2CdoHc3nPk6t3Fi7eWXdiW9Ff
ycKjuUaTxDomUOQF7pVSYM9fv3i2/5KXnmDLYH1Z7mlA0zuhZMpltcqIhTkgfgBmsF4RZaBuSg/l
KpXlCa0JVW9Y0aSqSF9N9MhZV3NplDmmKDhe0du2cPJ6STYHBqlSXmRKLCZvYDEGzmeKLeZqYDEJ
WkHSzXrQLq1cra84c7OFQ0c4hpPODRwJcJ7SGeAxbYyvuXjw9Bb3m+MyzyQLo/2uKT+rwbpUndqT
wnqkBuI1+WN3PtOrjkpalJHHe7JNAcVz05zBcc+QCHj7QguYRhB9y30lLbOemYmPmkwPYevIO3jV
1bQpcgc3wih6JxPJUc2DHmCv6jPGKTfYhYX3eFWSjvJ8ddIn9WubUSulSLqfSHOIPsPwa9DjcCe4
+fqZpiXGuhhM+qfMks+88lujiH8+udzmEeFKZl6+2tt+4cxKcorn8AQ3vYoqPjws/3IYfyGpg/DK
+5u/8SSDE6LRFVOe/PHSuflYnNXao+PcJxA/LqCs43TMSf7LPfmCAm1+jgmUL9v1FJqghsPbNUd1
KjXovHKIV26Rr5ekaXNW/Nj7Ff57IGf6H3g45FtxHmIMpVvwkuFD6a3tEdPjfcQu16Ukb9XLehZy
A3LE3hWc8TzjElWSkjHfXpEX5pP4RbTSe947nAt7h0Pt3rt34DbkftDuNb25DS9PO3OKfeF++SwF
b5BwVkGiJKyHflRG8rpyrfIQqYPKJ1gxwiF5ogXLAX6pX+EsHn517auxvhrLK47AJYwkU3MBcUzG
dnWWeQOvoRL8KXCdxWuz+cmkZNY0ntYNcQkIlxesO7yAt93z3FN67/26nAPWGTGVeDStJqlgpT9a
Ip0NU+ojclaYQHwJ4Jp1cXkxmAKdk8jWKLnfeo6IKXlXCsn2hnB4Yv1X+pe8xsXfyIcwJ6LLH3Fk
Bm812WZXiGdoEkJ5VxWSG8az4jmczEtHxzFhuZeFAFecm6n0+8dkDRgEflZWDVFqSpgvXbxPk2S9
pZLFr/ZzFI2PcGBDD28rJHKWhE/05WIgwypwHczwTEHjVsKaZEAwGqh9l21NUPwXf+H90sERhi9P
gmuOXh5JcgkdnPV+P8RxV3wrFSu2tg8yQFiiwMbTY5yBLA/kQzI7zP21hbPy5XLMvKWqGaQjnckR
xFuMFQVrojaZbJElmvOl9Jtigi/3yTGG6+aUVzmumQymLCUWdU3tc5pxT022U1NofcXp2vjGjnnj
bJewP1viy+wMDHnmcd0FfHILyCc50NTx5XUWeCxUnKJBZ6KMg6Ljk4qDgyTFHIWESfaH+8QrNmWA
oeCbOzbK9kuz6K0bKKOF3iXtgrj++F/+T0JQn/47zpDpha2adl7JaGR6f+Ugbn5z9+bZ7tGJV+Lb
bL9EhtZsor9KHn3ag7n7fjDYYtaeFzygP8ayL+FCi/4HnEAqOyQt6odJGumJWay3p0XIAX3K2zeh
LCO9tmjXYl5hCHqHSXoFo6QzA+M7Y3IaaNkXNmMCpjFVK3hFrBhQzBNPneOR12zVXaYuR+IwmF0W
Kw8tNpetWgxS121F1gDGYTb1Eu4mMd7C3cTCkdL8axl3I0vJMDUaskZ0WLo0PCmhQilSm57iKFvC
pKaJxHrgZd8IBZOwmBXYI03lPkN9qAjFIbHB+mITLvtl2VT9+4//p4AjmQhIk+RvPZ0KeW3zI4K9
us+Wo2eGs/hdmjTp8Mq0wyv5BCrQXkqZZeAALPFAMrbu4nTgmkHWVJCpMdxAq32H0IxyScZWcQtJ
6L1mbM+Vsoz8s7IxVSs1tVVR+pdlK1mkbfmuEhKaCnOjgN5F86aKDdmxnqQCkrQtGr0c6YNc6yT3
85oj1easZdFtulldGMEP24x/wPWQqRyGrcVITnJeLM2hXBPCjg6xSjJzjndTftVko8P3mrJTXz9K
3wKFhqaN2WHoNbsiH1ujpCaWRyVvoySpglhPu2jhQXhdVKAOme5zLtIP6wvGjlEyh+uGKgSoeQkN
Zl35kHP7ABJeHoEBIVeNyco0HULLxSFcJryxjGdMxjXU6w7hHZpYIZ50FqArFbed/Fe5r8ItIYIv
YYy0uMirab4jamfkDZJJlc0TnCiNdPQw3/NzhTcPHlSc9oZpS0MzYul2FzktcS6ZaXk//XvkkOyl
Vgf1OleDU63uoxI43cCVHC9TkzU1cjAbFB4p0U1iZZfsFr79ckOu2LFcT5RJzqAqZlZw0R9wuSvH
JyazTSSIK8nWBFpPVKUoqyox0ayItReiTUr+u3JJA74ggoai3LPh9WuKiwNajfV0QZiKMnPXVWZ4
20LlR06bVrAoooygSLSxtBww1cP2Uk2jJJF0ZPI1ji9BQT+IkEJnSNVf7yBGaxKA0y3pbnYpaQKA
7c5DfsKS/v3KrF68eC8aEqUAfHKljB52oN0UzFSy81IuHZQyQxpfLIGvKbG65kXdCLfxQa5rqP8r
/Eg6Y25eNgugpKxWScm2kpGelJzpmOAVES4ckzlRGVDW5XZYwh7SEqDVBH1mPwUEh9RMc1EAwMQG
EZJYyf2ElHusniLcbt5UjAYte+3WTcAtdxxy8M2TBGrwYrg47VgFzgP2+D62QusVMezvmbngorf3
HjHGwqaSSrhBwkiW8ASp/MDh4lavS3qfbNpUCvRAVldJp4z0422xVJIdoNKNOILv4+aeZISpWGk5
5YM0kzYopGLUKqg7Kh2G8Rv9W41WNpfu4y3wNlMN6tOeSmivd4TbwakvlR0fHhhESKMh+6pdEWux
p+7Y6ES0LN0p5JNpPtkjuqZxdb17U8f1KsBEfbaA7KZRpWajQamBGChpGdkaW1Im40LBVa9vXsPv
KTmXzTWVBd6U8/PZ/mRMF84lyQS386nj7VCuxVCTH1e7TSRxJ7/WEKqDBAiSYSlVEn4pkT0ShDUc
n0brOYuGX5OK81LKKOfgJuoP2tvZfIUe7yC9baIqO25WcbCAl6JGANYQ1FNtd5LcxfMFslywRPje
/aou2fnb5ntOMmlOhVqaLiLroHU9myZ1tvGNiBRIFJy073BbA9N7WyWSNzsor43rP2d/nqEFdabN
azEMrKjcqBiNlJhxFXAORBtIcjtUXPfXWSrPki7ZGpI8gt05E5FtHczQwBzn89l61vPsjDy5DGUR
tOQtzYKm47iSpuazigrMwiHvFeFlZXaXIBvGJ7cq9hl35OQLKSe+aMKnQujAzioqCVmcWfLqlip5
CjFQWSOR7Pg7y2ldZdZ1r3cdrIBH88I9uOYSyFfZNFXqQD+z368Sw+Yquzolt+Ru0YKEtNyVEIfy
hyEvq5EjUaniHxu1Q6MgZIhxxh/AWsJ0uKlPxURedI3RGue4FJ+4Kvj1agVtS440eILLqdFvlAPx
YmXXhn7BbRb9SBMGURomewSPvEa9XjcqdJqIyF1sjxGRXzeJ49KBK8BfMRUU+g0PHpPq7SKfGvbY
tn7Da92RT96zXE2RYMn0lwl5Y1TZxF7SXvPG9hgIKw3aE7dqsbp589J0KR4ULuQ0xAXn4FJ//Lv/
IZdIjvkj//h3/2O2i3l3Zb47tgc5H2YCI1+c0HHNSKtez+6uJEn383uSiRBl+iGZ5qzkCxaFYSvZ
AiJW+tHmyFx2J9UTnNv1yuFlPDnOHDySOVh3KR4eGuQH74M5URzNou+Rwnlr76Flqw9JxnYjFWrV
Q+T8kndm32Ax/2+6dZSoC67jaJkCqjxFlTGASaTUT8w5jM3popL9s3iwGYJ/ZXOLdU3ysEpqaDKG
nR6DY6gzXhkhuPkEwKBQ7BtXLNlZvKawza6vphruJo+SVX3dYeTm9phukt8VkblzGySRsTVdV9xH
1/0PhdXFfrKxKA7sP9Fm/CAEV2S/KVismw9CscNKoiEmASR5Ha0sfmtR1WvCKxP92nqcbXWJLqkU
tEo2izZ/WegryvQgUx3O1nKJCDNOxt6HaGeC7FyTWerMVIGxNWbmsfkk9a0qK9Kr7pB4zES4H/Vw
rRcvprDXlBrXKmdqjnssmD5WpayC6ZobxAaApS6pCeVxb44YSnijPv3TCI5l51Yh3uPTM7c1c6vq
kA4V3I0s1ynWMiKsYDTLd5B89fIasaaISnaV1MowkYVPJFg78b8quBeiXcay1fyEgYso+HTEeM8d
EJIrpjTwaEL5fC4plOG4h5v7uUR/WmfzMjA1DRJdV78xU9QyN/NAED2wU6CXJplZ6k9wc2LSOKPk
R71pYk6qASl/96PhqPyipqHoth/oZ+UmNFiYoN7phYMS3W9yfRPqGpftTvjAnaVoKnBLFPi4EYWY
7iG0t6QHiWlsu++nvTctzuzAHudqV71OxYxO/CScGVi4sxQR2fJYqG1XiiKb54QuzBf8vQCpuqEf
5H4m/n7gdbiiaHBndxUkiiC9HoWvlWiFZjNBEN5C1aw6dBMrM0cFHY4W5ZnZTFI4J8zsGg5iS6ZM
JFlS1ywbJ7zAZrl8I025m7zinZW3MvUOSqw/VEMwMgL1lzlx9tFVUawOZ1WqZJ+7QLky/tuELy3c
LibBXIYt1Uq5rfmcKIbP6iZpbMVuKckOapdMRmN/8npPLh8tUNkZlPdEAtPKEQJnTuIvmMR2LBgl
wXGHbub4yBXLGgmY6FAfxchiSXrJRzgJvocH+K/Ny/UsGLFDC8jBnEYnWq50uRRs7JkTrOCB1DOj
1AsbifxH2WfRYQ/WfjnjH5Q4BI6unBrwePdI1CgMOB8mIa0rLcaSdxOnLJGms6TH3kvEFJnXSWwd
ApkRiYhMh7OihriiIGYIqWLHYi+LnZtwo529YheSPUHPe2sxc8qLOewD5kJ80PbZhHC+T1fxmSzj
AkxHZ76Z50o2tgdphIRWDJXcepaKZsgORinWIUb1GEk0ccXu4poQQvto9UKr/kkuBQBitJ/GQ3fN
Li90henIXBDArS5w4TSfuNkA8z1NrtwzoYcIO0N+LkhGuclK7xTg1oXdj0mvyqgs9lviuJN+l282
UeivsxGSXYbZpSYsedZ1GrsUv4ZN2G1vmnfo9FSvQ5StvkF6wxgz8+TwyS5yXvAfp9z189n+maTB
mRLq5cuUqEqRLJZsgPDi7GaZOyra0iYcuXLNdn/K8Ctm4DAm5KO542xsdv6pu0XyxoYClBBTA/eq
uRFCtCJnVDaqt+JOze0tPpsXWZ0eeQ6QwPnyOjipI83n3JqpSQR3AVJoLFzM8fXULsLFJZi1u839
JY6kMPrmZMwsvCnHT0eP/2B1lh0nqC+7COuLRW43POsO+NOqm4yzQf0H1DW3GTWcquIKkpgy4kfC
RvKh1HrHnkSDpPHZEns9skHZMxMmF1s0Oi5r6vLpEyeTzTm59B6a80QPNQvhz3k5/1z//tPI/9tY
zP8b/Jz/98+S/3c1k/+3udps11rIxBoGPy/Cfwn/vp/JhfZR9cX2061Xu1u1k8GfOf9vHaIoyf9b
b66CFwSNerj6c/7fP8e/p5PppWQtQBbTCnZ5grCKTEPQst/0cHAAquSXcDTh2MAxLuZ8s7X1bHNv
0/vy5ZPnei5bogOHOOw1mcVUMiNkEZ5P4+7Dh0e4y+70AKHMJzjBFkV0tj7EJsv3M7muy4OzxZNm
Y+O4jga1lZUdnAOPFaDe4zjAISu5lhw3ps36evvmAe5AQVw/EwKhTd6ZJ1cx4DeUzBVczDuky3Mu
V2H3uJ0fzU6GyBY04JUHZ4jX4k0LPbm4DEBGSIlBAwMjGUiCmlgqIRqxi7iG+162SzE32E1f5Oq0
k1P65eBoRx8JEJdLnPGTQSqNYdyoBHcLNgiPcQ5LvKqA4TY3HuT6ghZhFNNOrhV1AU05OLBdwOAG
p/3on6MXng5uxYkc69kJegjcI0QKhU54NBOpe+MUzzI5hOoOQMb0ChvOrMSPEoaE3iT0hZg82x6/
CdKH8zhDbWjuEoFapA90nJGquHYvllsq0PwJThx6ipF5LP1G10Bj9vIY4CCeHM7POdWGcpDnECYx
SAf1hiSoGYlmrOQTy02BKyt7z7d3vd3XX+x9s7mz5eHvNzuvv95+tvXMe/Jbb+/5Fvby3vx2Z/vL
53ti4m3t7HrY2uN+6N7O9pOv9l7jRQmhHtu7JX5Y2Xz1W2/rNzgnt7vrvd7xtl++ebENYIAOA2Nv
ewsW4varpy++erb96kvfAwDv1es978X2S9xq/QyHR31p1FRbSat5r7/wXm7tPH2Ox80n2y+2934r
Hflie+8V2/oCjW3yoOHe9tOvXuC04ZuvdhCFsuVhWCvPtnefvtjcxg4Vbk18hRa9ra+3Xu15u883
X7xIZ+nJFjqy+eTFlkJ79VtU3IGhwS6nfz0FdtCHFz4rwk+BP7Z+s4UOb+781ueYgZvdrV9/hUL4
iJOwLze/3NpdKd8wbOAdly5vvWS/MNbdr57s7m3vfYUNtS9fv34myNzFvTmQabvrKy9e7wpGvtrd
8j32XRoGCKBjd51/P/lqd1sQI9ft7Hz1RgJCMIffYOjo4yaqPpMZgxXFSQPaX+/8lkCJA0Gw733z
fAvvd4g0mfFNomAXM/90zy2G9kAIe84YvVdbX77Y/nLr1dMtfn1NKN9s725VMB/buyywrc1+s4k2
v5Ihc+LRK/1ze3fFUqUvs+Vtf+FtPkPwArptCmN+d7cNLQjKnj436K79rOr9bP/9fP/Lz/e/pPZf
a201/Jkr/Auy/xgB9Yt/xvtfVlut4vUfNBvNditn/4VBK/jZ/vtz/MP1pd4elHA1zGAZHMxoWYiR
gNMO1K5P5UpJauqNKiwCWmRPdp/Z716596HHCKhzvsVVjQIRzmGGzI9FZ8fpkNQUQJ48BEP5dDGP
qLg/OjIG5l9aOxF3uj3mRdZVAfVmxASzNHAQioj8V7iIdqK21lu1MfUmuz4P9R1F78s0QGF/JsCM
ITqcpObnw4rck3170/dHmLpsqNDY1RtofwKLF1B+SqO3Wr3z481eAvmxlm9xR/504/fH98Xavwrp
JzGBdXC3soJN/38KQ9gM4CexhZV+f2qDmKvlJ7WJAfAnMosB6ZaWMf1jBeaxAPjJLGRA+0mNZLkO
+6ezkwHuJzSVM4P9KaxlAPxRBrNcOO69RmQfk9CdT2YfmFtXXm7k/q1YEYutamQ6mFM0Ysua4RDz
RPD6jPI8PSHfOQcLG/H89KWHY4haiEXQyKCbiMWg5j3DdaRYjzj1g27EwvqjPgKZEOcp7OyEnLq8
IfodTwqTYyaQLJAt0f4kGNa+2pzNeNuungMT0Yf88czFHWlGFN4ya7L+ekbESb0v7bA6ZISQoGBY
wv4gnHBJK0N5Eaj6Ic7B5PgQ5oFzKJcW0o4ekjU6icCgFjB3y0lZhvUIXqmwCEM/Je87QX4cMkDE
wWg6XKQqllbHEM8xNrBnwnYHke4/YyArZkafRyMwueSe8njpjMqHbyI9RqFdjJkU7DgPwNx8jkhS
H3O1cWLCSv0TE5Npb0ZnfiMf16BoCX2UP/HOlDm4xLn0+PTAh8Db0MuYa/pO/+Yn8ydKmEpHfCsX
a/uUmL25rXnkFNfv5kGLmeoQNX05gyTngWr6uGJHdTGZ7aOnH04ZMfvxCgEaK3eAlye8gR6BJYec
M5SxWBEVBBi7NEmK54wbxQn92QTzhDB4S8hxTcB8E0mcEkry1EbPC1vtC/znmRalR1AGqSXN5eJk
CS6DJOQy6vE4kxQRWMgYNz+GggOZhg6tC9UdT+Z67TWIRy5f7mkAHS/YEEjagmnO6luEhmCL0yGR
BbksV10cDOfnQ0rdKZcAxTJGjXiUaDbmxA3nRrMeRmZsu2AXzOaa9FLwJEIc4SeXvDoM76YTTYKP
htjhzMDl1nDbPiJncd8xEk0AuiGo5LAFWtoH8HLPP6is3Llj77XmKUG5l9y+Qi9xoAivArzS9nty
CAEdO5A/OL137qDhcg85t8IKr4IuH+ifchE0vt5JIJs/HhjA/MgbmvGLZ7I1oVcPh3FD9urOQfLu
IH1ne2T+uO+FKxaIOUivjazIS0Hs5uic9HVgSNDSzBJiWfd6Z5PhgDzpErBGQ4Zd0cBYmFAglvxz
uFHnHUSKCoNKieMG9d+REt+5Je7g49vv3jMU0k7D0P+ukowiXUA4zaDh3ToWGY+5TD3q702eRxd7
cj3mx5U7b3GM9/1GidZzyX9bCsxDwIdQHwL50jAP+MJaTXkMtFbLPEittj5orVXzYGp1+BiYttbM
g9Tq6YPWOjAPplZfHk1bA/MgtSJ90FqH5oG1rlZylGsHjjxOTlq1FBdvB+/lPnCxo+QzF4kxD2gU
wNiyejqEg2jZpyc4j+FdpHq5Ho3G528HuDJqHn9by3dDAZYvfC1QsSuMUbbKK8ulexcl/6LC29nR
Q8r44+hi5Q5LkM0i31QJKddKvu2+lEQRlgT4bMnf1R+UfJwW84TRMCSW0k/CIOvxSkr40zLowHQK
8fN3kbSlVvNiJR2uBE1GnhdJogYggG5/fjnFMefDyf58si8C+6Ksu7r8aDjxPgtwiHqHOqEOZFlh
3cM0/gCZhBFLeB3P1Vf1/Tj7HoMkprUNLj97GYh34VOWo6SN85zYOZyrMPLKTEztBb+sgCNCh+AJ
9g1tgT0F7W9IPxYmjelWzaj2bXNlffYVuo/GMZf67u3F+7eX75XTxDyHvEHY0kZI/lcNFa2qJexS
4wi6t9PAFrSujR/6L9E7vmAWACqK1GeIXuYBYQ4VQZ7pC1Q/j8irWNr/9Y6nm+97tPkU53SmCEgW
GI4haFXtK8uEsfukULUuK76UouxDHCAaXtAGZeQCrqx5VSjIpLIhAKRWxsknRZAoA4ek3eHYUghO
3TMbi3S7tpJb2Ak2+XAEqQfZpkTyLX5/Kz6d3chK7dAOm7ZsjbqEyNUYdwjRkSTAAh/FOFFNqbzH
Hg2Rd9jcrgWlHOd2js2T44pZoDY4u/YJsYyOgKYgIUWj4iPW89t6de39g89KiZA0SxhylqdkCkpv
Vv+V99m9e/drD7sPqkVVQ62avmiq2LgDMwLB+2XNYAivHI8cwphA2p2BchR4pvCAZCZIDYtJihKG
Mh6OLOuAb6ynN1wRiYZuVBeuFvxLLJy+rcVbKKyCP2BwqLpVukhhWX7HON2Pr5QRA7zQG5fdFZaf
fhwnH+3Cwcf7XufdO/HcaWPjRQhsl2eJZxG9QQMyoaZDylgkdJIxAZ9195jsS0pHvlkJvblkGIb5
Yi4GgkXDCkHbX2RVdrVZiGp10T8IbfN4MvC+JXFoO+XKtxUuPzWZNKmH+OEcvJ2AZQ5xRF67Lw6t
Exz2micDJS+nQmkZpL0KzmuQXqfHveQFkp2KXwp5iNQtyz4iOZ04pgxwgwCzVgrhBvU84AALR1dC
1+vgIGdv/N0Qbxvp7ChuRJ9LVwlGx7ufh8qzlJdQexOr1vvss3dPhkfvRlrp3SEOe38sG4K46xBJ
FXNaNe8z03eFy5bN+wJEXV19zNRZGPHVlScdmEkHPvtsxaFsCB4amGPxpYG7nKSTJ/OZpSOHt7ok
4idz4NJNrmwGUA2WlPD5OU5qqqtOeCXu5BOSOCei7UIzRkLCzS1RwVk9MXW5OuguFcbcS8bC8Sm3
zSzicsEyFGFCdpJKmaDarKtvoVgexB5KeOUXL3/9vFKzjfBqbuP4tBLTNybOuXnfd1iQgzDgG8gY
q/eSvN1Xhh97q9UgsJw5qQzFfOUO8mUHaz5cn1zB+NngT2/tyseHRpMPYUd+hlpIPuCiUTw05bMp
pB86dT605VVT6jXwga0EdXnsSCttAdaUOkGDr8znVf1clw8t+RAKsI58bmuNNb4KWvIzqCtYbQX3
APJlR37q33UBFq6ydCiDNDXDkB8aAj/UV9L9oCk1Gqt8CNfkZ13rdbSVpqCkISMPm6Ym6zTbAT+0
iZ5Q/g7WVvmhFRKvzUA+rMnPsCEfOkR+s8XPjVA+tBraSru5isdWfVVA8mfYkTqrISG32lJnTT4H
+kEgt0O+ajb5d6MZ8ENH+tJuS1sd+dBpaStrgqXVgKNoBfy7WSeWgTeOeVVQ2Wp3BGQoHwT9nTYR
05Z6zXaTHwLB8Zq8arcVYFNaCUJOLA0laYvAWo0O6wiWg7oQxKpMQmtNmm+yySAQTHeEONqh1Gg1
An5Y4+g7qzquQFtpy6dQcLVGRuyt1jn+YLWBMaMt1lmT8a82W/zQaeJV0CQ9Bwi154c1ojJYk1et
prQl09ZpKsbCOhs1bQXSgTVpJQzW+GqVsxiEDfnQlg8NojLoELsYUFs6wUGGTZJQIBgLGhx9UG8p
xmCXs87aGus0Q8GeICZcreNVGPBn0JKfgcxLKPBDIXFQqrQlJA56w6tQyDVoC1hMxxWNSmGIjhop
RhHzdFkOpiqlXJylXA7OfZiDiZ67H/X3hUN9Sw5KBZIizCoLRtQler8wOgiowA/9ht+s6BbVgbod
xImZVaKlVs3s4jFVBys2/U6RimmNsqgvtZCWbOyzlr/Y18RKlZ/7BjZ/qXoqzxsQpUavzBRrpIqp
KdcpLJdTOt22HhF2ZWUl9S1h61JtVV+g6pu+LQAeLof8sPT8Nb/jyzIIfRA45jqoy2rxwbj5FDJf
uqkHk8HO44a3tkYNV7Kc8wBexG1mg32T/Fz0np6RMmfMnpYA6l1Y3InvKo9QWoGB0+roDF7Vi9GZ
zBgxMTwsqkVxX/D6MY9GLvn2yJkWaaiwP/xo2i/6KPMiQtm82nD7LL4pfjW42wj8u4nIVMeV6NMb
iSB9a0q+f2sBvqdG7pQ8UDdE0zP6R1blNo5DO1ePsNRTl6HxYYiTGUmh3qZ09F68hkqLaV0cWimu
G95YF7hd1nBjsbK6Ky25poPUemZM7pLgtApPABKMuiwN9RPvZgLsvteAxwTpr5xuZkGFCShX/V4O
LyS8YDm8RgJPlfflkAJA6iSAri8Htd/BFRrtk7pHyhcVzdkJcJZsUuJOZh2bv8yXzMJ0yD9p8w4y
ePQ+pJ2Qny5jSoE/2mjW/dIzmgfzyQT4odKseY6FWq2xizgWaxenlX2XSSRuNiNaeq7xBJW1rvtc
QawG5XDcH53CiC4wuqRpo/Bb/Zg41qAM630QNuPSAd6E1gwjL/alve96vIM2JncuFCHGEKWrwY6K
bSXiYnitlBheLxyGBTJhaEXBj2T0dsktYSJ5FjJ8v3Id38hzjaLiLqvIMwpbHp8yHhevlCLZT0Ax
nZmYXsb7RF+MQZMR0pJB1Tia73JyEl+zoUKUSL0z20o4hSqK8Y99y8n5VmOBTCyKCX45h2c0CRjB
eOEdlfwtqWdF5jVnl+L8LwxyuDtjU9EoU64Dzttm3jFegyFOQ4FnofOVZP5zXZHiKAfVjiLr9jCU
78vWGAxfJPv9fC6pkbCIarfQiYTZ7R8MtWMOtS/iKkv4KatMSd9Mfs6nhnmUHAsMAtKZ5L6TONWI
z1T2xd7rv04cltqhvAal7RlKynzJuRQdYnF8zZYXLrwyAPIKo5BW2sy1eqOgbt9M8MYy5pECS2nV
fksQbQjbabhZcbuRaWvB0R52F6IUrnOOq7uGhB9HEp/hyYZgyuUlGouhgXQKm/TNjmdY3MSOB9jh
uK4H2Oz/21ANXKtgvNw23gKbpLUPNbQiyLELRhL4SsiC+GUcHz5dY5ee63e33pzELknGeP/+K+3S
/ftd6xyaRZFhktLPdLAnbBuckjLb1N50RpWCOJ+4y7wISOACeSKYSKrTOzZB1blbcyhBoB2tZpZv
L+4Ph/ODkfpm6ImpQrT90P+oztQv6kEVPw6xA/wjQKXggjrABQBHv437uQGzu9FZrNZYY54K/Zv2
dBOimWa3ggsJLgQ4T3wv9HLQPUGvAp0BNO9pldMAp93si9dpee8aBNcwg6VvKBCXgC+OLbGzaZ3T
Bl6lSe6L84uBrfSp0MdFR424hARck+CaAEejnlY4fSv0SYRrzBOB/zhAVKPvgAY2HQ3Le9ciuNah
ZobO6kfXb8zKEssKFNmpEhNO4oiHY12dhsyxUbIgEpTuDCvZN1AND9WiWuLglDFJZt9eNvZVwxIO
CU3Z2d9ntIJszeLL0B8+CA3Hv9sjiydKfUrdhixoUYzJfICnVXkf1EUlTRt9e9d9ehC83zD8Edli
xOOKtPQ+odNCYN5Dw/0Nd3UDccoupEqRSnoNyjOs7TZ4l63aBPVIxIMrPZBlKaZCOxeegX0rYIFX
BxcE1JK3YHPtM7OtdcPUCZe4aeKMzjqeJ34G7kyEBTMaXjejYjNBdAPnidkllm2AgpZdvWWoVZnV
ej6U1UpFTMSDcEmR0A9NkaHksASs+/CBMhwmVFPlGopIlUFU9tWms5aYgss22au8/xNhtisZQ+kH
0Zbdo0/Iiw/mHTfR01htSjSxbb6xKp1R+77a+6LaYUHG30jUscprqI99OWnAaEhGRkZGGuKyzR7T
QXoMDDsaY6M4NkB0cytmap2YcsfsQ4wubyA0g5Q/jUUoNWXwPXQwrHRA6qr4nco/M47T7XBFc/Fo
qfFIl4yu5thvQW5z+ToemjP9wmurums4V7F5bcXMnBTZWXkt3Ltk2kUndIrBoVYRcyNo7SYYrp4/
PToWFdAqYEyHCrYwi8TYWDFurPx2odCzmQBerMqE6XY7s2DDLL97lZ8dxtogAaROz4LiLBdXWars
T2U/60aPnOGECfUSyFX29b4anLKtmoDnliJjgaaS+4rpQpu+tFl1ainlZMoyMtBMpmU9pnG5jmQj
CVVya1WS0qYvzsODDHyzetCqU+QedMq/3Ugbtm5ZvQSLLolqrviNvTOVr++YKWT6RM/cgFFIjG1j
rJsGJTEWT+LxzMWvSmuei+xk+3ifrIKOhfIiqumEMyFlEhYzmEQxeSeiRSBtbTxi4OeBCW8qHuyQ
wZq65jV+Kuk5YKUdz3Isw6syXMqxzxpd7/UMaY0ZqPUnxYz/qEAo8VRIc4YFmmjxZH3zaSA3WvRm
EALeFxKR2yPPUOdDq/ocYoixKUgkLhf8xL5jo9Ec0rfGCFNFCDZQurglPiwsHmIs++QKMY541EjB
pZDCAkh9p25iZH5HTcyYeTa+yZze0fgmFX4iWLOB9ToAT8LiR4caq6D1v436+vFb26HYRhgcTlJL
89npzLJQaIuxHFESP04SlGzmQC5zN6Px1XVjtvFNeILZaSvGlVE5NZR/fMYbkGPjPxpd4rbtoXgA
mWmYEQBfMNytx3Vw7B0getYEA8AGn+iOiyqdqXdVXALdihLt3bt3IWFBG7u4Z/OEEjLXJSn1Supr
1ISgecTTZDA+To/wg0luLWvPV6/lzgWMJkcPe2QEkyMTqkDZYk8Pon+X0FkgxKKxnCGknJvHD2fx
w6ND7JAiPBiCVKvXpoNDa0RTed9XXZAhwbziBMoJ7WmNO5CIAd+EPMj+N3erda+Zhh125Wk4yq4p
TcK67B63fBMqQSOXkQord3AyV3bvZQ/Y1/iBgJZlSFsQxyZpc0pEhfzQeAYJGvBNfMSa7PLKXu4q
e0hjGZvuvol+oE3tcVs9aOqmuWyW01oNZUdZdsLZnFiy/NqSHsoWd509bEp8hPRdIxlkh9/XUI1A
NvGlXke2mFuytczHlmx80yZmSxI/gOgCAJSACEYdSBhGIJELEqkgj4zTCDjuULampf+yfd6QcAGC
FmubXUCkAwDKTnkoZnqHUBnvEIqlvroqW9W+RmeEYoLTPA8k8kE222Wbm6Z9KMZ5QBwGq+I1YGWJ
0AgkQkKCEtg5DTdpSIQGUUoIdZktfmU4BiIBfA35CEANnBSJMpAddRbkVIQNwQBLa5gG/wrkg8wo
v7YkTEP8EEJFssvPIXsaDSKBADKPsvPPeRSPhIRprK7JNr7EmUiMg28CWiT4gz4UT6phTAAoqJLw
CXpYPEGLRGDIPEoky6o4QGTIqxI0QKSxw+IZ6fAHJwrBCpwU9kbiGTwZ41pHwiTYkYaEWHBSJNxA
ei2NrEnYA/HDr+xH2JIp46SEJFONlliVyAqhwzUJhSB8Dk8eJe6CJBiGQqASesEOS3BJW1ZiXXDY
kugYCSshdvmXDF6cRRKEIgua6yjQ0AgZsgRviD9JSIkI6ZA5BBKDIvMv608cQsRz2JQVJmiQrrNh
WdWyZlaFf/Cr8AW6qOhYItmI50oCOKTv4okSgEJFxA1pJySskHQSct2GpL5A+ICEsEjgFWoAoCwu
iaSRtcDBhw2hVSF2KS3EKPQkcys9lLgW4UXC/4Qj1Bn+kfgI9oVnuvwyJN5oUxrD0wQESF1pSELA
QjMHspaESoTVyTL1dEgd0ytZZLJihALIhoF0mTthhxqBFJpZVHwLMw4T3ibsSVZfvW55uKBDo9aE
PTUsAxKmJExDJ0K5UMNyUX4VfMiaE36k/kBlVGsqCgBQmKzwNgnskagodk7IQvik8nlZfd6aYXCy
ImV9yUpTOvNEZgjjaiSkXw8NVYpAIE9UZqayRdjM6poRVoEJ6rJsrNWUtdox8kF5loQ0CW3Imuus
2dUoAkAkmHCdRmBWhyf8QdiFLi1hNspDGobqlY6lXyIfJCpN2JMKk6ahRzI4FSZC75QCAKiSomXF
k0qiwCwyXUurHSPVhKXIqlJ+JMPRBbuqqxs4FPG3FpoVJEJOxbfQl3C0esOIzlDduquG4Qhv1ng/
ZQgCUBiLEEYi4pUti5gMEzkiIqRpZI0RtI1E0il7bQkOZV2uWUGlxNIxa1U1imbTqBUiKYTrCNMT
zprKWTIhLv62FZPCRVWQh1Z8i8aiqkzdsHhhcLrupR8yRGFyDVGGmlZMKpcQdqjitWlkmbBlFVbk
ISrahMMI/kU9aLaV1xCHgRGEIn9EEgXaESuEhMupztNIJHxn1QhHDQtdqysP5JDXVOswTE84uXBa
GWMnMCxSWKlx3rcMjxUtTPYKRDpRnFIzaBp5p2yzIQw0MCxSdD3V+kQ4SuWGkbEmtFU5cEtD55KD
E+oloRmQauTmIDOPO1K1V/MmFp/cqtmZaCzuRsj0h7oDIUK2o6ELjXrN+9pEfqDh5ADH9zNjE6mB
Ix3BFThH9LQg1AH7bDBwsHdnEiDYTfeg4po7NPTUHc3TTN7F74L7//d//bswgGF88bvwfu934FE4
PmX9M8nI9p3h6n7V29X3EsAQJkqPLCQhflk0wtB1HdcZ5/g2qGuNpl1IwiuUGUloqASLCmXJ4hJ6
FSqCg0MhNBSCCG1RK1VBtrxc5U69bRQFFdqiLawmXFZ0iwRgSwCKtFF+4rUMD1D4jYT36Y/A8GlR
eWW5q6yX9SdCyg62rZB1lltWriintaqk0boCazVIL9sWobKUhfvquMK6A16xL6JBOLfwThFWqm/J
YHQcVsk2am7DSFyHF8uH9J1to6NtiNq/1jZCTDFEMaW8q9kxmJXFrbpsOpuiHHea1mRoday9JCvV
NBQqYQRqVyXCIbCabaBBrWuGzxnrIDAcW60PaTy02FAqEkSIQBUmEji0GIbSpHIE4ZbCpsVo0f6t
WT4gkls0P1VCmlYnUfGd8FxBccMaWUadXDU8XAWybbyZLp1QeKxgV5hjI2FoXt3yXeEWor+HqQmZ
EJJILbFJVFUPrF0aWEVDBY+2tuZ0o21WU92uoaaVjNqrptVZzI5qmPDfwNqJIkY1Br5ju6umcMtg
XKWL0L2IaS+0IkxWxapDcKEhOJFColw3jEw0pq+qAq3EKFq1HRKyDW3jejIgTIXvqtXnhcKCxHyv
J+QoK6Vup9aYns5ybhgSlWprodGFhOWJSA0TzqCiq2F1XdFmdd5kqDIYJeDQTLyhbKtvqbNAFCzB
mhCwGs6WielEER4Fb/3qakWPrWR2O9MYPOO779y/MOdmjDCQM6UXLKEe+3jBLQ+XGOTIfD/ZgKEz
Wryr5YxP/iQ+cjeINrg9JA4xum7FD4sSujWU7O5yf5BlfNzPVOW1dvDa0z/rD/lXxQ9zG0aAsLgz
pAOR0EKKtvrncTbCJGKGoCjJazROd3xX5OhZ0YZwIvQcGV8UclUkHPd7A3opcUEVRslootQZKGd9
4vl+dDGFvB7PE+QdTVOTDAbZRv0qPWOfr+RJPG0GMJGnOLaAFNH1TLTU0VSClxZ7/DYP7306iQtN
PVho6jYdxPVU7CQ7dTTVmEFnXi2oZHJ5/vRzVVOOo2scjK5PdZFyrf93X6rtp9WU6PKdTEl5Kpss
PBWuNL6xUVLaLyXR6MTlzUvDbPVlIAm9ZgHpfkjR7p49Vf/V+AOOc44FkmiYrNL17sUlPwVeWQil
3EeqrBjJ4LjDhVHZLwsztpEp/KCQwPK0mmLLOl+vZB+ojzCwOc98KrD4eHg4V32UN8l7ZdO45ywC
S2xuJ5RlCOwiChvafZwTh5wsnILyy0Bn1ol5V9d3Kyb1xwK0xxuLCMosCRMk+KO5g0bXvNSA0MtC
rsRTHMrn+pPoEInKeAtiEtciCeAcFqYAk/2T/FSkWykWVaYuLAuOK0mKoHAYwjop5pfJRiRAc7PN
+pzeLpnR9+/NMYzhRv7TbRigXw3SlCxs8m/FpZVG1Wf5Ytl9fMAKFe4GtlqZOP9sHYDLxdUv6e8S
/uzX004WQda0Lctw4FR2CddJmpJsg7x1oL9//zYp/j7pd0E2jc/j5W1fi+wE/MaGc5okD2NjWA0y
uC04p6CBR/majxZwKTJc6ntp1I7dSzZ8yKQmogFsYmVvRiwqv71LCAljMSPLyir8SsPP73IHTbOE
uZuAybYZY3ZMDrHsBqEevYMoOz4df7B7fiabUSwLdJzd15SYIbtRKYoOAumNauNLxKlsKTrnkWua
E8w6AVj2Uium9ZI6PKqnLZhjeFo5rcQ9YJ5g5w7x4TAaDcwO8QS7/sgwYo5oZEM/oFshzZRmlTxM
cjg6cXDqJpFtVnFQpApbctbZFFFdYD6ZY5aLYkuMxielfRuwYvaaFZ4BkcuVkEAwHpLjYRoYg6Aa
ZqQaJ9H2Cfr1KDXPUvOscduElV55+X9XtB60GEpRd29eybvcv7QI9Pn28iIey9Aq6uTbupJjpKZH
dGXRpGle2yOUosHWuaZHLMIDKdf1CGV4QKV5bY9oX9IhvHptj1CK0BrLmgv9jzBjaVGuLS/iSZkG
e31Nj8QlBEsOx2yW9gjNwQSjIXlNcywSXtfpJmetdfOs0edAaxSQrusRPGKwdHEe6Boc4TsbvPL1
USbIjsHiqCHnjAKnjE607VEo58h98YCvLe9RE0TS8Glnd5YjgEWwQpZ3mjhqSq+voSP2iI4YuKuu
mzU2t+bTWL5u1jCrdNYIjpoOylIowNGa0FHjytfFUPcDnWinR+JSgYcrCK+fNdBRJ0U3/CYEHly5
nQZ4pwis+iBXxEu7kJZpLfQIjlO6tYPW8h41QLYdv9FOm4PzCJ6LbI8abXsQTR9XufTwmMFRWwgn
dMoodRbTkW9egF7ouHLx/REvmg66s8zgI3fTUjoy4wd7qidkJUUcOkrKKHtKetTk6sesYUPhOjpC
F8AfsLqBSB0cKrSIcbfTXP2haY2POLLekNYSTGdx1FmCI9mIWAvTsYn/bq2RHd1tZg3TT6QIGomy
VR8k6qBxlTgS6k96naAsgyOuifrqtfyo43RBZy0hdKdIMk2mtZb0KBlXkOdHzSJ+1CBlo5PsaMs0
5pC6S0dNv2mba+Gx5TczzQVZym4tUjZdmJlZaxXNWkuSY/gk5mT44r3rZBDgdsH0qO03Q3di8Q4b
lJQiMrJVPAJHLWdcCz1aXdYjuhTBJbUUe0Q/5tqa2xzqwm/YtIsEmIVDu9l2yBZIvnGtkbIJw8wH
ukLSM7ORkWstpaOmGT43LETQpc3VnS6Y1Q+UrboLKcisNXZwYa2FWcrGlBZQNjvARR3WHTrisg4z
S3sty4+ai/yI4N3VH9yiR2tFPRLKJu030hVJR3ug1RyenXRBzjl9xKZCs5XrUbLczVrrSAcbzrgy
ci1oF8m1xq1mjcWojZjmSABg8k23uSBH2a0Cym5leTZpoZhn823QdnFEduASCRGQ7cKC7M/PWntx
1qjLp6SccFG21MrybJHhgYG0yh4BlUGY61F2cS1qI6sZHHFG8jhqiKS1y32ZftTMELKZtRYZRpjj
kMnikjNyH7Hl2MwsxyDbo2bBrLVzq79ZtPrbRMmqTlIrmTVyx47bo3aGH0mP8vwouBlH9dyshUWz
1uGsAR31drpGHEHnCC0XR41FHOVmLQwXexSGt+CQJHdnsRvZz/VguERCkxkO2VzkkGHnRspuNHI4
ai7DUUo2Bkctkl4jO7qbpIioBw1fq0mAQ4oyV/Y7OOIgFumokaMjRdoCHTUyPQqLetTMzFojWCJp
nR6xzGKPVjPKh139SRctjoIsjlYLehRkcNRYLcDRWg5H7aIetXL6keIorx8JHTmUXS9Y/VmeHRbw
7DAn+1lmkbIXNLZGocYWZig7XFuk7GaYlSLBLXpUREfBaqZHLhO94xWrIkJEue6wiEtERUItN2WN
1s3dWabSZvihrzSVX/prWfa4djNZN9u3mrL2bXpUgKNm80aVtpUXs0EBMwrCvFBbLRJqLOaQNVdI
nqwbazcKtTzDbgbLhJrbo6BZKGbbmR41CsRss53tUX2xR16uR+3mMjq6BcPOipCgQIQ0127sUdi8
BR15zVyPgk5Rj4JGpkeNsKBHnRtnrZnDEcEs9Cis30oVadYzsyYMOz9rjRsFf1DPzdpq0aytZTpg
1xo1yjUXVlYVoTRaoOycUCui7HyPspRt4hv3TLpxjaWw6eLqNpNLkqYVZ+8kqbg5VMRjZHOb01y2
Kbb0bFnXc/Kq0Vc8NkkB7DFTpgIc8GhaDzvEM7NT4u6j+BkIYSZHCPYdVk2OgbnJNjKwjno9BjjQ
Q591ST/g/r9e9P9G0f+bRf8vLJkHaFGaHpviVj7CEXQnRHZ6giR3EDZ4urI14gaX2OOt+8lwygku
JAF9JmWS/YKj9dzBWnUKSJCPbPH/LnRe28ZwtJSnKMfMQHM6kiOYiG8CkBDACLyKRcXDAW9ssvpN
2cPmeWPP1EVpXCLBuTMvnHb0CGsPp8bGrGKbY0zCwsvkKK/UT87XLlZOjtqynD1+GrbSHa2kSqZH
d64Z9NJPDwj4vlde1pnfhUSRmRP2hSmbENs0ZwIZ3bjK4AbJYfqnUzevdb6vNtfUHLeZcMudkRM/
vP/V5V3Ht5BhV0jNQfDmDok7hmLkV3UpYDtHaXKvtjMnWRhtJUjZAC743Agy7dt4r+QCILn84CFC
wvQVOiBvmFKAu5Z2PzbhPCZ6OnuyNTmSK08LsUS6ueeGSmv8BO/I0yOY3163dfKt0p5sNr5tvX/b
fG+zh0Q9bIAmuauTw7R6JtI9RZumxc4XCt0jpUUlGg0GGTBLh3t2VsI1xpL6XJO05msxgXgQZmvJ
kVfJRuQ9kd1X3u8QeN6zEP81PMaG4znIlwpZKsR/DfzX1FJhmC+FI9LPQpQIm/ivpaXQ92eNZr5k
EyUbLfzXxn+rWhJZQ54122lqdSBVkpmmu+ujYZof3Llrg33z2T+fzfuEzL/4ik9Ua9iQaYQPfIMb
gD29sIxXEh5NzElcQd2S07uJJNU8FLrJ3BuLrHNzIn5ukiJ+7pUF3F3zDZSNGEgcS69rivDNkdyc
xKuNTE6sLEhzm89hfie7YJNcMutSqssdC4WZxc0Bg8XcDBrEkEZh4BzuYN8JsOsvzdhwffibyYR4
MnXvDWIIl8aOapjJ/GSaySnCT3gh+URMAImU3rDn81GhkiYmMDkChdOYcWoghpv/IslOZ4coJ7cp
VOxUce3Y43GaXUBzGuDGkWF8zItMbWIJGyRg4wUK8lOsOKJZMl5ISQ0e9PWtqa3vktyPtmicyfuD
PiC0zI1PSD7hNIhGuCWY1UIPTR6goh4Q1drz8P7wPbJC2nKZPmGlZsshbKZaOCIzr/toPS2v8aA6
w+mw3t51hmgicZIwYRmMjREuy9ODwgYr9zVna0Je+5ps84aQ0MUuvPcXx52DLJfkKPHKKC+IY9uk
Du+OKff2rq1gRmbTXWlpXL3jd9wUstlpfXs3N80GSEr0+5om5s4dnfTl+HEzHpkL5uwFi3q/hBGF
35h4aZNGMElN6ZxvsokixoY6yeSi3onc0BYLO+5KCwcB1lFAm4L39CH1U+axfNDIPIMRV9JqITNG
pNXSR62WPmerNWbOe7seDCvTPDOZlYKUtiJ5Xog+Xc9mOnKocjDJFcVT2XmTKQ0+VfGS4NSpQssU
7qQ5qAsbk2vi3E6/vZsdQ26VJO1iueD/+LxaWZjvXQo0Nrn11Kb2uHPt+HOkdwsc5Ij3h+BhodE/
BRcL7S/BRy63SwbeYooXaCU/0e2eGz/Zv/SGcETcyToVnafglqIkXUyafFPM0wmvl5Sq0Cv2oxMk
4Nm3t5TJJWn2lilq4RycKhmmBBVsjXk8xN3ngIT7zpBsZkCe0cu5E/SuNDkiiavLJEGIk4zUABRs
9ihxBeoA1xOOKUBF0iH20NyAlsbz8RIvewEZgrah3UyHF8j9irHpFWloELK+tpLBgXP7t6bLkXy+
HC/tA6M4pmppHYQlcYFjuccLebb85GM1FFlo7ns7wcwzGvrS2nNpQc8U7N9UsBq4EEX8pUACF4iN
OLX3zdupJHrMXCbKjL0Ajnc80ewcH4nZKfqNa6OqIqsZYt6kdWw3Y34oTOBlyu5zPjJGY1wGa9q/
qKxknRJ35a0mkBrxC1YKbhTFz98zqDWjxAs9pYqMwzC+Sx/vCEAsd71sshqm74ytSfWh6DPeOSXS
zymnIC3OeppNJxlgYrOXce0cs0IlHVzVHtHugh0vNrxtS/Jyb4TJ82ruWbSp7PMqn1NweqW7O7Qc
CGt4F7/W8xPZRrKfnPYOJvP55GRhBJny2cEs+5TiuF3wWl7dBtNDJj50MN3IkoJ5zGHetBU++A4o
eRBq+3l0ZlHxnSip2dJZZFigQjHpsKt22AnxuDHj3l7GH6SryXClee5TGVywkgRXD3o0NSSXV3on
Gy0THCuBHTyeuys8BQLc4T5VZFganZ6MvdXC3HvasF2uudXKBpG1brSx6q9ZtOPR1+VbNWsvmUwW
lyRr90KeCyB7qcrtkemUSxE164pKLaBsM+8js1hTtPUWPyfXzYiPOXv1puNXjuG3ClSemfvl2BGL
Rns9ZO4GM+NamWn6NhWOxpmntyw+ic7xtatSP9MjipAD47ewkuw8Sm84L5pAvUlybm9ltETtp6Sr
GblT0qxJii9N9eYcA/BNgzEucKYcdf0niyj8lXOL5FYtcO+RTJJvLXp1GRuPywuwudCRX3ItEX61
5Vejrr+4ncE7zqs4/CKF/IYpji0hW8NvaiXs57ZMPcRkNvWv0G91DCy/HSo43HzWUHis67fbCaCO
v1q3D4iTWG2m4PzVTvLQ9jth8oA7GdppC/5a3fS5WQ3r2kpHYOFTMwPbX+tkwCPAJEwGgiuNGHje
TkfhdxjbVM+0y5CQTNvcKtL2w6AartpR2vY8PwjDhUbxMkEBduTkJYO96pkBm8DztL26doCBVJ2F
XvmBmR+3Z3jZNr3rVOHMu1PQEew2EYM6x+x323zhFlhzAT++hOrYOXbw5EswWjshEtYIzQeAarcL
u4ytZYT7ooNwKuJynrq9EKuQe4hOK9y8ddFSF3xiz4p7UW9q5L/f8F/6xP+cp994S79JvQJGvLCm
crw4vR2mrOyX0maVOTKbiZFLA+uazZXUN7R/IV6V/cuV1HmB2ok4vXRfUPydRykb4yW5MBiKty/A
mQy/KOBo5vQYgZQv0iycl/onO8K/2HDBa6csSzg3ruuAZDwbvSn8KQ8CH78v8Vu+y8nZy40qUlJb
14y+u8i+uyPHlGYnLvtWq0Qut9Ac3tHBJYTxGVMtz+WydCSOnONAHYeNBN8DzblrAKrQk/49GOCK
Zenjg8Hl+w1azr0DHBm++H/bu9LdRo4jnL/SU0zWkDVjDaUZHauVsFzDduIggOMYhpE4MBKBK2mz
9EqkTIpL0kGeI8/hV3BeLPXV0cdcohz98I9pwytOn9VXVXdVdVWW8991lnmCaD6Xt0IvP/q34uMn
PmHgoXDgstoRyy+u8bIaA09pJGYUOVM1t5IanL/10HBGoteVe/DJT3kbjxojoZVwBX9GdI5uWM4P
J5ZEUxl7/lYFQhm0b+gqR+xYem1a8cSCi6izrl6zPek48XLXhQB1xXaKI/90ObnkzCLTpCqu5crT
YnCaKXjeArW3p1Ce6PVZvcigSUIctWtdbJl1P/kTKqcb3lgexsHu9T9Z8n23mMF8jxgaGnlodifT
6d0uA2WHN3Nabo49vxvQkZPt2IbhWZ7Ie2Y1cIt/2bYtJXBUIbEF+6vX4jCEK/9ZlJQpxXN98kzy
F1bYogr/j0ZZSbalq1FaCmnPEnFL+SDsDEyhUEjlhQHF9WmU9oT/WFThG5UoA5vzWpQCjkiNshxF
6QrasCBsCrsfTEt4JsNSKGCFRhnwNlYySA40ibL+ljaHksNVqFE2iTaHvn2O2xh211RhY+UXQmlj
Jd/uH4sqfAckysoVNod+RkubQz8qhc2hX0FcmmAPFFbcLoBLZTJKvbqH2fLpG48c3H4PUYtsrW3R
G8DtYDm+NE8zJgWTZ7Vvp7PxjzALfCPfsPhAjvxumu9QCg0MQchNI5U/XiwGuLx5/csLfHM5GEbR
4l5O9B2S/x46j+S7sQEhb4T12A/op3c19gOcsQlHNGwN3h7ABoUij4LqmDcGM5Ukx2Qf6JVJb/NZ
ZGvhRX72NK2Up4NxXDWOcydPVPlzQB+IBMNJZVJGY6ccABu950/R9Dg/s1ZbKjrNwY1+qJ4XXI8N
+dMMi5/XEr44PKhmhOVTKFeFCljhBjolX9e2B/Wh/ZXKt+eyKs2s83K53Cf375N3azbq/MNsgM01
uF8QgSRZ6oHUOdBGBmoXOjrqXoQtM7kTzGS4yFEc+fIYpPC4XLFMGRC/wkcoOkXFpSMOZQXLapTH
TKUnb2Y93mhOSE88FosgluZqIDtKpmjXo8vSZyo9ISxq3XMkJuoeN2eQVSh8UYQEvfBoPR4Kh/+j
oXAUNDwouOYCwuOpWHXcHNWq0+GALJYBdTaQFEQ3mJVBdpmVOvmTSFEb+ZB0+pH3hyKXnWOtd45g
lTWybdMUkM1gmvzBIwTQHzT8eYqbE5L3F2M/nQoDihWURCdyydqVYptB7ipN+zZihrH/gQYy1rDt
DHNoUlZxPynuJBPnwuSqyuZXkVTgBNnc6TU0ZhdVZhNbmVW+zoUAas2wK4/rq/xYM2JXhwWeoau5
vKYZnFBpCUgZQ70IB1QFu7oEQ61cnVa8l5jxsh04BN1au7Q1pYnymuU4SI42wczU0yyQ1ZLhp5jp
7PtUhn0JOvh/96kR7rhrcbc375O7psJAypjNfI1v+ey1UL+Bt9dEL+AJglc33CmISakRRFtoiFZw
wMcNvP4QDayuZ5WGGWzYGEwr6wpL0clM121Nq9b7buUJYFszNtpcJmKED51O0/dRekVIVcSuejeU
o3Uw7ds2Maf7PSyqEixHFHmpKjyyT/Doil8XwmxrH86c1IPtkR5K4+08rJZjskDm5iLRyfCeokhI
6FbO5xDt0wV5yfrn7twurGzHUTdVcXCpQv8bFMu6AinpVV+zlhzLwY8+zsQ2T6QINzBXXaJU6NSL
RQj+6Td/BTd89E7ZAojNnbOMJZgoS1aOuaqqeqsglxkBXymT4OtrVh+gPiTJZ8SKGJsLDpU/F0XS
GFJsx1XGuoOHvJyCMmVzmXVj7rKlhRXnPqrmLh+Gp1KmbO1DCmeG76GNvAeWIH4fZY19Kov2dt0o
7AVfVRjKDhiaK2iGo7X/YdOoZ89qDesBOefpN1RFqlTj5EOSOULYVwxek4+ZK/akOJ5gCavIhjhN
6Yp8TK4HJes+388W16pivMv+ue9l/RHS3d02xab5u8+pkSHM/ePGby2mF/lFZkSbDQ6CdDMX/x52
4UJuFD/fkEs1uWcl5XV2HeCrAoK3qrjHwsNEfdtbQYM+17oxxyoAabVz1Jij2tLDuXaOB+X+SfZR
utp5PjikX68K19XpHbDoj6r6AY7jgn1nee1zEr2Ri/Q54cUM7NiDAyoDFSCgw3RCOi9fLEY8SFkr
AB9hQPbk74PgarY9KbVx7njQzefo5TXRRlJeSVmZhDtQ8sclffBNzZRLzKbqoGzOLOxXRnUqDIWX
iFyxXig1ZdXlr8iB7i3UcmTZjOEr8zRJqXaM864up13ir66UoY+FX8rCJ/RLSriE56EQi9pI5Z62
DTvaFAGntB68UwKsjY6xmbYFlJ/hxXESHadbrnf5Lvtn6HaMsF/8fjN6lGpJGmzSadZirM/N7PqS
CasE8I7/AVGF6RcRf5g8NZHlvUny7Zd//lq0I4UiUficSiQvBwrKx1pRwSk0colVDdTzDf5QY3Zh
/+Tqyqtw6rEv9Zrm86xBCB4fnhqZWqiuztDiRdN0ZHJHfSbUNzeB1bv4EnB3PxvGGBRaH8h8N6Xs
8OvmTv5Dfu3BLWjG5WzMjrdsyek9YB6xxPQSoNVcXI1n+Rr/DmlCaTTh8OQeJ0uQbjr54MACPHfP
zEBQ77/J2WAKosx0H9esbzlybvZBGQObpk+huHj0fjS+YcG56Otf37BvREBtFgnZfCKPCAmqSEYV
WlAM49WaaOsqZhebPB00otng+EWGju0Wu1QQhqR3S/51xorBrKx8JxrIKoTD1ys11switpf6tirx
z3CwXKAFIWpa0if05R6am6IB7804grDpyZ1lRtz5dMk+C2QAeDUsJn6QOAtIHe4DUB5kN5SopJQZ
kMGni4K6HJ7TQFAMMMGB6e7gQI7LC0+0mih9Iy7jUMcdbT7OyrIkmSZ1ek4kmZ8SLnF0NIV+mSGu
LPINys2zw3KGbHF3cAXTvEw80F2pCxlxYcJZiNfctglQ9eHKkg21Lu7n40j5MZduH/KQzOUUzjIu
zMRrwsOB6FRXCS0Rni7ARU44Z9d8avCJS+xCQpETeq1AJdkWIjXMJhqh66qkHYfQRJcc9YX+0AfL
G2VgB4mIITEoGBC98yPxuS2O7xf0lIPgn1WfA27ZcNhwDkqPMLGvJYekJoO1TmFkbxVO8FS3kQc6
nnwrqrMfXTW/ccYjVQPXRNO6tM2z3eIWCfw8jLf4fkVRlCNFGYtNdIot9Ut+XHfudDBJm+gTU8ey
N3jjSAOLvvhJEX1OZ1ZGnj0xKnJl6rnK8/L8iP4vEz6AgBTN3p2zS77zys8sFD/61q2mr2ZTGLhU
s+coELYMB7tQFFrfvp7eBHqzkLPcsGbt1VS26ej9dEznUhJ8OyGwXnZUr5fw6B14xBO5h5nfYiBq
rnSmVmityH5wFgm0pmv0iolJq9FvLaX0ylEpjSb1cv116H7xPYEswhYdFM3udqzFrnA5tQtRRr6Y
vrnAaF7IDhZT0hjy88cti62a+nZ34AJfkinVYAmRjsjJ3jgjivmK7yJjp9A3mrPh8gtRMaaShPXP
E9E4zvG89lw4A+5sNJes9b6S1JxE5ws8UbsQzGeMuHMnqPLaJZ4J0l6DskQqMA6BwEwthV8IBAyV
Ci0NXfEKwobBXTvq88n9vG0ut0LQoolsjFZCumUDhJe4I7Vz7OwdB4k4LgRvfAjwaj+HbrB9FzoH
qyNRofOAvOnKTZbNT3ybW7ZXcGSwn3td5Y1EmKJKJ9RlMAq1qfbLTbM8AvBfCHak5w2mq5cSbjtd
qKdZvqva8vXrI1rGL7mmfpH8ChdJHaHV1whWEr2LfoCyS76NMDzn5OqUNt0m//1PMlH8Tj/TW7qn
8o8JX1h5TIgf9dKJB8SIf7qqR/FspNX1x2kWuVc2RlMkpTTn1gTwEhoaeNXcwKvmBl61NUAJ3FnR
BXSk3U8uGHpHiV5QMIj0EP0JjlIbT91mM/sHWm1s2Z1vwOL7WpI0wx9FT5zO63RroCvY27XndEMJ
bkU2J8AoLsCi4bsDrUlREMc9Q86z7CfbuVDHQQ9CQnrNJG2wuQC6QSxml9fy0s9l2XcWTcgty/sx
seBJ5/GOzolsyuLHFZ3i9v2a26N7gS6yke71prmvJlC5xC+mptTDzrJHnanHnaknne0+j8um3Efi
Jlc6WS12GldaTX7RnXzWmQyPeuHuwriTdjNwXdlcZlAb3WryYXfyUXfysQCUxVvxyG9FnEPZeYGd
f9KVLJXhI9eKLJQAH9VSDzvLHnWmHnemnnS2+7xWNuVOYq0MWxaLrJRqrVHyi+7ks85kWimaHCyW
VcdikZXSXuXAxrc1+ag7+dgBtOFiiU5o9BL3MTfYx+NpLnJSJD//RJcokNR32Q7uu2FU+o514iiB
CDDNLnJ5Ww10RxDK0nJ1OEjYig1Jl/GnekU9xk2C5fCsFu5r+4jFaIAtg+2eQ8eWDg4yAdkLRtJq
dizjz0yy3sgSvjMOfsdbZrrOT2fRlZ14r2+T1J5sQiogObMm3ryK5WFOxC7sjZZEYlazWHN4tGi/
gZtNNTXUb30bNvATqEQkmHbsg6pruuqDZuZ9sN8XiNakzD4e7N6LcHlbXlew8xMVWYdPsOn6+iJ4
WO4fPKtbFYM55QnJ+Oyw3zHkPFwQ9dOhunPow1H3nQ0UIQgKq4G4l/5D2B7oj4BN4h/RGmgroJzu
jddEUX9sG8L42OpYDwYMcS3+MoLNLg6VDuBGP3rNPPso0o1T3dJApYaYTQlTb26++H083UQmpHuR
QMtyTQsFnLIpdYxOafu01lSHgcUerL8RMSJ/55aJewHoFKL5JA0WXTrkN/hUc8ZrzWzgWCW/lxf6
zrURGJzq1sjZ1PLIodEykpV7IuMJ5b7tMnlSIXWQUM1vrWArbqs0jmCZLy6pSbyhnEF0qWaSdJ+l
/OwCT79+/qn88OefDvdVvPTeROzMEssp+VAj3FOPnN/KkOiSWezTBXXoCudrMDehpYJDtKo0ZQE8
b0gCcn11LiyjXMfO+c5jGd622DCytYoT/a0aLGA0nTvFKXYCjQlUf2zGVLVnJymXAxPMv64Zw2Aa
gKMzPEwasPE6ko+Y0MDhGZJcksouFIkuoXxTw+bSSEowB3iXYi5obWWN1ldyvyYZK9OD75y7lrO7
Pqeitr0VrF1TEOosoTvfVKCuL7nQBYPzeix55AlPK7xWv7pn5J9kHawCWEsuMWnBneQGUG9cJyt5
jWQcmtERMoJmVezV/FJTXFodLc6KyZQd2orkLs+xS0N1kDwxB5S631V1ageFfjsEk1isrslzqGGy
c5WbCTP6/Sz/oDLh9bZNP76ln/pNY0rEPn1GCr3OGqZ7zlg5FjyWxlUsvjgszQgCuJ3xM+yYUTW6
pSYu278Yw/N0qxNQwinXhNhgAKwpPq8VGM0vx+Nado6tZ1bXvtXcEh1k12EMvpD4gG6hLcz2HFZJ
rHio5eJIy9r0RrwxPm/RI8U5uCHagVLTJjRwaglWpPldQUsKCrUdNTtOodZWfODUZuJIZFU6NlQ8
mrO2rk61n1xe25LPflq024P+w834yG+r4NNK1v2UTgJHpZs4M7WaKjoKzZoLlnkD7Lw5Hs8Zc3mz
v+43j8GDOHMjxIqq2i3IdZqX46Kt7oI7fQmjqPfzGTn9jAHquLS4pVM7CreekanIvwXzeURXWaOk
YvabPvShD33oQx/60Ic+9KEPfehDH/rQhz70oQ996EMf+tCHPvShD33oQx9+XeF/OG/s4AC4AQA=
