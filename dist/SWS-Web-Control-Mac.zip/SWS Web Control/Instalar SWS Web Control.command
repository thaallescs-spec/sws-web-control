#!/bin/bash
# Instalador do SWS Web Control para macOS (setlist web para REAPER + SWS Region Playlist).
# Dois cliques neste arquivo. Para desinstalar: ./"Instalar SWS Web Control.command" --desinstalar
# Os arquivos do script vão embutidos no fim deste arquivo (depois de __PAYLOAD__).

set -u
NOME="SWS Web Control"
LUA="SWS Web Control.lua"
HTML="playlist.html"
BEGIN_TAG="-- >>> SWS Web Control (auto) >>>"
END_TAG="-- <<< SWS Web Control (auto) <<<"
PORTA_PADRAO=8080

azul()    { printf '\n\033[36m== %s ==\033[0m\n' "$1"; }
ok()      { printf '  \033[32m[OK]\033[0m %s\n' "$1"; }
aviso()   { printf '  \033[33m[!]\033[0m  %s\n' "$1"; }
erro()    { printf '  \033[31m[X]\033[0m  %s\n' "$1"; }
fim()     { echo; read -r -p "Aperte ENTER para fechar " _; exit "$1"; }

DESINSTALAR=0
[ "${1:-}" = "--desinstalar" ] && DESINSTALAR=1

echo
if [ $DESINSTALAR = 1 ]; then echo "  SWS Web Control - desinstalação"; else echo "  SWS Web Control - instalação"; fi

# ------------------------------------------------------------------
# 1. Pasta do REAPER
# ------------------------------------------------------------------
azul "Procurando o REAPER"
RES="${REAPER_RESOURCE:-$HOME/Library/Application Support/REAPER}"
if [ ! -f "$RES/reaper.ini" ]; then
    aviso "Não achei o REAPER em $RES (instalação portátil?)."
    RES=$(osascript -e 'POSIX path of (choose folder with prompt "Escolha a pasta de recursos do REAPER (a que contém o reaper.ini)")' 2>/dev/null) || { erro "Cancelado."; fim 1; }
    RES="${RES%/}"
fi
INI="$RES/reaper.ini"
[ -f "$INI" ] || { erro "Não existe reaper.ini em: $RES"; fim 1; }
ok "REAPER: $RES"

# ------------------------------------------------------------------
# 2. REAPER precisa estar fechado (ele regrava o reaper.ini ao sair)
# ------------------------------------------------------------------
reaper_aberto() { pgrep -x REAPER >/dev/null 2>&1 || pgrep -x REAPER64 >/dev/null 2>&1; }
if reaper_aberto; then
    aviso "O REAPER está aberto. Salve o seu projeto e feche o REAPER: a instalação continua sozinha."
    while reaper_aberto; do sleep 0.7; done
    sleep 1
    ok "REAPER fechado"
fi

DEST="$RES/Scripts/$NOME"
WWW="$RES/reaper_www_root"
STARTUP="$RES/Scripts/__startup.lua"

remover_bloco() {   # remove o bloco do SWS Web Control do __startup.lua
    [ -f "$STARTUP" ] || return 0
    awk -v b="$BEGIN_TAG" -v e="$END_TAG" '
        $0 == b {skip=1; next}
        skip && $0 == e {skip=0; next}
        !skip {print}' "$STARTUP" > "$STARTUP.tmp" && mv "$STARTUP.tmp" "$STARTUP"
}

# ------------------------------------------------------------------
# DESINSTALAR
# ------------------------------------------------------------------
if [ $DESINSTALAR = 1 ]; then
    azul "Removendo"
    remover_bloco && ok "Removido do __startup.lua"
    if [ -f "$WWW/$HTML" ] && [ -f "$DEST/$HTML" ] && cmp -s "$WWW/$HTML" "$DEST/$HTML"; then
        rm -f "$WWW/$HTML" && ok "Removido $HTML do reaper_www_root"
    fi
    [ -d "$DEST" ] && rm -rf "$DEST" && ok "Removida a pasta Scripts/$NOME"
    aviso "A interface web (Preferences > Control/OSC/web) foi mantida. Remova por lá se quiser."
    fim 0
fi

# ------------------------------------------------------------------
# 3. SWS instalado?
# ------------------------------------------------------------------
azul "Verificando a extensão SWS"
if ls "$RES/UserPlugins/"reaper_sws* >/dev/null 2>&1; then
    ok "SWS encontrado"
else
    aviso "SWS não encontrado. Instale em https://www.sws-extension.org (sem ele a setlist não funciona)."
fi

# ------------------------------------------------------------------
# 4. Copiar arquivos (extraídos do fim deste arquivo)
# ------------------------------------------------------------------
azul "Copiando arquivos"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
LINHA=$(awk '/^__PAYLOAD__$/ {print NR + 1; exit}' "$0")
tail -n +"$LINHA" "$0" | base64 --decode | tar -xzf - -C "$TMP" || { erro "Pacote corrompido."; fim 1; }
for f in "$LUA" "$HTML"; do
    [ -f "$TMP/$f" ] || { erro "Arquivo faltando no pacote: $f"; fim 1; }
done
mkdir -p "$DEST" "$WWW"
cp -f "$TMP"/* "$DEST"/
ok "Scripts/$NOME (script, página, QR code)"
if [ -f "$WWW/$HTML" ] && ! cmp -s "$WWW/$HTML" "$TMP/$HTML"; then
    BAK="$WWW/$HTML.antigo-$(date +%Y%m%d-%H%M%S)"
    cp "$WWW/$HTML" "$BAK"
    aviso "Já existia um $HTML no reaper_www_root; cópia de segurança: $(basename "$BAK")"
fi
cp -f "$TMP/$HTML" "$WWW/$HTML"
ok "reaper_www_root/$HTML"

# ------------------------------------------------------------------
# 5. Iniciar junto com o REAPER (__startup.lua)
# ------------------------------------------------------------------
azul "Configurando início automático"
mkdir -p "$RES/Scripts"
remover_bloco
LUA_PATH=$(printf '%s' "$DEST/$LUA" | sed 's/\\/\\\\/g; s/"/\\"/g')
[ -s "$STARTUP" ] && [ -n "$(tail -c1 "$STARTUP")" ] && echo >> "$STARTUP"
{
    echo "$BEGIN_TAG"
    echo "do local f = \"$LUA_PATH\""
    echo "  if reaper.file_exists(f) then SWS_WEB_CONTROL_STARTUP = true; dofile(f) end"
    echo "end"
    echo "$END_TAG"
} >> "$STARTUP"
ok "Scripts/__startup.lua"

# ------------------------------------------------------------------
# 6. Interface web do REAPER (reaper.ini)
# ------------------------------------------------------------------
azul "Configurando a interface web do REAPER"
PORTA=$(grep -E "^csurf_[0-9]+=HTTP" "$INI" | grep -F "'$HTML'" | head -1 | awk '{print $3}')
if [ -n "$PORTA" ]; then
    ok "Já configurada (porta $PORTA)"
else
    OUTRA=$(grep -E "^csurf_[0-9]+=HTTP" "$INI" | head -1 | awk '{print $3}')
    if [ -n "$OUTRA" ]; then
        PORTA=$OUTRA
        aviso "Já existe uma interface web na porta $PORTA com outra página inicial; não mexi nela."
        aviso "A setlist abre no endereço com /$HTML no final (veja abaixo)."
    else
        PORTA=$PORTA_PADRAO
        while lsof -nP -iTCP:"$PORTA" -sTCP:LISTEN >/dev/null 2>&1; do PORTA=$((PORTA + 1)); done
        cp "$INI" "$INI.antes-sws-web-control-$(date +%Y%m%d-%H%M%S)"
        LINHA_HTTP="HTTP 0 $PORTA '' '$HTML' 0 ''"
        if grep -qE "^csurf_cnt=[0-9]+" "$INI"; then
            awk -v l="$LINHA_HTTP" '
                /^csurf_cnt=[0-9]+/ && !feito { n = substr($0, 11) + 0; print "csurf_cnt=" n + 1; print "csurf_" n "=" l; feito = 1; next }
                {print}' "$INI" > "$INI.tmp"
        else
            awk -v l="$LINHA_HTTP" '
                {print}
                /^\[reaper\]/ && !feito { print "csurf_cnt=1"; print "csurf_0=" l; feito = 1 }' "$INI" > "$INI.tmp"
        fi
        if grep -q "'$HTML'" "$INI.tmp"; then
            mv "$INI.tmp" "$INI"
            ok "Interface web criada na porta $PORTA (cópia de segurança do reaper.ini feita)"
        else
            rm -f "$INI.tmp"
            erro "Não consegui configurar a interface web. Faça em Preferences > Control/OSC/web."
        fi
    fi
fi

# ------------------------------------------------------------------
# 7. Pronto
# ------------------------------------------------------------------
azul "Pronto!"
echo "  1. Abra o projeto do show (com a Region Playlist do SWS) e salve."
echo "  2. No celular/tablet, na mesma rede Wi-Fi, abra:"
ACHOU=0
for IF in en0 en1 en2 en3; do
    IP=$(ipconfig getifaddr "$IF" 2>/dev/null)
    if [ -n "$IP" ]; then printf '       \033[32mhttp://%s:%s/%s\033[0m\n' "$IP" "$PORTA" "$HTML"; ACHOU=1; fi
done
[ $ACHOU = 0 ] && echo "       http://IP-DESTE-MAC:$PORTA/$HTML"
echo "  3. Ou rode no REAPER a ação 'SWS Web Control - QR code' e aponte a câmera."
echo
echo "  Se o macOS perguntar se o REAPER pode aceitar conexões de rede, clique em Permitir."
open -a REAPER 2>/dev/null || open -a REAPER64 2>/dev/null || true
ok "Abrindo o REAPER..."
fim 0
exit 0
__PAYLOAD__
H4sIAE0P+2oC/+y9628bWbYvNl+tv6KGbp8mbZJmFUk9KMs9sq1u6xy/RlJ3z1zbo6bIksQ2RbJZ
1MPjo8EBLpDkS3AR4CYBgiS4cwPkIheYfDlILnLy7fpT/o35S/L7rbX3rl3FoqR+nMFJpj3Tkqpq
P9dee7332vX79fu/etW9eBp3+/H0F/8s/xr6b9HvRqPZSv/m+7ARhdEvgotf/AX+nSaz7hTd/+Kv
81+0GpzMBifxRriy1lpttlZay/X2yvJyM2wv/eLnf/+//7f79W7wdXwQPB6PZtPxMKgFv94JeuN+
XB+edn/C/b/cai3Y/2Gzudz6RdiOgHWNRmulif3fakXLvwgaf8n9Px2PZ1eVu+77/0f/1WrBr/px
0psOJrPBeBTM48PJOJlNu1OLF8GkO+0G3YPpYBp0gySeDQfJLBiNg148PB12p0tssXs6Ox5Pg73j
7nAYJ/JqNB6M+vFFUB6MesPTj3/qj4NJPMSPbm88i4NSrmOiX6nCmpsH0zg4PekG33ZH8bCLQZwE
YzcaNBOj3Wn88T+Mg346oPLxbDbp3L+//aozGU9n3fuTYfc9v9SPZyfDSl1anqCvGLPoffz3JzFm
1XezuD/rHgxjNDPqBidxgt6nMXr7elD7fFAJYs6/i1EMB6N30tTj4eC70zgYuVEqlIazeDoC7GLM
KQ62XyVBOYlRD3OYnM66fcBoNjiLp8FJd5AEfZ0ne6rUg62kFxzGveNufWlpOO51h8Hu1qvA/Nsg
3N51j+J6bzw6HBx1ktODclgNwoot+3hn+9Xe/pPtHZQt9+OD06P6UTwbjA7HLFfaLVXqyfh02os7
R6xb+t2vSnhdqlQ6J91Z7xgvyvW7ldf337x5W6oEGGipXjJtv9r8YsuNo5QBbMmO9bspvvXHh4Nh
XPbGUq/LLPCr9N00HllCg5UGFL/nP8L9FdeW6z7ASk4Pu704OAcSladxdxJP64PRoPIDGtYpHJ6O
erIn0CL7KVeWOGXzEdMbjOvjSTyynQG8++hwX+ZcATCnByWtMjjEBpmhzuw4HmF9Z6fTUTAaDIm6
XpuojFYPO2ivXy7d7Zrah53ecJzE2e4H02SmX7E0QMMYtdlA58gs3+vfvZm+Gb29h8Xrj5cs3mht
7gj0xGputXvJ6fRw/07/3sbTvb1Xd5J7d2qf4Ql/lPGrYsZiZiMNcDLupfkgTR5ip5eJJMDHajCb
nsaVzMyltp26/Scz4vTlNybFUq6ELW1/m5YUDHz5w9CHO7Jv9raA5oc1M5kOxtNBHxJ0R0nEfWkR
/+91k25QDteieri8Wr+oBA+DsFG/4K8Vvqs1Q3maxslsnMe7aXf0rjyY+OverQYHxLxJuku5Onfq
/iKZQrPx6PTkIJ6Wu0BG93DgULIbbGwEGFrQHfVZAQ/Lq5mFCh28XfFGpkA0X2DFtveQ7Zm/H2wE
zTBTs5lfypZdxqDb706ENsZJcDaYzk5JG8tf7z6rBk/fY6PVvqoGX8n74aPxBf5+ft6dxtXgybj3
Lp5WgBS97gnRJ/j4T0PIthauX23v7H25+QyQ+RCUzmKMZjqKZ6R658mQv47Z+p3aGf/WjocH4wt5
OmEX/KsvnfCv4Xg8OQAR5t/ghv0j+X46Ox3xd/e8L20Oh+el4DK/soPETAD85STWFeFfpNXym/S2
VOkMx+dYsorb6PvV4Ew2+qQLzC+bGWV2OGkNWtBNeJbdeNyKC7dSd5jEuga5wcojdkqGAJ1jFBgs
iTlWvfTmTcn/Oj7lVjZ0cesi7r2ajntxkpRZjShRGkyUcZVkqveTg8Ho/uDQvKsGbQiGynVKXrNk
M1Ww+HhUVSyJyWU+XFblP1PUJ4gYxzUEEfjW6x5AeugOj8fcsQ77OmzlmBLFCWbSOx0DBwHT8XkS
lDZtIXCyetApBfeD591eUIpHjU5wOOweJRv4kKWZ5AAZinsnwVAIDP/tHTDmecqaTtYCUGaI/suZ
Jsuv75y/vVfpKMfmp8ocCfX4zcQfH1u+mqSXtl+dtUp5oj6Y5FgJSdGdeuYHKFOm/5i4lukn3wig
cxePM8N/5tsrnBeGi5YIH0KbiPJ6MHnrXnhkM4xW7tQN/POfltfu1KN2S77PQcQ1uiFAyHwjfr6+
LfLnvSB8K5RGZjaYAG17oGjcFYaqo0g5pQNmhXVAoLJYPmyAy4UMUORTSHAQS3RX2O1aBkV8n0G8
i7p2/YeN4L350ycK9vMD99WHqCuEebCEwRkU8ff7YJLIRnQbcFANYo9QcYjcdiz4ekDAxGwwR4Lw
8Ufw8r8VwfsHS3tGJkplvXRmRM2UBpr3/Qu+D80jcGc6AORPp8M5+nlwOhj2yxlJUDoDmG4L4DYC
w1W1FTQL2XDdQsUCCU3jC3SxweioDhijcLlktJw7SedOgp/YnALh/sXbqnRSFWE9Q5rfVYk8aOq7
af27KSXwMprWIm4A43eCiCyIYWI4sjB2JmaGX4Mho2yr1QDBXm4sHR1eUOLGsOa1SFUYUzURI2X1
ilSC0naIkqKYbE4HXXLOcDX7LfK/tStzUO7F1AD24otZeXaBeb/HlkA9nZffUPpWW5idYw4scBJ3
IQNDEJuyhbQilpW/3qMY4HNcP+lelFerQZkvzzG12XkF9D+CkPXe1elPu+euIY+pDrvJDLpi7x0a
a8zNgbUyXLZnhgbVAorgNEWiHjajEIke0SdaUfxh0e9OsQCVDPYsWUanSqrRSqGGbr+y7cn8x6dJ
vN/rToK/geRHWU45TTpkIipfCdpChM1SR26JDfl5R0uABrqP/iZwWo8HjLkBLPkLV27UGwA5fq7x
pyq69juYMwrgva7Tuf46ljJzmy4zYtt6yEal/ci1zH8eTpW2MwomSNnO1uarrZ1g9PF/oT5PueV0
CipeB35yQ3jNeN2Y/xd38WoaH8bUimNC1+yd+y93H99nlw+DzX4/eIjmV9F8VNwEN93BFDIKhIVU
JX4YlKhyG5Ws0XLVyYcNdMzW/8HweUE4UKOnqWMgyJVVrX4EYL6KvyW6poYeiGRXAquehVJG3NCd
Ren1ts459wUbKCYnaOXeJ4Pfx44EDEZu+7cM3h3j77DVqOSqgd4NfcqBWcrfh9AfpmVp9D6EfmwW
7fguBl3JNzIbz7psRRq7my+eKzy+sP1pHymhYitKq/JVSNyixo0Wxm056l7j91Vt1v0qWF7dm9ml
p5DAcaLtkS+P22/vF3wz+1lX7vXF29fv32L5G/NyWsFwKXFdcJUs9CoAH0HKefDj++KP/k9vCkUC
aP7Z//uG2A5mbMajqw4qulwM1voyt+RyJD/bC3fPY+W4QYEpEwpPAgtoao7kxsn03VrO0BqAvpj4
5zrNiSk77PFOP9CfjhOJkRT7tifyADhHVVqv5MawvJoZgy8KOyZwOul3Z9ZGZhTPPilEmUzV8GDD
X3/2+qT/6j/7f3/2/6b+X3iA1+rtZtgMW6s/75O/Pv/vT+j1van/t9VYiSLr/11ph8vY/80w/Nn/
+y/E/2s9quJXy7pHK8bNGezER6z8yrgCqR6hoUWuYDg8ExaP6vifvJlMx2eDvn4OgoxHUV/5zsLs
m9qz7cdbL3a36id9/fAavtTR2+DKwAYd2QHMw1rnufi4A0pCUnrxnNRpPeqexUdi/01dxjA2q1Vu
1tFGTz7+UwJXRNClgQ/ycXwyGYujpwsxqUpnXW/QnVYFhvw1/fiPF4OT7n1+pkMJw5lRNArEmzwb
TLVZyFDfoUHIT1PXhTrVE7iS7asEPU3g7+3jr5Fzi4vfW5t5tbP9fGt7ZzP4autfpZZtzAGG7IqZ
QRCE9WCHbnaOOuh+/A9U8uijPot/H5Q3xWpBYbDQe4/3O6cjerLFaz8ZdG2r+DfOrrIi0thIbvvn
5+f73HABZcQk4XKoAenb09FsbEIAVAGv20ajenAjBTooVpJLVW90T+LD7ulwln7tZIfrOm0a+JSu
RLcSIwYWBxt4Dv7He9svX6hfHS2iQdOedb0/3Xv+bP/z7WdbBZ53LfFo64vtF/t7m1+wBEb58OHD
ub1QxqYcV/jJ1tp68UTqBKbWgwcPFtXCJ1tr9++2X+1vP3++9WR7c2/LWMTF1MQ/OgEsGganNw1O
l4IJZnxClARV6K6r26lDw+Dh4IQGA4fSyQkQ4Jj29ndm71nb6+OnW4//bn/7xd7Wzlfiz4NdQi1c
SXx0CkROTMAFCM2A3kDg7f8B4mIBtLmXVpba7cLayWBkojLgDTwblwrCMG4QiLGzteuXNqrJF/Fs
J9b4i1fQ1Mu5sI1Xm3tPg+8buDEf+cEmvBavj+z4fOfl8/3dvU24FV+Je+/r3f2vtx7tP375Ym/n
5bP0ky51ZWlhAbEZ2xEBkegdUChvPwFMAWRs4q5A2xDW8mQK10rveNAX+85w3O3vniePxycslvzQ
AJHNnV9/uf3Vy90fUHvOHQ8V6XPGdkwWBYJMfkDQR//6kA9Tt1/onT2fDmaxDqsa9K8a2fmVI5ON
6MZ22JF2y/0rxiPurx8Re/ECyPJs8+N/+fFfvwQD65M9zmhB6ATTsURynUzo1k8+/mNwctond6DN
AOOEwFb5CdZzMAJTGw6fgniWT5KjxIed8KSNdMkLQ5gcMc6AVapmbCNs/PVt/rRuwdLmV9u7Lztq
lk1pOsOi1KB8OB5YYyrEjKCLUDP+xv9VVKuXch66rGFdXfTn9GyQ/nhRVzkGW/LtJTvwck8pRDzG
i1n8ZEC72Xj6vozSsDH58KHdiN4ydFEADwsOBz4Wr9ABOQ8cep4dCrNcVQoVeF4LwPjnf/j3hTAU
aYMRhpQqCqdc6IUu6GFrZwfrZI385BCD4GjaPYNYJh1zxIWWqaK9ajBuFwg8O53MIV2i7+cXbVfW
PCn57/b3TXERMHyf0enUx1xTaj6Y4gC/6HlJBQY2+2aUwgfPOTseQJrSljvfvWGoi8dgKn7VkkUB
ohZj4vbjCwgrSfnQBA4s5h2kLOs2evBQQgdy4yrNv7IijJ2FN9VRfO5PnIb006nGNLjZp2ENFnsP
siiolffp2Pbqm14RceXXNi3E80hs7PndAclLmc2QicfEt4pl6G+mnwlkhan7lTEP07eRMg5osK5w
yrqa+INNzyPkvAPkaHgamyFwY5ZKLhSC7RtJ4c3oE4xBI3YwJA+HMsNhv9KeHUjWPkvCiKLSPn7/
QesspgIGZassfXM6sC36VEAhFaNnDBiZSUZXCMqZXVP5aUmBafnG1AA6iXMqPoWmkfH8aiyo28WF
Iab+nv5+YaA2rKc4+NMPSxIkd9Q1F/tTgNk/LrTUky7K0hLHUS5t5sJ7v/34R2qk+Ok5XrVGV9dC
KpMSVOqlSqFfyKihAOCNWi9qRinNqzQePg1vqFKGobZndOY3ixXENyWPmS8Izit9TqkHPhdqw+NO
8HJiNe8bqbx54vmmWAV+A5oDyftNaU79fQMNFrFBQ4TDZVrKst36m9Gb0ZN4MobW9D2mf41ynB98
+cWYNgrGAaIewjJ7mANEpLNBIgF8WLT4gvoeH8TVZWwLSgOq1vlEH3I8PRnAsFIHJfjhguyzre29
L2FIebIZvHq2+dtn27t7wZOXqtNgHvXpZBIk3eHZ+KcQWjGXJLY2qaRMCTHOxrPIh6oRAxgXOTIM
wScRpt71ZGKOUheRD8TqPcR/nxTFy9m4uEQD4xw5RcNz5XTMI4+BFdJmj0r2qwHjcJOC6EENjOZv
Upu7lYINzHDB/mLX8aDvR1EP+sWERBtBtHPjomUs2yYwsi/hMEB170veWexNvU6zwyAGoLyHNJBw
qvbIjcyk3ejkhTCE0IsavJGLOg9eBe1UJfw8VB/s/s3z/Z0vXuxbVCeE67WKLn8eS6SRQvhi36hQ
OTb6fyeYaxr0FKHQr0MaWawVFpz9rPu2qDkpTG4fJ5Mug0TOsMPVklMKPqVl85sFWMR46aqE7S4o
8J2w4mTmGXcKsOA7mkU+LX3KRZC/S5+W0r+/KS1GNCO4U8W2PQnf/Q5+77xYmZEHNWRcK5JVukFG
VfNW5EMMIv1S3BRnX9yUvhL51AvwrajpKL9XF+5XO9yq7UnaTw8x7Jq9WrxRi3aNmXwaLr+AnHzw
SyJuvMcTV5R8dSBYmrCEiAO738RQdXltQEeOQQtp86W8Xrd3HGtM7Hw8PYS66fhEjTaw/ul8XQ2R
+ja5+cZJXaIaSneedu4870hs+KUVqVlThp9DLGmnHk85dxhgx9/G2GNwiUBCcqYFYUfQJfErDsqP
Z9PhvV3jzIHDAZSm6x3uu4mtwfATX2RNZ2YMI7bM4tG+sOObjJPk45/OYnAzZe5ThOScCamY6Ixu
MijlNxtX8kwGtJhyG/kwouzY4tExPR8L3EIjNzID3JsA7Rg7a+Qf7hjmYqaTOam9bvBXOIw2QCq9
Dmku7r6bQ0+dggyUu1vLixxAjhy+9Qr1xqeygLc9XP5B8tAOVOqP/y0sGJgC3U8wXp1lFw/icjyd
/STy0HF88Xg8RJRbL4trLja2cY39FaL6kZ6XMjqWNMf9+YK8Ji73EI3auPhc/mXsnznbyO07jejC
/gdJ2jRcKdT9jmj/JyIlZcIkE4+cRtJng//c+LBOsq97s+fdKU4j+W1I8D2dGiYgTyLa5g4AAtUG
yc7RiEHikBWnR6OtEaQKpZASh9UjFLwzPBAzsn02pVOUzlg8pNV5RjeTkPR5YiwqM3coRwGWN0iO
2acZjh1Dusb8edWpCGuZ/jHHCHZfvuBvhrHBOXEmYa0ncLbFU8a31cTrjHUv0TlDBebLnW04KaDA
kLaNPN+welGhsA1ogWC7wQjr36UnODgAmeWpVbio6KTVmHzIKNBMeLSYQbM8fVS1HlA2BXUMu9+c
m966mMGOCKUp5nP+AGzfd4/+2D2GKZeTDOqXZ2PFfrxXq9Wnr+/cwSmwO723n3pnUXqV/EGS3Ka5
cwe75TfYLb3OwXvG77kI8UrxxgEelkeVRa3Vm4doa6SHjQrPYXAZDOamDMqYLvD2hTmEJ8w1NYvJ
sxN/Xv+OvrN7lU9UBpJ21BZT5mGx2cc/zU6H44pvbD0GV5w7vfFpaaJbqtQp8exGqY/DQO9LOMpR
LakMYD8k5wlff1r1ML9XtgOuVD0oy3bdTsxmfcIWlTxwOhq+X6JEqcY88fqUqjmWZwQQkarSb2Bz
dXMuZK6FNNI+ZZoZKlC4YJ9+KI3flTrSRJWzRjX4iGXSl8AjQq0qU3WtpgjiG3hVNyKvv4Kwwrx4
AjJzMsCOHB1VHV215wcb7qDEcxMme6SWCAn7oGzEFkAR/gi+BiMMOxXqQLM296FGXKjFg8Cu2/Y2
ASn4twLYecEP5yM0KsHH/w3oF8MacwZbUwfk4uOfRv0BNnMXgg+/jiV2d2xbtJ9pyLBxKTjLA9FN
VKCSDSbBbjhN6AkBYSplo0lAY0p1X/jwD2ylcoNVRAuOkSt/EGC/JtLwr7c+N5gKsqAd0Vb/sFEU
p23NnaT+s1hOhmlxHHApKDiyse3dg6RsilYKyvVF9i/T8yBcpRZM68JtGNadY04GD2y4cT9nmRC8
eX1bfll1PIvHc5oHEFvBgV3br5bI7NxW5iB0jwOJ9Q+ZhRa1gNAPGEp3ps3gSdgf/7z0CIEjCGYB
dL9M63KwuCr00s7cPilI+DjfjFuIYkIhLWBUlfma07rya6GXVINhrLPv8CfeKI0cnQ6H/vHN9AhK
gaXJbFZY4vUPC3/Hf+y0rwgPLyQ9S95SkQZxpkKCrKXBrpd9tutDLCh1Xt9J3lZLZlD2URAovz55
GiZ7yiyOJ3inFfRkJ5SUHoZpaBbGUalmvzgypt+4Lnq+o/IjhJ/HL59vvnjyctfYL/lKDZmiOZL6
GSIilPBFqR7sTU+/Y6jPcECdcazhOogn7g+MaUepseTqMJBEmAKK8gneJxhtcPaa5Cn8z/8kzTK9
Cg67ndCtIoVgzp0ZOlMKXjD0TAMF3XkGKQ0TffCYboASywvb7iJULdje23rOuCJnQSqPbBCbIeAV
ifwCmeP7gvA5ChDou3tSD4xxG8XGfTE2y3TPxjTOdzU+Adbrn0Lm6p30vdwA1tqZCuTk+30THPNs
PH4Hd3Ja3EppqMDdiF+kvRX74J3oLLJNeFE3xiVFzk/4uSgmjq60T3sdbXUZo10prSILt6DKi63f
7C2qB054tqjeq52tr67q7zHo/sL+Hn+5s/9oc3frSa4F5anEc8nDQ5cCpOnMeBa1K+NZ1K5rYXY0
3CWmFLTAkvsv4UDf+wIu8OcvX+493d3a+jsZlGH2DL4EutEOmtlernm+fTE+v7L5tOn9l59/7o2N
lXc11u5GlV94dcfvTJSYogfxyy28fSD0FPUkOhDIp6kmbBu97mj7RGcU29YsvGwbdoL+s465qOVC
Z+tgduy6Ydvlw1FlKWvu1vP56ejAluYGqKZRG8O3Nz46GsZmt4g65g9fRO4wLwdL3ecwyO2/HJma
ZW+OLtBGS9tRuVwDqaorDcH/dwZk/XJ7Jz5E6eNymD/srfarCR6Hbs6LKtfCypJnuvdSBVw1al0J
DtxPB0OODvzw6+8ej8/hAEzGw/h5cjR3TNzEQ6W8HeK+Deeo5N3o356eTHbj7+QcdW6tu6MRWGov
/lsUKUvWMZ1VWsX+ZU8o2/HFM6tWl00sLvgrC0PysXU4oI4MVJquKsIUa6vcFTQlmVHkPBaaEM2y
QDDUhg87s79865WFbgEyW427cgNM46gyaCYKgB641DH1x1dU5+7OLLZLBlEE+CKwJO8GkzKU3coN
54sS5XTTUSjQNarwoLi3y7x6CmFqbVTVTNCGAhpCCvBQ8rowiD6eZlis7RDDcwdLlfP6LAYAc4SO
EmxawjILU0J4mTePXMh0hjZctawL1oO+QF2JgpPOV1XJRqb8wADOj//14+2XP0zYyYsZNo8GA27E
/jmPFUtXx1JiKeJRwoV2AquLoIRsuC2xd+L2hzWlpqUB2vp4eqTe//l40MJ4PU7916cMXTbxfF2b
ytA9yrEQc6SiGtiYTWP9kxCOU6nBpkrPAAtIyV0N8iupXUGOo9iDFhB0KbmKVdDEsqs9gnL0hNEn
TA4RDD/+Uc4lfMVpync53Gs6t4kbbUhGP82hSLGVzlI5XFEn5DNx4B7LQzTJTnwyPovdeNOVMQnK
emN1onlYyOlgn/WDfEB6taDQvmQOLE4ZePUhC20tzUEDoJzFVLJwWv+YqxOobUOGmHesFMQpmoqV
HM+f5xDSkZAh21dRxMRCEJZF96TF3lS3IVbFBpPr+FV22kXu40X+TJuA7W8ZAKVGLaJg7+M/IppW
grKB0Z8FW6opMS57EpuclXLGafB7g1tAuu6gbrY03p/Fe36swlWwLEnx/RlDH5lTTiuLTcFU42nV
fZDV3oAB6UwtI2VwMAXp6By0ruTokHIZXjlVqafkWLjHjTI7oCAOFIldKKwqJXpoDKvlrIaOT1Uj
vKgUI39qarelfCDZy4DWvwEDF9IANANz7ABzCM/CmQFpeTpP6QqWywSHUZAXT7Pg5LdMKUP7Pe+k
rH3R3CXfi5vlHHyzfbohlbYtLfylTFsjU68DDv+aj4pMqUTxbH5E5NbLl68CmAd2t774EmYPhm+9
ePnDlXfms/m7GKIV/xDLu/4p6Kd/infJSwV0HPfe6ZdHCLmHuxA/1XvXqBYkCJqcHgANjhc4ML5N
JD5osZ8D6ytlQFjsYAq1k+Jd4yxjVWkls2tsOh9pckO+Xxn7SotnJt51ND5PjRvZLe4l8WEWEwss
hlxlz3Jlt6kttsF6aR4ifSW//PxEV87c0qRqqpugzcocBK5shF36LfA520QmV5M9HXU20ENSEBw+
/vEIR9Joa+MbhmrgbW/QG7qDDgnckEjjEEw//nEyMAwuzSR1Jd0lTcwkeMQxVKMW5pXinvGMFaHO
kxgHYOOFNDePMooV0JBoe3DhQMQ0vuxIpNEn2TyKUlqkcqddOc7Cb5U527LEARizoFQU/SNcUI4S
u1+utqigZR9aNgsvPcHgtrhoqQsN1BnU1vLA7dwpxznktg0Tu/P5fd2+L/TgJ5k5mWLyKxtHpY29
i9+L3OYQV72JJNp/r7HWqJmrI47MtO8id2Q+u9JMzT+emqdVBI8eH3dHR7FEPpjafgLPnXj48T8G
JtL2OxHNO5JWBmI2w3816OR+96DL8C8e+xbTLcJ0GKiNp674zCHMDE7reR9XPFXXbZlwMIQTRF74
uLfmS7mo8rLjAWkmtb59bHjjF8lQ+hA0mg8OS/HETRdma+oAZYY8SgiHOh0ZMQGLiehA2dAbQyt4
jG5kzO02jqpgIBi+LoeZrsYZUKuRCZi3Ork58XQRi8pgvMXhhdwSAH/Hb319L8PJe3W8HD9kJ0YQ
MO9R/gKJ8HJ2keuIVEroPUJ1XSVD2OdrXMdG8z4o9YM7J/gu5cE7j5t3NlfGxpLBhTNxHeIgT01P
okELT/05/8/P+X9+eP6fCKnKWyuNcG11+ef8P38F/zI5JH7xz7f/F+f/aTfbLXf/y0orQrkwauIa
mJ/z//wF/j345ZOXj/d++2pLTl0/XHogJ7SHELc2SpNZ7dFOie/AHPDrJJ6Jsx3R1LMNZLo/rK2W
7Gs6nzeQJyM+59G7kg323iidD/qz441+fIZwpZo8VBlggkS+tQQCFghPFVlfp/JAA8HGaJxrtDuZ
DOPayfgAIlENgloNL2rIEsvSXkfv4yRX8aZVZoPZMH5oTCwP7uvj0gNjOE2mPTQFG3r9W5R+cF9f
8/vsPct1iBk0d9ZqB0ed2424cRiG63iaMCF153a4Eq6FPb6QszS3o27Ub0Z8hogy69w+jPg/PvcH
J53ba91uo7u8Lu11e3REo0q/3Ts8ZJGjMRo87K60+nyCh27Sud1rNNeiAz7jkoJR53a83F1pNNaX
LpfufkAUBXTGTmN90u0zahV/4UqDGtKO8uGAYWnTGt5cLnHdqwfj/ntO5TgeHB3POmGjcWeddxwc
TSF69zuQl8ucZWVdwnrMM6dRWYdFc4p8o+cdJPDoxyNOgJmWa4ewQw7fd5L3MCee1E4H1Zqup76o
Qso5GsfBl9ul6s74YDwbVyXJczXpjpJawvwtAgqs4bvBrKaYAkGsN+uMEHG7PvfClpx1J7VjTGLI
idR0uLCpjxKeGBzNCJ3bGMiH/iAhCewcDuOLdf7AKjDtAWTGDmqdnozWPWDgMMf9u5C6BhdijKdY
epowioVHDiF130+NePfpeIXx+O79pdtazvUlA7ULEjYmF8jwOUHvBNe5dsYFlGcmiO2EbXwmmGsQ
UI8wMEm0eWkbrtOf5VqXA9jpN4ziw9wSEnEqaRnizXwhvrUrfRuEWief3pbQyWa44kyPRYqcb0q2
QiWdcwtzjtzEHRrOcHS7E+I1PMRwqGlducXgcqkO6hAPP3hAiVAVIvmMGIAkPGy4HrbikwxyYk9V
FHSy+oz+6pxOGCzZTWJAAGeEiA9euz3kJ5qUIwys2j47r7Yw1kpmbVaxNhxUzSJGPWyvm43GiTUC
rinR9vwYAU0yuBiLfj7tTua2iQzNvUSKWeQ/HSQYGALEP5gOVgmjFKSWghiwQS8YnCbsOd+4tgJN
cvjB39BChEkI8quk5Iawnnr4JDvjW7DJweH7mj03KnOqHcSzc+TsWResrEmsWucAcCV01o+6E10j
BU2NtEoAI7uMwOjwBwY5jUle55agicLVZSxBOypaAnnGwAdQwmswboBW9DqwMfPQMJ8T13KAILFh
BnVaue2G45nzWGPGPYwPZx1gA8CSIEvNB28fTll5vmJu41470Bw2tU1PwcGHOTKLOdGO5c9lDV0s
GruD+Y/BRHFyF45F6IGa4mGOwP7H2QeHN0e4E2edP2rMfDeEElxTgpp0wsNpEOE/81tRhcN0BCLK
oXzYjxpR62aUAoOADRwlQNOkvBLc7HaR7gxtOwRvTQEaNQposRsYECFY1d3tj6/Zbcat1jrz56BF
BAmSQK/TMiOcZIoTGjxMNA/08WnvuNZVfgOL74Dp0fjgT6OjZ74+wDmJVjsHgnYjXqcT4p4SzFiL
GTTP8AEfF8MCpB+TcM7ed+qrbR9nIqK7bRXE+8PcTICjR+N5Qn80xnCAFRJhwVBRscVtv9h+vL25
w9uceKqwh/If/4h0cEjyBiciWWZsLdgmSEM86IPRxz8h8lJ56MFsxMAPCV7BSnzIEMQe4G938O3e
YbzWX1Y55xhGk/MOHPNIld6Q/2FqgRGh2m0fykF90Bt7G4scILsz13Ms9hCCH4ztuXrhSr4e9zOg
upAN14/Hw35A3/MwBTTi27FbZvG6DD5LrqdHB91y1G5X7X/1ZhtczjE4Eax/U25472q4oIwMitTM
9Cg/GFOtPc9VD011HY/7bDYbK1dxYecJXOmcbRfyyK8kdiUoI8+9ivqd5RZ2U4UiJUnDYmqA/+i4
l1WG/f2D7tvmpbx5QYqnb1qXS0p2NCCCiMG/PpCnYIHs9qq97zAPjJMG3XsI72NQNuxk2XlcmTGQ
KcPrfG6mkpYSqJZPoNpGgllIkoBjURQt2++Wi5ivniiKMYAJfIC33sAs6h0v4ClXMpE8X2K7UIMs
aDzEDudFhQXUv4BvUBLjcQUf45tFLMjQXg8ihkjOyy0OqiirnJYmqQ9XMdbVmzBWs7z1Puj/B0fq
Wva1cNIMlzmMWlHPfjZU9woxySsWcBGr2TecRO6Vgs7jOwYY6ZtVcFzskNn7DxYq3EKKa3MqwPo1
ILL4neVLduQTXL0S9z8gC65ops0cOwUtXzffauPDQ1KhWpNtepwJG4c6dT+FbrPt5ALcznhiIkLm
zh7xXFNJlaPjOJ6ldO9wcBH312W7NNYFkUVnld3VyIrBjagZrVoIGrY1N4Mlerg85i0/QOB6Zfnr
HjwKZ+WkexjXsBu7NaG2ZjdXfJoqf5Fu/bYcho07C2hjPVxF+lCIwDVAbv33NQmC7LQvzTQlGaNH
aSmY2G97NDvkhdQbqzLzmlB8Ylt+IWQg3f956ZfSdEZ/Wf6REqP0+jWVyiumo+qlETrMAnNX+1qy
31ahlluXz49mo+R7yJ2pvOmJPGa32OZ+jAQpIvlCCXLVSJA/Sjj0Bsr4dORK+jAvjupGZAzRBCcI
sddUYPmhmp3PC31hnROS1c3KxBnN39ukhVL7+jXcJBW2xCP4YR6RRKtMjuGhftdp5KHvqt+medCw
xPTlZChbZN6otbCZyfDV2LDAqxnQvEjUWhWRKLATQpxWxjJ0ab8YDMyAmYI5Qhx1GqnI0Pgx/JxI
ssF/wd7Ws02c/UI+q80n+EPD2Wb3TSauSgdHI7tM3Ds8HXWZYsqpfh//HQLWGEzdZxJ1lc3wjqa0
waxrWgcCWmhAGAUyCS53howAhm021kDLcjorQNwIjxlT3RUbHHV5x1JTTAet6E6FgmWuLLOeiXQY
mNKNKgpVJHHgut4nkylPtpB0SsbWp79KuNgVHEpmir+5YLJqJRFijblPmmHtjr6Qb6zmfeHj+g1s
kASKUScac1KupUuqbRQrxXoQEZvfiIM36DNPGcz+zwq8SqVvIN4vqGf1OiPfhyrx71Jd0jfR5Y20
gkDzlvigxWMGbpdikhYKmJbiC100EUNE7hCgWtFDUZEXfuGKQ9oEV+9UMkJ9kdCR4xSRcFX8T3pa
aHJcpb2r3j47ri6L0TG7WSFLDd2yWcUGSq5TckRQk6Y60bpXoKa7rSOpJiD5yCAW2dzQcTUMMQRc
E8cx5BRZ1MzZn7Qeld5qE9WoNVd0YVMDJtkF34ldsRjZfEajpJxB98Jslk3lvPVN9s7cQDgBuLA5
lIYMRewR9o6GPukRTRIT8NYur0LECWsE5Z3C3CBn/3gVliTZuCm1Al03s2xHllyZrZZnkDKLOTN2
qB8K0CJKraedyApmxavX9CHsSTUZ2OV4bNbqSLl9fnXFgDnfnux2XRonBhjLmPmc515rqtr5fH45
X3jeTmtnJUpM1mNCgcOKIlJmlJVyiZHyXlTJ7Iw8SuCULLbZ8D/lZ7DslbBKS2ZEkf8tJ3NTJNSZ
5AVM3+RZCKEM/uKUBmW5SQxmO1qIpHTBTruD2TyOpiw1h6PODZXOwyJkBgNXF2KgQXDFoCzKrM8v
i8Wg1awguQB7LHAKkCEy4y7EgTUFYHZBF7pSVMqfV84NGfeRfc0Aaj2n4BTJV3AZq6f4wX3jSKeb
Fb/6A1zm3hcHN9zQGL97Y6QMeJvxJvuJVA+l8UZX8KGILPIZFDBJUIIUpuTaiZ/J88NXEkFmWnR1
WMosdOnhn//h3xZ9ByXHULwnupTs4PIVzCBAh0oPTYCbq6pIU3pYq3VqtQey2x/aC3EAJXn22su2
SBLmmsT9NTbqMXhwII1Dn2LLD+4fPHxwME0Lfs57RcyZP2wfU5qPzwSUOhjUsn16EyoAhoQRP7QX
myBr5YGC7SAdua4zl4YPQGfThKFyAkSVaABEmtftFGFIxiL8m/8dsMDbhwZC9j6gFELaUHGrkA5K
tr2jcUAzrVk88/LQXzzp58//3f9pTfTapcITLfEARunhbAxqk/auY7tqEC8ERkVT+1N2ajZNzY2m
RqHQTY2m85tN7t/8X7j4dsdO7SHzdk+vms2D+2bFijYf5f10K4idrvRw8+i0O5WDOi7L8J//4X/N
bI/M5iYLKOXQKjUBlR7u5fP0FOGh4zILt62znBBdNe8ecwPJ9c/2GKEck5RI6KSDHjVN0YSHAuXL
QZd0U2qZREg2aSSRMqkv2PyOyaUkwFtK+fpYjBZuOdWGUXqor7vTLCIU1P9i/EOwfO/lY7ihnmzi
TpibooNHBby1VI6SAziVcvRpyNHQW5wDsxn0w6uxBhJpV/MLp2nA7EzMk+r1D//8P/y7dNEy1Dy7
WXbc4QTi1AZuYGUmTZfT00/GKC0Vbtf/4v9229X7NuPmDjbNSbRp4Ray8FmyMHtgw6bu3w/2TiV5
Co0HgTk/iDhtJebiBjTHtaFTDQz2JVSuBh//eBZDRj8ajg/kZiaR2RmX5ee7K+NQ4MZDHEC1Zg0c
pXj54vPtL+wThCbm75+567bmLtta9+LZMV7JvKX5hV0yLRMc9gx3yWljT18+e7L/nBcdwSm2vijf
PFrTe+AE74RkyIyFQiFmCPYSvRbOtLopI5TrkxYnsWerequSJlJGynqCR863m4vizNFkgfGS3rCH
bAsLMrgwMJ1sLlNiPmELi/GwTKbYfH4WFpNANSTabYTLpaXL9SVvbbZw0BBH79K1gcUJ7gFajQKm
iqpq/i08vX6LTJXdc5d51X7XNL+1cF2qTmx2AD1GB6nA/bE7m+r1ZiUtytMGe+KIg7y8ac7d+efG
pHn7QguYThBxT8+pllnPrMQHTaCJoyrINXrZ0VRJPGLNoyfdk7HkpefhLtB49YrgZCsMCIV391Xc
QJlTwY1JPTdm1oopoi/Hmjf4CaZfh/hZrtivn2gqcuyL/rh3ypsxeJfE1jDmn4/ebzMtQCWzLl/u
bT/zVsWd3Ds8we3OokEMDsu/HCSfS7owvAr+/u8DydqGEygKqUD+eO7ddi7uGB3Rce4TkL+JnYMT
cSf5L3fkCwos83PCRvlyuZG2JqDh9HbN8bxKHaK6HNxnLuxSoyRdm/wQx8Fn+O+e5PG4F+Bgf8V7
SDCVTsFLhgw6KCD1J6EAP+57SdisF3TN5QPljINLuJt4ri2uuJIJ316SFuYTd8Y0LnSDNzgL+gaJ
LII3b0BtSP2glOiVBvZISTqYU8SC9MpnafMGCGcVJEfDfujFZSSsLNcr95EurHyCHSMUkqfYsB1g
wPwM52/xq2NfjfTVSF5xBj5iuOzsBcgxHtndWeat2wZL8Ke0621em8FTFiWzp/G0bpBLmvBpwbpH
C9bRAs86AsdtW3L2X1fEVOJx1Lqkf5bxaIl0NUypD8hTYw7fSNDmtAN2CaJAKzYytEq+x67HYkrB
pbZkR8N2mKXiM/1LXtdPusiBMiOgyx9wTA5vNcFuR5BnYJLABZcVohvmsxR4lCxIZ8c5YbuXBQGX
vNvo9PsHtwcMAD8pq5gqNSW0nzazxy5Bd6lk4avjHMajIxzS0oQN2hIpi6MTPbkMzJAKXAE1ONOm
cRNpXbKeGDHYvsv2JiD+m78JfunBCNOXJ4E1Zy+PRDmHB2fd3w9wxB3fSsXStR2DTBAKNKDx+Bjn
nst9+eBWh/n+tpAfo1xOmKtYJYN0plM5dnyDuaJgXeQfkyG2RCtEKf2mkODLfVKMwbo52VlO6iZr
MUuJIaCuZgVqn49NhmNTaH3JG9ro2oEFo+yQ4HEq8WV2BQY857zuN3xyg5ZPck1TlpXX2cYTweIU
DLoSZRwOH51UPBi4tJJkEibB50Pk7rFpQgwGXz+wYXZcmjlz3bQynBud6xfI9ef/6n8WhPr433OF
zChs1XTwikZDM/pLD3Cz64c3yw6PtscS32bHJTy0bpN7VvLg0xHM/Pf9/hYzdT1jUo4Rtn0Jl9j0
3uHUYdlDaRE/TKLYQJR2vTExRt73U964C2EZKfVFuhYdD1PQe4vSa1clhSEI3xkTUkHKvrBZUrCM
qVjBa6FFi+PdEJQ5HgStdsMn6nIMFpPZZbHywEJz0a7FJHXfVmQPYB7GbZ156KgQ7mdzvCeJHrkG
iCZ02THG7uQrZK/TCS9RgAp8BA4qyWJ1OeWkiNBLUdykfzwYxa2ygJAV0LGJY2odXkX2b0upXIIm
pl3lV0p0c82YDSDF6pNTnJv1iTIFkFQo/M//KSDiEnmktkn36XaZvLR5Um0X5tlSeb+ngu/SoUmL
WaaBoJIB9ihNd3zinSEupSRXR5HppsR0BfAGJzJ66VTzS0stgr4uOipT/0qtbxGlVC7JdO2aqA5c
qasSjJK/zAJSvkvh7GIbpgnhhSmSsAVEGDdxqesuI5hkb9JDDLE+yO1uck23iUs1R66LLtXOiseI
+Nlm0A9uiU1ZM9QvBnSTGGO3DuS2IA5+gI2TWXC8m/Cr5hwevNXMvfr6QfoW+8bgk9FEDB5lN+lD
q6fURRmp5NUWlzGM9XSItj3ws4sKJCQzfOYHSD+sz+k/Ru4crBt6KY2alxBq1pU0eZeQIO/tEWgS
UlaZ5GyTAQRfnMXndrG0aERaNtBbT2G1GqdIZgaLpisVv5/8V7m2xi8hvNDRypR0qHs16LtFFTcQ
DpbHOnto9Pm1wpt79ypef4O0p4GZsQy7g9S2SE/A7Nwf/yNSyXZTRYSinuJnqXk/bBDnEbVQyp+s
0Svf4d2BUq9/jZ1Jm8mCTEqxsqCu2BcqGaTMb4oUMeOhUkA1SlWKJUOUmpchM0I36hC4VP6KSnNe
jfsiF2UA6Dchaj+UJqs6FkBfMEmALgXvedvE8lLWtB9Fh6TjXv9ApAeNATVTCY2Z3cUkQlX/LdMH
zhfzdFebMTxDg/QlkyR95r/oBL6a2pu5ROOfpQPEsZyqr/LKDO6bcnfhdWyIkiANFUOXsHUITyo+
B20h7aYkh4HHO6WsSqFqxgfDBokPua7UhpJOB7SA0kxK8saJ8m9uCnz75Ybc82Z1C9FuSD9UU7CS
FA1U73flDN94uokspSVx8aF3J7vHWdmd2c5Fznom6o0kYS2XNMYWMtFAtE12vH5FcXHkqPUoJcem
ooDxqspcobnKD7w+raSjgDJyhlMP0nKAFNhlt66B6ch8Nf4KZ2ihMR7EyOM2oC6aSHpV9CYxj52S
xuGUXBdo2Hrw8gvmxveZj85yBYsnqjjF4ECHKZCpZNelXDooZaY0uljQvuZl7JgXjbdaaXSQGxrq
f4YfbjCHdNM58ltSiSIlLewlo6NS707nBDOdyAWJ2byJ7ll/wBKwlZYArjrwGb8kEA75AWcikYKF
9mNkUpRLcilysXoKcOsErRiVTqKEgo2iLa0hZoEhPom9heC+jNhubrMbRTaOZ+7yPUa42HyGjho6
NraAI0nlRcRRRu+cn5UCxYTVVaBTNv7hplAqiSe1dC2MYIy7fiTz4nZO7iXOpB0KqszLfo7u6qEh
okzySv8uW9nSOk0rBdvc1MPeM3/ZSp5jfY5Imr6gce6poBl0j8bTLnXPsmedBqWJqA5nXy1XxA7S
VUdDfCIaq7ru+eR0FOObvaJz9WwFE8+pII2JYlhKJ/9Cd7uN5KdwbVrxAERf9YIyGeMgLi5/9RIW
fblBwFy6XGAnPD+f7o9HNE6+J77hrlk1KR/KJU9qzAILHEsaan6tI+wN6XwkX2Aq6/5SghslDnUw
Oo3Xc7o6v7qKs1JKcWcgS2rp3NvZfIER7yBZu2UtvgNBTIcgyqgRgsaEDccU1K8g3z9HziaWiN76
X9XZMHvdestFJvIqd0yTH2VdD77N3lwEYax+wk6cnJ6OHQ4ZQHpvq8R9wgHKa+PUyllWztCDmoln
9QSmg7jcrBhFi5BxfUoHkenAZSqq+Ibds5QxuiHZGpIKicM5E95vXScQCj23ytl61qfizdxd7TXf
tGThzjZNl0glTTRr5W0YPAa8JYtXb1r/VzaSWe4I7jEQ0Mt+VXZeFrZPvcZrOyvxOLQ4s+jVKVXy
GGJaZQ0nIuDvLMn2dTLfcdTxoAJiz+tjYXR2LV9mky6qa+jMfr90lqvL7O6UTMm7RRsSbHdXYo7K
7wa8ek3C31M1ITHyi4YlyRSTjKWLtYToUCWhhCMvOsbYnOSoFJ+4K0oigKJvyfgJH0c5NWcZKUPs
s9m9oV9wN1Mv1vR3ZKvO+/UgaDYaDaPIpGn1/M32EKepGiYNajpxbfAzJjbEuGGbZorYXWQHhfd4
6zcf//VL3o4SWKqmQLBo+kuH3phVNk2l9Ne6tj8eYpAObf4ItbX4WWDT5F8BJDcYS3CQFlTqz//w
P+bSojIb8p//4X/KDjFviM8Px44gZ513beSLs3VcmtVuNLJ+Q3eFTN7b7jgvk+nJMmc5XzjPDNvO
uUmo9OLNobm6Vao7mNv9yullbJTeGjyQNVj3MR62R9x20QNxIjuaxt/hQoKtvfuWrIoGZUMEqFEh
g6W8Mx6x+Wz2qVPUyRi+SXSRJKs0RaU6NOO41E9MOYye7oOS47NwsPnuP7OZMjsmFWYltZfw/BEN
X8cQZ4Iy4snz6eyBoYiIqFi0s3BN2zbxDJo4v+Me5Y6QdY+Qm7vQOi5bOeLFZzYGKaO0+kbmD775
ApKvD33nMh+ojeB7KZ/vBOGKFEFtFvvmnWDsoOIkRBeflZfRygOnpdcDp6ZTULe+FFtdgreK5FKS
WfT5y0IzaGYEmepwI5RLBJiShpPuu3hnjFyT42lqpleGsTUyZibnNVBSpBe3Io2mOeRz1MUllbxm
yV66bZwGXKkZbmViMnTlstpMx9yH2RerFS2rY/Lj7gxBzbBuffynIVwm3h15vJWOeezhHjumE/aQ
RrGzgV4OXM+wsILZLPaNVtV/YdiaAsr5S1VdMaG+j+S8ivObanPPRLpMJIjiESOJUfDxkAHYO0Ak
n01pXN+Y/PlcLgSASwoOnKcSjm3dKIuaqWvU9ro6QZgrgTcN9AXQfbsEegWgWaXeGPcAu855UGjY
nTi9VDVR+bsXD4blZ3U9jWPHgXFWrgODbRPYO7nwQKKeVN/IMXDmRHp3vK1oKtDZD3hcC0Is9wDS
mxuB07Ht8Kvp6E2PUzuxh7natWC1YmYnBheuDFTlaQqIbHls1GWfiyI39ZiW+Gf8PddSbUM/yG2D
/H0vWOWOouae9ZeJkTO97IuvFWkFZzPhPcFc1aw4dB0pM8e8PYoW54nZVC4kcMTsCgpiS6ZExG2p
K7aNFzhjcza/kq58U7Q4GeStLL0HEmvW1+CiDEP9ZY6dffBFFCvDWZHKRXAUCFfGDeHo0txdmRKm
aMhSvZQLOsmxYhi/ruPGlu2WXK5ru2UyEvujl3tylXaByM6Y10cSclmOERJ2knzOlOwjgSgRjr7n
qefqUShroK2ToT6IksWSdPYMkcVjDw9ww5iX69lmRA8tQAeTSYRguTRG6nmXtck+ABpIOTNOzbmx
8H+UfRIfdqHtlzOGRomw4ezKqQKPdw9EjMKE8wFA0rviYiJZpHFCHkmnS5qypERIkXidJNYgkJmR
sMh0OkuqiCsIEkZoK3Qs9LLQuQ42OthLDsF5u4PgtYXMKa+Zsg9YCzFm22cTIf023cVnso0LIB2f
Vc06V7JRa0iKJ7hisOTGq1S0QnYyirEeMqrFSIL1KzY+wQTH2kcrF1rxT/LgoCHGseo5hI6JX4Cs
MBma627osQUVTm/HMH7caqBXBXRNUC0CKpFtEpxR7mXUG3LogbM+tfTip8r8uNUUaAdavl5Fob3O
xv52GECaqrCkWVdJ7FL8CjJhAzqo3mHQE73cVzzW/fS+TOaZy8GTQ+S64D8uuW/ns+MzKfAzJdTK
lylRkyJZKNn4+/nVzRJ3VLSlTbR/5YpAlpTgV8zEoUzIR3Nj58jEtFB2i+WNDXIpIVoM5lVzv5FI
Rd6sbCR8xV+am2t8Nsu/Gj3yFMC188VV7aSGtCrX1iyNY9wFQKGycDHD11O7Cee3YFbvNrdxeZzC
yJvjEXPKpxQ/nT3+g9ZZ9oygVXFHrM8Xudn0rDng+1U3+dPDxg+oa+7ma3pVxRQkgR+EjwRE5Q8J
6I2xEueUnjyQUwVDe9xgagJAEwtGz2RNWT594mKyOy8z7H1zwO++5tT9l5z/919G/vfmfP738Of8
73+R/O8rmfzvrZUWMhAgE3cU/pz+/a/h33dTXpLYj2vPth9vvdjdqp/0/8L53xsg3ss2/3ujhcTv
jbDZiFZ+zv/+l/j3eDx5L6lOED5UgV8kjGrIqwa59FUXh0ggfH0B0wyOkBzjYuZXW1tPNvc2gy+e
P3qqqQUkA9AAB//G04RiWYws8rNJ0rl//wh3mZ4eIKz9BMcD45jmyftwS3w3lesaA5gnAuk2Mabe
uF9fWtpBKoNEG9R7fPs4cBfz5kaEt017evvyAe7AwhkPpj9Dn7wzVa7iwW+IZUu4mH1AIyEbgJmS
DvB4ejJAbrQ+w1XPEKjHm3a6cnElGhkijw5FcsykL+m4EqmEsNQOQgruBtkhJXRJm7HI1Zknp7Rk
wTSNMbJBXC50xk8GqFQfcaMeDBRwqR3jTJ7YIdGG392onxsLeoQaSc2yXjQEdOXBwA4Bk+uf9uJ/
jlEEOrklL2iraxfoPmCP6CQUOuFZYaRuT1I4y+KwVX8CMqcXcNGyEj9KBBBG4/ALwZi2P34ToA9m
SQbb0N17xEgRPzBwXvWKa1cTuaUI3Z/g9GmgEJklMm4MDThmLw8DDJLx4eycS20wB3luoUQCdVBv
QISaEmlGij6J3BS7tLT3dHs32H35+d7XmztbAf5+tfPyq+0nW0+CR78N9p5uwfv16rc721883ROl
aGtnN4AzjB7EvZ3tR1/uvcSLEoIjtndL/LC0+eK3wdZvcGZydzd4uRNsP3/1bBuNoXWI5HvbW9Cp
tl88fvblk+0XX1QDNBC8eLkXPNt+vr2HYnsvq9KpqbaUVgtefh4839p5/BSPm4+2n23v/VYG8vn2
3gv29Tk62+Sh073tx18+w8nTV1/uIG5jK8C0lp5s7z5+trkNnw5uzX2BHoOtr7Ze7AW7TzefPUtX
6dEWBrL56NmWtvbit6i4A9GcQ07/egzoYAzPqqwIzR5/bP1mCwPe3PltlXMGbHa3fv0lCuEjjmY/
3/xia3epfM20AffHX+5sPee4MNfdLx/t7m3vfQkX1BcvXz4RYO7i3jTwtN31pWcvdwUiX+5uVQOO
XTpGEwDH7jr/fvTl7rYARq5b2/nylYRQYA2/xtQxxk1UfSIrBr2Diwawv9z5LRslDATA1eDrp1t4
v0OgyYpvEgS7WPnHe34x9AdE2PPmGLzY+uLZ9hdbLx5v8etLtvL19u5WBeuxvcsC29rt15vo80uZ
Mhceo9I/t3eXLFZWZbWC7c+DzSdw92PYpjDWd3fb4IKA7PFTA+76z6LeX+2/n+//+vn+rwL9r722
Ev1MFf6K9D/GDP3in/H+r5V2u3j/h61ma7md0/+isB3+rP/9Jf7h+upgD0K4KmbQDA6m1CxEScBB
A0rXp3KlMCX1JtNLUiN7tPvEfsepy3ddxgyd8y2u6pUWYU5ltPpIZHYczEhVASTXRPhQlUbZIQX3
B0dGwfyV1RNxp+fD+pJe0V0LXg2ZTpsKDoL3kMINF5GPVdd6rTqmnkJEFxNcQv62TAUU+qdrzCii
g3Gqft6vsPng5qrvj1B12VGhsqs3kP8EGi9a+SmV3lrt1o9Xe9nIj9V8iwfy/ZXfHz8Wq/9qSz+J
CqyTu5EWbMb/UyjCZgI/iS6s+PtTK8TcLT+pTowGfyK1GC3dUDOmfaxAPZYGfjINGa39pEoy2vsp
9WQ09xOqypnJ/hTaMhr8UQrzkvCml4iFY7rE8/H0HRNyy8uN3L8ly2Lh3EXWixlZI5y8DCCYOcZb
ZVzk6QnpzjlI2JAn5N8HOAGohVgEnfQ7ji2G9eAJrqPGfsQ5GQwjEdIf9xD6g8hIIWcnpNTlDZHv
eHSJFNO1ZBvZEulPwkftq83plLet6xEsYX24LYM3D8SaHYe3jJvszYFhcVLvCzutVRJCcFAQLCF/
YE64pJvBrwjtfJfk2uT8EBiBkxvvbUs7ejrayCTSBqWAmV9OyjIQRuBKgUUI+ilp3wlyJZEAInJE
MzojobT0OgJ7TuDynQrZ7cfqscVElsyKPo2HIHKBjZhJFq6ofPg61oMHOsSEuSmO8w0s6T3yiL2s
Yq02TkwgZvXERDGa73Lwt4pLn7SEPsqfeGfKHLxHQoLk9KAKhreRSI6nur7Tv/nJ/IkSptIR354w
5VGVHLM7szWPvOL63TxoMVMdrKYnp3bkBE1dH5fsrC7G032M9N0pY0w/XCKkYekW4PLoFGcDEYpx
yDVDGQsVEUEAsfcmz/aMkZZIzTAdY50QOG4ROalLM1/HEtmDkjzn0A2i9vIF/gtMjzIiCIOUkhDh
yyAHarLghNxGXR4AkiLSFrIHzo4h4ICnYUDrgnXH45lcUE/k4T32qCMhZ7zNQVrSHkx3Vt5iawhP
OB0QWODLcrHPwWB2PiDXnXALkC1j1ojgiKcjLtxgZiTrQWzmtgtywYTEbpQCJ2HiCNh4z6sj8W4y
1is/0BEHnJn44JAhMaZ/xJpKXg62bhDKHU9AT/tovNytHlSWbpnPeq6OcajuFUZ5JsfaQ7zS/rsS
to+BHcgfXN5bt9BxuYv8a1El+AOiSg70TwKQX2+5ls0f90zD/AjhhL94HFpPundxDjbiqG4duHcH
6Ts7IvPH3SBaso2YDArayZK8FMBuDs+JXwcGBS3OLECW9aB7Nh70SZPeo63hgIFKVDDmFhSAJf0c
bDR445qCwoBSIp+B/bekxLd+iVv4+PrbtwwetMswqH5bcbNINxDi/zUgWuci89H2cSJnb/w0vtiT
65E/LN16jRO0bzdK1J5L1del0DyEfIj0IZQvTfOAL6zVksdQa7XNg9Ra1gettWIeTK1VPoamrzXz
ILW6+qC1DsyDqdWTR9NX3zxIrVgftNaheWCty6Uc5tqJI6eXl2IvhcXr/luKu6pHyWduEqMeUCmA
smXldDAHkbJPT3CCIbhI5XI9lYzP3/RxQd4s+aaeH4Y2WL6oaoGK3WGMS1VaWS7duShVL3DkqMYR
kscfxxdLt1iCZBa5x0pIv1eq2uFLSRRhSTSfLfm7xr1SFeerAiE0DCIl95PAwUaylCL+pAw8MINC
xPltJOup14NEUYc7QfPp51mSiAEIOdufvZ/gYPDheH823heGfVFWry4/Gkq8zwKcIv4uV6TVvmwr
7Huoxu/AkzBjCUjjkfaavh9l32OShLT2we1nrz4KLqrk5ShpIyPHdg1nyoxwQyRyqwfhLyugiJAh
eHh8Q3vgSIH7GzKOuUVj/l8zq33bXVmfq9p6FZ1jLfXd64u3r9+/VUqT8OTuBtuWPiLSv1qkYFUp
YZcSR9i5mQQ2J3Vt/NB/Tu74nAfwKShSniF4mYKDyXMEeGYsEP0CAq9icf/XO4E63/eo8ynMaUyR
JllgMAKjVbGvLAvG4RNDVbusVKUUeR8i59DxnDQoM5fmyppQh4xMKhsEQK5vnBVSAIkwcEjcHYws
huCcOtPwyLDrS7mN7aDJhyNwPfA2RZJv8PsbsensxpZrR3ba1GXrlCWErya4MY2GJGksrKIYF6ol
lfc4ogESYZurnCCU46TLsXnyTDFz2AZj1z5bLGMgwClwSJGo+Ij9/LpRW3t775OSY5JmC4PP8lxJ
QenN2r8KPrlz5279fuderahqpFXTFy1lG7egRiDcvazZLGGV4yE9KBPIt9RXigLLFB6QRwRpgrFI
sSMoo8HQkg7Yxrp6nx+BaPBGZeFawT+n4fRsLV6kYgX8PsMp1azSQTrT8htGtn54oYQYzQu+cdtd
Yvvpx5H7aDcOPt4NVt+8Ecuddjaab4H98vTtNKY1qE8i1PJQGZuERjImY7TmHpMbR/GoanZCdybZ
pqG+mGvQoNGwQrhcnSdVdrfZFlXron0Q0ubxuB98Q+TQfsqVbyrcfqoyaT4NscN5cDsByRzgULkO
XwxaJzgeNXMTJS2nQGkJpL13LGgSXyfHXfcCiW/FLoUEVGqW5RiRqFAMU6ZxAwCzVwrbDRv5hkNs
HN0JnWAVRx+7o28HeNtMV0dhI/JcukswO+T8k6mZDa/Sm2i1wSefvHk0OHoz1EpvDnE8+kPZIMRt
D0lqWNOaeZ9ZvkskvTLvCwB1efkhU2duxpeXgQxgKgP45JMlD7PBeKhgjsSWBupyki6erGcWjzza
6qNI1a2Bjze5spmG6tCkhM7PcLZRTXVCK3EDqaDEOQFtN5pREhw1t0gFY/XY1OXuoLlUCHPXzYXz
U2qb2cTlgm0ozITkJOUyYa3VUNtCMT9IApQIys+e//pppW47OYZp1hg+LcesGhXn3LzveSTIAxjg
DWCM1HpJ2l5Vgp8EK7UwtJTZVYZgvnQLudPDtSpMn9zB+Nnkz2DtsooPzRYfolX5GWkh+YBrlfHQ
ks+mkH5YbfBhWV61pF4TH9hL2JDHVellWRprSZ2wyVfm84p+bsiHtnyIpLFV+bysNdb4KmzLz7Ch
zWovuPWUL1flp/7dkMaiFZaOZJKmZhTxQ1Paj/SVDD9sSY3mCh+iNfnZ0Hqr2ktLQNKUmUctU5N1
WsshPywTPJH8Ha6t8EM7IlxboXxYk59RUz6sEvitNj83I/nQbmovy60VPLYbK9Ikf0arUmclYsvt
ZamzJp9D/SAtL0d81Wrx72Yr5IdVGcvysvS1Kh9W29rLmkBpJeQs2iH/bjUIZcCNc14RULaXV6XJ
SD4I+FeXCZhlqddabvFDKDBek1fLy9pgS3oJIy4sFSXpi421m6usI1AOG4IQK7II7TXpvsUuw1Ag
vSrIsRxJjXYz5Ic1zn51RecVai/L8ikSWK2REAcrDc4/XGlizuiLddZk/iutNj+stvAqbBGfQ4Ta
88MaQRmuyat2S/qSZVttKcSiBjs1fYUygDXpJQrX+GqFqxhGTfmwLB+aBGW4SuhiQssyCE4yahGF
QoFY2OTsw0ZbIQa9nHXW1linFQn0BDDRSgOvopA/w7b8DGVdImk/EhQHpkpfguLAN7yKBF3DZWkW
y3FJpVIIoidGilLEFFmWgqlIKXe/KZWDcR/qoJNz9+PevlCob0hBKUCShVlhwbA6J/cLoQODCqtR
tVltVdRFdaBmBzFiZoVoqVU3Xjwmt2DFVnW1SMS0Slnck1rICDaqslZ1fqxOS5Wf+6Zt/lLxVJ43
wEqNXJkp1kwFU1NutbBcTuj0+3rAtitLS6ltCa5L1VWr0qq+6dkCoOFyLA5br7pWXa3KNohwFWEV
ax02ZLdUQbj5FDF3vqkHlcGu40awtkYJVzLe88haTDezgb5JhC9yT9dwmTMmLnMNdS8s7MR2lQco
tcDQ63V4BqvqxfBMVoyQGBwW1SK7L3j9kIcJF3x74C2LdFQ4Hn40/Rd9lHURpmxebfhjFtsUvxrY
bYTV245lquFK5OkNx0hfm5JvX9sG31Ii90oeqBmiFRj5IytyG8OhXasH2OqpydDYMMTIjDRKr1M8
eitWQ8XFtC4OrRTXja6tC9gu6rg5X1nNlRZd00lqPTMnf0twWYUmAAhGXJaOes666Rq7GzRhMUHC
KG+Y2aYi15Qvfi9uL2J74eL2mq49Fd4XtxSipVXX0NXlIPZ7sEKnPWL3UOmigjm7AN6WdSVuZfax
+ct8yWxMD/1dn7eQ86L7Lh2E/PQJU9r4g41Wo1p6QvVgNh4DPhSa6TTvKbZaZRdxLFYvTitXfSLh
zGyGtXR95Qkia0P9XGGiCuVg1BueQokuULqkayPwW/mYMNagDGt9EDLj4wHeRFYNIy2uSn/fdnnj
dkLqXMhCjCJKU4OdFfty7GJwJZcYXM0cBgU8YWBZwY8k9HbLLSAieRIyeLt0Fd3IU42i4j6pyBMK
Wx6fMhaXoJQCueqaYgIwUb2M9Ym2GAMmw6QleakxNN/m4jhbs8FClEitM9uKOIUiirGPfcPF+UZj
gUwsigl+OYdl1AWMYL6wjkrGk9SyIuua00txYhYKOcydialohCnfABdsM1MXr0QRo6G0Z1vnK8mV
55sixVAOrB3G1uxhML8qrjEovsiz+6lcVsZNVL+BTCTEbv9goAPzsH0eVlnET0llivpm8XM2Nayj
ZCVgEJCuJP1OYlQjPFPelwQv/84ZLHVAeQlK+zOYlPmSMyl6yOLZmi0tnHtlGsgLjIJaaTdXyo0C
un2zwBuLiEfaWIqr9psDtEFsr+NWxR9Gpq85Q3vUmYtSuMo4ruYaIn4SS3xGIA7BlMpLNBZDA2kU
NpmTPcuwmIk9C7BHcX0LsPH/21ANXLFhrNw23gJO0vq7OnoR4NgNI7lzJWRB7DKeDZ+msfeBb3e3
1hynl7g53r37Qod0927HGoemcWyIpIwznewJ+walJM82tTe9WaVNnI/9bV7USOg38kgg4arTOjZG
1ZlfcyBBoKtazWzfbtIbDGYHQ7XN0BJTA2v7of9RnGlcNMIafhzCA/wjmkqbCxtoLkRztNv4n5tQ
u5ur89Waa8zsoH9Tn26BNVPt1uYiNhehuUBsL7Ry0DxBqwKNAVTvqZVTAafeXBWr0+LRNdlc00yW
tqFQTAJVMWyJnk3tnDrwClXyqhi/GNhKmwptXDTUiElImmuxuRaao1JPLZy2FdokojVmVsB/nCCq
0XZABZuGhsWja7O59qEmZc7KR1c7ZmWLZRmKeKpEhZM44sFId6dBczhK5liC4p0hJfumVUNDtaiW
ODhlTJLx24tjXyUsoZCQlD3/PqMVxDWLL4Pq4F5kKP7tLkk8QVol123KhhbBmMQHcFqR92FDRNK0
09e3/ad74dsNQx+RX0UsrsgIX2Xr1BCYKdBQf0Nd/UCcst9SpUgkvQLkGdJ2E7iLq9aBHqlrcIEP
8hIlFGhnQjPgtwIUePt1QUAtaQuca58Yt9Y1SydU4rqFMzLraObsDPRMRAUrGl21oqIzgXUD5k7t
Es02REFLrl4z1KrMat0qhNVKRVTEg2hBkagamSIDyfqItu7CBspwmEhVlSswIhUGUbmqOp3VxLS5
bJfdytvv2eZyJaMo/SDcsj56h158MO/oRE9jtcnRRLf52op0Ruz7cu/z2ioLMv5Goo6VX0N87MlJ
A0ZDMjIyNtwQF692mUAxYGDY0QiO4sQ0os6thMloEvId44cYvr8G0QxQvh+JUGzKwHvgQVjxgNhV
qa5W/plhnLrDFczFs6XEI0Myspqnv4U55/JVNDSn+kVXVvX3cK5i68qKmTUp0rPyUnjwnokKvdAp
BodaQcyPoLVOsHg0Pj06FhHQCmBMIAqyMI1F2VgyZqy8u1Dw2SwAL9llinHrzixwmOW9V/nVYawN
Uibq8swJznKZlsXK3kT8Wdda5AwldNjLRi6zr/dV4RS3qmueLkXGAk0kWxQTbLaq0mfNq6WYkynL
yECzmJb0mM7lJpANF6rk16q40mYs3sO9TPtm96BXr8gdyJR/2Eg7tmZZvfyMJolarvi1ozOVrx6Y
KWTGRMtcn1FIjG1jrJsGJTEWT+LxzCXAimuBD2znPt4nqaBhoTwPahrhTEiZhMX0x3FC2oloEXBb
G48YVvONCW0qnuyAwZq65zV+yo0cbaUDz1IsQ6syVMrTz5qd4OUUiYAZqPW9YsZ/VCCUWCqkO0MC
TbS429986ssdEN0pmEDwuUTkdkkz1PjQrj0FG2JsClJvy906SdXT0agO6VujhKkgBB0o3dwSHxYV
TzERP7m2mMQ8aqTNpS1FBS31vLpOyfyWkphR82x8kzm9o/FNyvyEsWYD63UCgYTFDw81VkHrfxP3
9OM3dkCJjTA4HKea5pPTqSWhkBYTOaIkdhwXlGzWYDZOZ1NV041x45vwBONpK4aVETk1lH90xtuw
E2M/Gr7HpY8DsQAyNy8jAD5nuFuX++A4OED0rAkGgA4+Vo+LCp2pdVVMAp2KIu3t27fBYYEbu7hz
9YQcMjckKfVC6mvUhIB5yNNkUD5Oj/CDaWEtac9Xr+fOBQzHR/e7JATjIxOqQN5iTw9ifO8hs4CJ
xSM5Q0g+N0vuT5P7R4fwkCI8GIxUq9cn/UOrRFN431dZkCHBvBQEwgn1aY07kIiBqgl5EP83vdXq
a6ZiB688FUfxmlIlbIj3uF01oRJUchmpsHQLJ3PFey8+4KrGD4TULCPqgjg2SZ1TIirkh8YzSNBA
1cRHrImXV3y5KxwhlWU43asm+oE6dUC3ethSp7k4y6mtRuJRFk84uxNNll/bMkJxcTc4wpbER8jY
NZJBPPxVDdUIxYkv9VbFxdwW1zIf2+L4pk7MniR+ANEFaFACIhh1IGEYoUQuSKSCPDJOI+S8I3FN
y/jFfd6UcAE2Ldo2h4BIBzQonvJI1PRVtsp4h0g09ZUVcVVXNTojEhWc6nkokQ/ibBc3N1X7SJTz
kDAMV8RqwMoSoRFKhIQEJXBwGm7SlAgNgpQtNGS1+JXhGIgEqGrIRwhs4KJIlIF41FmQSxE1BQIs
rWEa/CuUD7Ki/NqWMA2xQwgWiZefUw40GkQCAWQdxfPPdRSLhIRprKyJG1/iTCTGoWoCWiT4gzaU
QKphTmhQQCXhE7SwBAIWicCQdZRIlhUxgMiUVyRogEDjgMUyssofXCgEK3BROBqJZwhkjmurEibB
gTQlxIKLIuEGMmrpZE3CHggffuU4orYsGRclIppqtMSKRFYIHq5JKATb5/TkUeIuiIJRJAgqoRcc
sASXLMtObAgM2xIdI2ElhC7/ksmLsUiCUGRDcx+FGhohU5bgDbEnCSoRIKskDqHEoMj6y/4TgxDh
HLVkhwkYZOjsWHa17JkVoR/8KnSBJioalog2YrmSAA4Zu1iipEHBIsKGuBOxrYh4EnHfRsS+UOiA
hLBI4BVqoEHZXBJJI3uBk4+agquC7FJakFHwSdZWRihxLUKLhP4JRWgw/MPZCPaFZvr0MiLcqFMa
xdMEBEhd6UhCwCKzBrKXBEuE1Mk2DXRKq2ZUsslkxwgGkAwD6LJ2Qg41Aikyq6jwFmIcOdom5El2
X6NhabiAQ6PWhDw1LQESoiREQxdCqVDTUlF+FXjInhN6pPZAJVRrygrQoBBZoW0S2CNRURycoIXQ
SaXzsvuCNUPgZEfK/pKdpngWCM8QwtV0qN+IDFYKQyBNVGKmvEXIzMqaYVahCeqyZKzdkr26aviD
0iwJaRLckD23umZ3ozAA4WBCdZqh2R2B0AchF7q1hNgoDWkarFc8lnEJf5CoNCFPykxaBh9J4JSZ
CL6TC6BB5RRty56UE4Vmk+leWlk1XE1IiuwqpUcyHd2wK7q7AUNhf2uR2UHC5JR9C34JRWs0DeuM
1Ky7YgiO0GaN91OCIA0KYRHEcCxeybKwycjxEWEhLcNrDKNtOk6n5LUtMJR9uWYZlSLLqtmrKlG0
WkasEE4hVEeInlDWlM+SCHHzL1s2KVRUGXlk2bdILCrKNAyJFwKn+17GIVMUItcUYahl2aRSCSGH
yl5bhpcJWVZmRRqirE0ojMBfxIPWstIawjA0jFD4j3CiUAdimZBQOZV5mo7Dr64Y5qhhoWsNpYGc
8ppKHYboCSUXSitzXA0NiRRSaoz3bUNjRQoTX4FwJ7JTSgYtw++UbDaFgIaGRIqsp1KfMEep3DQ8
1oS2KgVua+icOzihVhKqAalEbg4y87gjRXtVbxKxya0Yz0Rz3hshyx+pB0KY7KqGLjQb9eArE/mB
jt0Bju+mRidSBUcGgktjjmhpQagD/GxQcOC7MwkQrNM9rPjqDhU9NUfzNFNw8bvw7v/z3/wuCqEY
X/wuutv9HWgUjk9Z+4yb2b43XfVXvV55KwEMkRN6ZCMJ8sumEYKu+7jBOMfXYUNrtOxGElqhxEhC
QyVYVDBLNpfgq2ARDBzaQlNbEKYtYqUKyJaWK99pLBtBQZm2SAsrjsqKbOEabEuDwm2UngRtQwO0
/aajffojNHRaRF7Z7srrZf8Jk7KTXdaWdZXblq8opbWipJG6Qqs1yCiXLUBlKwv11XlFDa95hb6w
BqHcQjuFWam8JZPReVgh24i5TcNxPVosH9J3to9V7UPE/rVlw8QUQmRTSrtaqwaysrlVlk1XU4Tj
1ZZVGdqrVl+SnWo6ihQxQtWrHHMIrWQbalDrmqFzRjsIDcVW7UM6jyw0FIsEEMJQhYiEHi5GkXSp
FEGopZBpUVp0fGuWDgjnFslPhZCWlUmUfTuaKyBuWiXLiJMrhoYrQ7adt9KtEwmNFegKcWw6ghY0
LN0VaiHye5SqkA6RhGuJTqKiemj10tAKGsp4tLc1bxjLZjc17B5qWc6oo2pZmcV4VCNHf0OrJwob
1Rj4VTtcVYXbBuLKXQTvhU0HkWVhsitWPISLDMIJFxLhuml4olF9VRRoO6VoxQ5I0DaynevJgChl
vitWnhcMC5363nDoKDulYZfWqJ7edm4aFJVqa5GRhYTkCUuNHGVQ1tW0sq5Is7puMlWZjCJwZBbe
YLaVt9RYIAKWQE0QWBVnS8R0odgeGW/j8nJJj61kvJ1pDJ6x3a/evTDnZgwzkDOlFyyhFvtkziwP
kxj4yGzfOWBojBbrajljkz9JjnwH0QbdQ2IQo+lW7LAooa4h592lf5BlqrjRqMaL4GC1p322OuBf
lWqUcxihhXnPkE5EQgvJ2hqfJtkIk5gZgmKX12iUenyX5OhZkUPYMT2PxxeFXBUxx/1un1ZKXOmE
WTKaKDUGylmfZLYfX0zAr0czB7yjSaqSQSHbaFymZ+zzlQKJp800TOApjG1DCuhGJlrqaCLBS/Mj
fp1v7226iHNd3Zvr6iYDxIVOHCQHdTTRmEFvXW1TbnF5/vRTFVOO4ysMjL5NdR5zrf13X6rtp9UU
6fKDTFF5Ik4WngpXHN/YKCnul1w0OmF5/dYwrr5MS4Kv2YbUH1Lk3bOn6r8cvcNxzpG0JBImq3SC
O0mpmjZemQul3EeqrATJ4Ojhwqzsl7kV28gUvleIYHlcTaFlja+X4gfqIQxsxjOf2lhyPDicqTwq
986XTeeBtwkssvmDUJIhbRdh2MD6cU48dLLtFJRf1HRmn5h3DX23ZFJ/zLX2cGMeQJktYYIEfzR1
0Oia5xoQ+r6QKvEUh9K53jg+RKIy3hvo4lokAZxHwrRB5z/JL0XqSrGgMnWhWXBeLimCtsMQ1nEx
vXSOSDRNZ5u1Ob1esKJv35pjGION/KebEMBqLUxTsrDLP4hJK42qz9LFsv94jxUq9Aa225k4/2wd
NJeLq18w3gX0udpIB1nUsqZtWQQDr7KPuF7SFOcGee21/vbta1f8rRt3QTaNT5PFfV8JbNf8xoZ3
miTfxsagFmZgW3BOQQOP8jUfzMFSeLjUD9KoHetLNnTIpCaiAmxiZa8HLCq/vs0WHGExM8vyKvxK
w89v04OmWcJ8J6BzmzFmx+QQyzoI9egdWNnx6eid9fmZbEaJbNBR1q8pMUPWUSmCDgLpjWhTlYhT
cSl655HrmhPMGgFY9r1WTOu5Ojyqpz2YY3haOa1EHzBPsNNDfDiIh33jIR7D648MI+aIRjb0A7IV
0kxpVslDl8PRi4NTM4m4WcVAkQps7qyzKaKywGw8wyoXxZYYiU9KV23AivE1a3umiVyuBNeCsZAc
D9LAGATVMCPVyEXbO/DrUWqepeZZ42UTVnoZ5P9dUnvQYihF2b11Ke9y/9IikOeXFxcJWIZa0Wq+
r0s5RmpGRFMWVZrWlSNCKSpsq1eMiEV4IOWqEaEMD6i0rhwR9UsahFeuHBFKsbXmou6i6geosdQo
1xYXCaRMk6O+YkRiEoImh2M2C0eE7qCCUZG8ojsWia4adIur1r5+1WhzoDaKlq4aESxi0HRxHugK
GOE7O7ys6qMskJ2DhVFTzhmFXhldaDuiSM6RV8UCvrZ4RC0gSbNKPXt1MQBYBDtk8aAJo5aM+go8
4ohoiIG56qpVY3drVSrLV60aVpXGGoFRywNZ2gpgtCZ41Lys6mZoVENdaG9EYlKBhSuMrl414NFq
Cm7YTdh4eOkPGs17RaDVh7kiQTqEtEx7bkQwnNKsHbYXj6gJtF2tNpfT7mA8guUiO6Lmsj2Ipo8r
3Hp4zMBoWRAn8soodhbjUdW8AL7QcOXD+wNetDxwZ4nBB3rTUjwy8wd5aji0kiIeHrkySp7ciFrc
/Vg1OBSuwiMMAfQBuxuA1MmhQpsQ9wfN3R+Z3viII+tN6c1BOguj1QUwEkfEWpTOTex3a83s7G6y
alh+AkXASJCtVIGiHhhXCCPBfjdqB7IMjLgnGitX0qNVbwi6ag7RvSJumUxvbRmRm1eYp0etInrU
JGZjkBxo23TmobqPR61qy3bXxmO72sp0F2Yxuz2P2TRhZlatXbRqbUmOUSUyu+mL9W41AwB/CGZE
y9VW5C8s3sFBSS4iM1vBI2DU9uY1N6KVRSOiSRFUUktxRLRjrq353aEu7IYtu0kAWRi0W8se2gLI
1+41YjbbMOuBoRD1zGpk+Fpb8ahlpk+HhTC6tLuGNwSz+wGyFX8jhZm9xgHO7bUoi9lY0gLM5gC4
qaOGh0fc1lFma69l6VFrnh6xeX/3hzcY0VrRiASzifvNdEfS0B5qNY9muyHIOacPcCq02rkRue1u
9tqqDLDpzSvD18LlIr7WvNGqsRilEdMdEQBEvuV3F+Ywu12A2e0szSYuFNNsvg2XfRiRHPhIQgBk
hzDH+/Ortjy/apTlU1R2VJQ9tbM0W3h4aFpa4YgAyjDKjSi7uealkZUMjLgieRg1hdPa7b5IPmpl
ENmsWpsEI8pRSLe55IzcB7gcW5ntGGZH1CpYteXc7m8V7f5lgmRFF6ntVo3UcdUf0XKGHsmI8vQo
vB5GjdyqRUWrtspVAzgay+ke8Ridx7R8GDXnYZRbtSiaH1EU3YBCEt29zW54P/eDoRIOJzMUsjVP
IaPVazG72czBqLUIRinaGBi1iXrN7Oyu4yIiHjSrWk0CHFKQ+bzfgxEnMY9HzRweKdDm8KiZGVFU
NKJWZtWa4QJO642IZeZHtJIRPuzud0O0MAqzMFopGFGYgVFzpQBGazkYLReNqJ2TjxRGeflI8MjD
7EbB7s/S7KiAZkc53s8y85g9J7E1CyW2KIPZ0do8ZreiLBcJbzCiIjwKVzIj8onoraBYFBEkyg2H
RXwkKmJquSVrtq8fziKRNkMPq4pT+a2/liWPa9ejdWv5Rku2fJMRFcCo1bpWpG3n2WxYQIzCKM/U
VoqYGot5aM0dkkfr5tq1TC1PsFvhIqbmjyhsFbLZ5cyImgVstrWcHVFjfkRBbkTLrUV4dAOCnWUh
YQELaa1dO6KodQM8Clq5EYWrRSMKm5kRNaOCEa1eu2qtHIzYzNyIosaNRJFWI7NqQrDzq9a8lvGH
jdyqrRSt2lpmAHavUaJc89vKiiLkRnOYnWNqRZidH1EWs018455JN66xFDZdXMNmcnFpWnH2TpKK
m0NFPEY2sznNxU2xpWfLOoGXV4224pFJCmCPmTIVYJ9H07rwEE+Np8T3o1QzLUSZHCHwO6yYHAMz
k22kbw31egywr4c+G5J+wP9/o+j/zaL/t4r+X1gy36AFaXpsiq58hCOoJ0Q8PaHLHQQHT0dcI35w
iT3euu+mU3awkAT0mZRJ9guO1tODteIVkCAfcfH/LvJe285wtJSnKEfMQHM6lCOYiG9CIxEaY+M1
bCoeDnhlk9Vvig+b540DUxelcYkE18688PrRI6xdnBobsYrtjjEJcy/dUV6p787Xzld2R21Zzh4/
jdqpR8tVyYzo1hWTXvjpHhu+G5QXDeZ3EUFk1oRjYcomxDbNmEBGHVcZ2CA5TO904ue1zo/V5pqa
4TYTutwZOfHDx19bPHR8ixh2hdQcbN7cIXHLYIz8qi1s2K5Rmtxr2VuTbBvLipDiAC743Awz/dt4
L3cBkFx+cB8hYfoKA5A3TClAr6X1xzrKY6Knsydb3ZFceZqLJVLnnh8qrfETvCNPj2B+c5Xr5BvF
PXE2vm6/fd16a7OHxF04QF3uaneYVs9E+qdo07TY+UKRf6S0qESzySADZunwz85KuMZIUp9rktZ8
LSYQD6NsLTnyKtmIgkfifeX9DmEQPInwXzNgbDiew3ypiKUi/NfEfy0tFUX5Ujgi/SRCiaiF/9pa
CmN/0mzlS7ZQstnGf8v4b0VLImvIk9ZymlodQJVkpql3fThI84N7d21wbFWOr8ruq2yZf/EVnyjW
sCPTCR/4BjcAB3phGa8kPBqbk7gCugWndx0n1TwU6mTujoTX+TkRPzVJET8NytLcbfMNmI0YSBxL
b2iK8M2h3JzEq41MTqxsk+Y2n8O8J7vASS6ZdcnV5Y6Fwszi5oDBfG4GDWJIozBwDre/7wXY9RZm
bLg6/M1kQjyZ+PcGMYRLY0c1zGR2MsnkFOEnvJB8IiaAREpv2PP5qFBJExOYHIFCacw8NRDDz3/h
stPZKcrJbTIVu1TcO/Z4nGYX0JwGuHFkkBzzIlObWMIGCdh4gYL8FEsea5aMF1JSgwer+tbU1ncu
96MtmmTy/mAMCC3z4xPcJ5wG0Qg3B1ktdN/kASoaAUGtI4/uDt4iK6QtlxkTdmq2HMJmaoUzMuu6
j97T8hoPqiucTuv1bW+KJhLHhQnLZGyMcFme7hV2WLmrOVsdeu1rss1rQkLnh/C2Oj/vXMtySY4i
r8zygjC2Xer0bplyr2/bCmZmNt2VlsbVO9VVP4Vsdllf384ts2kkRfp9TRNz65Yu+mL4+BmPzAVz
9oJFvV/CsMKvTby0SSPoUlN655tsooiRwU4Subh7Ije0JUKOO9LDQYh9FFKn4D19SP2UeSwfNDPP
IMSVtFrEjBFptfRRq6XP2WrNqffe7gdDyjTPTGanIKWtcJ5nIk83spmOPKzsj3NF8VT23mRKg05V
AhecOtHWMoVX0xzUhZ3JNXH+oF/fzs4ht0tcv9gu+D8+r1Tm1nuXDI1dbj22qT1uXTn/HOrdAAY5
5P0hcJjr9PvAYq7/BfDI5XbJtDef4gVSyU90u+fGT/YvvSEcEXeyT0XmKbilyKWLSZNvino65vWS
UhVyxX58ggQ8+/aWMrkkzd4yRSmck1Mhw5SggK0xj4e4+xwt4b4zJJvpk2Z0c+YEvStNjkji6jJJ
EOIlIzUNCjS75LjSah/XE47IQIXTIfbQ3ICWxvPxEi97ARmCtiHdTAYXyP2KuekVaegQvL6+lIGB
d/u3psuRfL6cL/UDIzimYmkDiCVxgSO5xwt5tqruYy0SXmjuezvByjMa+r3V59KCgSnYu65gLfRb
FPaXNhL6jdiIU3vfvF1KgsespRNm7AVwvOOJaufoSNROkW98HVUFWc0Q8yqtY4eZ8ENhAi9Tdp/r
kVEakzJI0/5FZSlrlLgtbzWB1JBfsFNwoyh+/p5BrRkhXvApFWQ8gvFt+nhLGsR218sma1H6zuia
FB+KPuOdVyL9nFIK4uK0q9l03ASdzl7GtXPMCuUGuKIjot4FPV50eNuX5OXeiNzzSu5ZpKns8wqf
0+b0Snd/arkmrOJd/FrPT2Q7yX7y+jsYz2bjk7kZZMpnJ7PoUwrj5YLX8uomkB4w8aEH6WYWFcxj
DvKmr+jetwDJvUj7z4MzC4pvRUjNls4CwzYqGJNOu2an7ZDHjxkP9jL2IN1NhirNcp/KoIIVF1zd
71LVkFxe6Z1s1ExwrAR68Gjm7/C0EcAO96kiw9Lw9GQUrBTm3tOO7XbN7VZ2iKx1w42V6poFOx6r
un1rZu+5xWRxSbJ2J+K5AJKXmtwemS65FFG1rqjUHMg28zYyCzUFW3f+s7tuRmzM2as3PbtyArtV
qPzM3C/HgVgw2ushczeYGdPKVNO3KXM0xjy9ZfFRfI6vHeX6mRGRhRwYu4XlZOdxesN50QLqTZIz
eyujRepqirqakTtFzbqk+NJUb94xgKrpMMEFzuSjvv1kHoSfebdIbtVD/x5Jl3xr3qrL2Pj/t70r
3W3kOML5Kz3FZA1ZQ2sozZASRQnLNWwnDgI4jmEYyQaGI3BFbUyvJCqUuCQd5DnyHH4F58VSXx19
zCXK0Q//4CxWnOmz+qrqrqquIucFJFwY8g+7JaKfAf/0c/mBOAM+zrt0+YUTZX1NTiIhy5EdSyaS
555oPtLJPJa3XnYy1LKyQU+KI89nfSkPebPBwBU0zE5z+yA9idNjX1x2OnQfg2zYcx/kk2Hga8jO
coX5uNvLpZYhl0VRx1HZ2dkwKp4UTHquIeTSCIrnA9+KbAjdpjyqFyohUd0QFUn9vaLbO7VWWn1J
VvR6lUop0HUBSeQ4EMpeedRgVTz39eUCABSphhWoskLHJ4SMAgcK3bBLzLydGkBI2oQelDEG3AON
gQjsuNI/Gavq2BgH/ZSxMtrATRLk6GkEFTUY1IJMomVS9yUAialIznlyc4hViz14T8vY/GR1Iix4
d55l9qJ4asTzGo//wv/g63XSGMf5ahBxZU2VcLH3DpMK+gW1OYWNzGN3yMUBq0W44nlDFyvmqlys
dz3zgnI7croOA0D+llcejcFJLh0Y6sUXhJkUX9RgNL09hkLSlbfCuZZXAII3VFwTHKRFisDjujSI
2zMa3xE/5aDI6HdNvxzPN2fXoy6ZpDbWjISt4rAdvqY0vwnRt5xK2LmF2PC+erMmYvweppYf2Fk6
GY58oAt1aDYZ+J6IzV0tUIgew3cwIRfLDOPBZP3dCCfn8Ru6MrzqZPy77nQ8QTSfyzuhlx/9Lfn4
iXcYuCgcuKx2xPKLK9ysRsdTHIkZRc5UTq2kBvtv3TSckeh15S588lXe2q3GWGglXMGfEZ2jE5bz
w4kpUZfHrr+VgVAG7Vs6yhE7lm6bljyx4CDqrKtXbE86TrycdSFAXbGd4sg/XUYuOTuRaVIV13Lh
ad497Sh43gK1t6dQnOjxWb3IoEpCHJVjXWyZ9TD5EwqnE95ULsbB7vU/WPJ9t5jDfI8YGhp7aPZv
Z7O7fQbKNm/mtNwce37bpS0n27ENnxdZIveZ1cAt/rJtW4rgoFxCc/ZXr9lhCFf+WZDkKcRzffJC
0ueW2YJy/0eDLCfb0tUgzYW4F4m4pXwUdgYmVyik8NyA4vI0SFvCPxaU+0olyMDmtBakgCNQgyxF
XriM1i14NoXdd6ZFvJBuyRWwXIMMeOsr6SQHmgRZewsbQ0nhCtQgG0QbQ18/h20Mu6sqt77yE6Gw
vpJv98eCct8ACbJ8uY2hH9HCxtD3Sm5j6GcQ5ybYA4UVtwrgUpmMUq8eYLZ89tYjB7feQ9QiS2tX
9AZwOlhOL83TjEnB5Frt97P59EeYBb6Wb1h8IEd+1/VnKIUGhiDkpJHKjxeLAS5vXv/yAt+cD4ZR
NLuXE32L6O9C55F8NjYg5I6wbvsB/eyuwn6AMzbhiIa1wdsD2KBQ5FFQHfPGYKac5JjsAz0y6Wm+
E9laGGZnz1NLcdqdxkVjO3fyTIUPAH0gEgwHlUkZ9Z1yAKz3Bs9R9TQ7s1obCjrNwI1+rJwhl2Nd
/jzd4se1gC8OD6oZYfkUylWhAla4gE7J17WtQb1oP1H59r3MSjPrvFwuD8n9++27NRt1/ue8i8XV
fVgQgSRZ6pGU2dVKumoXOtrqXoQ1M7kTzGS4yFEc+fIYJPe4XLFMERC/3AcoOkXBhSMORQnLapDH
TIUnb2Y93mhOSE88FosgluoqIDtKpmjXo8vCJyo8IcwrzXMkJmoeV2eQlSh8nocEPfdoPe4Kh/+j
rnAUNNwouOoCwuOpWLnfHNWq0uGALBYBdTaQFETXmaVOdomVOvmdSF7p+ZB0+p73myKXnEOtdY5g
FRWybcMUkM1gmPzGIwTQbzT8foqrE5L3F2M/nQoDihWURCdyydqVYptBzip16zZihrH/gRoyVrPs
DHNoVKfkflLcSSbOhcmkzOZXkVTgBNnc6dVUZgdVZhNbnlW2zoQAasmwK4/jq7ysGbGrwwLP0NVU
XtMMTqg0B6SMoV6EA6qEXV2EoVYuTgs+SMx42R4cgu6sXdya4kR5zVIcJf1NMDO1tBPIasnwU8x0
9m0qwrYEDfy/21QLd9y0uNmbt8kdU2EgZcpmvqY3vPdaqN/AmyuiF/AEwbMb7hTEpNQYoi1URDM4
4OMGXn+IBpbns0rDDDYsDKaVVYWlaGem87aiVet9t/IAsK0Z623OEzHCR06n6YcoviSkymNXvRvK
0VqY9k2LmOP9GhZVCZYjirxUFR7ZJ3h0xK8KYXa1DWdO6sH2SHtSeTMPq2GbLJC5sUh0MLynKBIS
upnzOUT7dEBesv6527cLK9tx1E1VHFyq0P8GhbKuQEp61VesJcdy8P7HHbHNEynCdc1VlygVOvVi
EYJ/+s1fwQ0fv1O2AEIz5yxjCSbKkpVjJmVVbxXkMiPgK2USfH3F6gPUhiT5jFgRU3PBofLnPE9q
nxTLcdVh3cEeT6cgT1GfZ12bumioYcWp++XUxePwlPIUjW1I4czwPbSRD8ASxHu/U9umIm+u1/XC
QfBVhqFogaG+gHo4GtsfVo1yDqzUsByQcx5+Q1WkSjVNPiSZI4R9efcN+ZiZsCfF6S2msIpsiNOU
rsjH5LpbsO7zw3xxpSrG++yf+0HmHyHd/V1TbLp/9zlVMoK5f5z4rcb0IrvoGNFmg4Mg3czFf4Bd
uJAbxdc35FBN7llJeZ1dB/iigOCtKG6x8DBR3u5OUKFPta5NsQpAWu31a1OUa3o81d5xtzg86XyU
rvYG3R69vcpdU2d3wKI/quoHOI4L9p3ltc9J9EYu0u8JL3bAjj06ojxQAQI6TG9J5+WLxZg7qdMI
wEfokAP5fRRcTXYguTZOHXe6+Ry9vCLaSMorKSuTcAMK/rikDz6pmXKJ2VTtFvWJhf3KqE6FofAS
kSnWC6WmrLr8FTnQvYFajkybKXxlniYplY5+3tfptE/81ZUy9DHxC5n4hH5JCZfwPBRiURqp3NOy
YUebIuCU2oN7SoC11jE207aA8jO82E6i4XTK9S7fZf2M3IoR9otfb0aPUs1JnU06zZqN9bmZXV8w
YZUHvOO/Q1Rh+kXEHyZPTWR57zZ5/eWfvxbtSKFI9HxOOZKXXQXlYy0o5xjqucSKBur5Bj9UmR3Y
P5lMvAqnbvtSr2l+36kRgsebp1qmFoqrMrR40tRtmdxWnwn19XVg9S4+BNw9zEcxBoXWBxLfzSg5
/Lq5nf+Ib3twDZpwOZ+y4y2bcnoOuI9YYnoI0GIuJtN5tsbfEQ0o9SYcnjxgZwnSTTsfbFiA5x6Y
GQjq/TfZG8xAlJnu45j1mgPvzT4oY2DT9MkVF4/fj6fXLDgXff2ra/aNCKjNIiGbT+QeIUEVyahC
C4phuFoTbZzF7GKTh4N6tNM9HnbQsP18nzLCkPR+wW9nrBjMysp3ooGsQjh8vVJjzSxie6l3qxJ/
DQfTBVoQoqYlbUJbHqC5KRrw3owjCJvu3FlmxI1Pl+yzQDqAZ8Pi1ncSJwGpw3kAyoPshhKFFDIC
0vl0UFCXw/fUERQCTHBkujvYkOPwwgOtJkrfiss4lHFHi4+TsixJhkmdnhNJ5quES2wdTaFfRogL
i3yDcvXssJwhW9wdTWCal4kHmitlISEOTNgL8ZzbNQGqXlxZsqHWxcP9NFJ+zKTZPe6Se9mFs4wL
I/GG8HAgOtVZQlOEhwtwkRPO+RXvGnzkEquQUOQt3VagnGwLkSpmE43QdVXSjk1oolOO2kI/9MHy
RunYbiJiSHQKOkTP/Igc2OT4YUFXOQj+efk64I51h3Vnt/AIE+taUkhs0l3rEEb2VuEET3UbuaPj
wbesOvrRUfMbZzxSNXBNNK1T2zzbLW4QwdfDeIkflhRFOVCUsdhEp9hSv+TLdedOB5O0iT4xdSy7
gzeNNLDoi68U0edsbnnk2hOjIpenmqo4L8779L9IeAMCUjR/d84u+c5Lr51Q/Ohrt5K+ms9g4FLN
niNDWDMc7EJRaH3zZnYd6M1CznLNmrWTmSzT8fvZlPalJPh2QmA97KheL+HRO/CIb+UcZn6Lgai5
0LlaobUsh8FeJNCartArJiaNRr81l9IrR6U0mNTL9a3n3vicQBZh8xaKZmc71mJXuJzahSgjX8ze
XqA3L2QFiylpdPn506bFTkV9u/3hDF+SKdVgCpGOyMnBtEMU8xWfRaZOoW98z4bLL0TFmHIS1j9P
ROM4w/Xac+EMuL3RvSSttpWk5iQ6X+CK2oVgPmPEnTtBldcu8UyQ5hKUJVKCcQQEZmopfEMgYKiU
aGnoilcQNgzu2lafd+7nTWO5E4IWDWRtsBLSHesg3MQdq51jZ+84iMR2IbjjQ4CX2zlyne2b0NpZ
LZEKnQfkbVtqsmx+4uvcsbWCLYO9HrTlNxJhiiqtUBdBL1SG2k83TfIEwH8h2JGeN5iuXkq463Sh
nmf6rirT18+PaBq/5JK2k+RXOEmqCK06RzCT6F70I5Rd0m2E4TklF6e06Sb573+SW8Xv9Jre0DmV
X275wMp9Qvyol048IEb801U1iEcjLc8/jrPAg6I2mAIppj61RoCXUFPBq/oKXtVX8KqpAorgxoou
oCPtfnDB0OsnekBBJ9JF9GfYSm08dJuN7B9otrFldz4Bi+9ridIEfxQ9cdqv06mBjmDfrz2nG0pw
K7I5AUZxDhYNnx1oToqCOM4Zsp9lP9nOhTo2ehAS0m0mqYPNBdAJYjG/vJKbfi7JobNoQm5Z3k+J
BU86j3e0T2RTFj+uaBd36OfcAZ0LdJKNda3XjX05gvIlfjLVxfZa8/ZbY49bY09a6x3EeVNuI3GT
S40sZzuNCy1HD9ujz1qj4VEvXF3od9JuBq4r6vN0K71bju61R/fbo48FoE68FPt+KWIfys4LbP+T
rmSqjJ44V2SiBPioEttrzdtvjT1ujT1prXdQyZtyIzFXRg2TRWZKudQoetgefdYaTTNFo4PJsmqZ
LDJTmovsWv82Rvfbo48dQBtOlmiHRjdxn3KCfTqe5iwnefLzT3SIAkl919nDeTcMSt+xThxFEAGm
0UUqb6uBzghCWRqODkcJW7Eh6TJ+ykfUY5wkWA7PauG+tI9YjAbYOrDd03Ns6WAjE5C9oCetZMcy
/swk67Us4Tvj4LfcZabj/GweHdmJ9/p9ktqVTUgFJGWnjjevYnmYE7EDe60lkZjVLNYcnizar+Fm
U0k15VvbRjX8BMoRCaYd+6Dsmq58oZl5H+z3BaI1yXOIC7sPIlzeldsV7PxERdbhFWw6vg6Di+X+
wrO6VTGYUx6QDu8dDlu6nLsLon7aVLd2fdjrvrGBIgRBYSUQ99J/CNsD7RGwSfwjWgNNGZTTvfGc
yKuXbUMYn1oc68GAIa7ZX0aw2cGh1ACc6MdvmGcfBbp+qloaKJUQsylh6s2NF9+Pp5PILeleJNCy
XNNEAadsRg2jXdohzTXVYWCxB+tvRIzI37lp4m4AOoVo3kmDRZeO+A4+ldzhuWY2cKyQ38sNfefa
CAxOdWvkbGp55FBrGcnyPZPxhOLQVplcqZAySKjml1awFHdVGkew3C8uqUrcoZxDdKlmknSdpXzt
Ale/fv6p+PDnn3qHKl56byJ2ZollFN3TAHfVI+O7MiS6ZBb7bEENmmB/DeYmtFSwiVaVpk4Az1uS
gFxNzoVllGnfOd95LMPbFRtGNlexo79RgwWMpjOnOMVOoDGA6o/NmKp27STlfGCC+ds1UxhMA3C0
h4dJAzZeR/IRExo4PEOSS1LZhSLRJZRvKthcKkkJ5gDvUsgFza1OrfWVzM9Jxsp04TvjpmXsrs+p
qO3uBHPXFIRac+jKNxWoq0vOdMHgvJlKGrnC0wivla/uGfmVrIOVAGtIJSYtuJFcAcqNy2Qlr7H0
Qz06QkLQrJK9ml9qikuLo8lZMpmyR0uR3OU5dmmoDpIl5oBS17uqTu0h029HYBKL1TW5DjVK9iaZ
mTCj9xfZB6UBr9Zt+vEN7dRv6lMi9ukLUuh11jDddcbStuCpNK5k8cVhaUYQwO2Mn2HHjIrRJXXr
kv2LMTwPtzoBJZxyRYgNBsDqwrNKhvH95XRaSc6h1cTq2recWoKD5NqNwRciH9EttInZnMIKiRUP
NV8caEnr7ojXhmcNeqTYB9cEO1Aq2oQGTiXCstTfK2iIQaamrWbLLtTqijecWk0ciKRKx0aKRzPW
1tWh9oPLc1vS2asFuzXoP9yIj/2yCj4tZ9VP6W3gqHQTZ6ZWUklHoV5zwRJvgJ03x+MZYy5v9te9
cx88ijM3QqwoqtmCXKt5Oc7a6C641Zcwsno/n5HTzxiglkOLmzqVrXDjHpmy/Fswn0d0pTlKKma/
2T7bZ/tsn+2zfbbP9tk+22f7bJ/ts322z/bZPttn+2yf7bN9ts/2+fU+/wOUaCtzALgBAA==
