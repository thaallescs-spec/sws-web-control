#!/bin/bash
# Instalador do SWS Web Control para macOS (setlist web para REAPER + SWS Region Playlist).
# Dois cliques neste arquivo. Para desinstalar: ./"Instalar SWS Web Control.command" --desinstalar
# Os arquivos do script vão embutidos no fim deste arquivo (depois de __PAYLOAD__).

set -u
NOME="SWS Web Control"
LUA="SWS Web Control.lua"
HTML="playlist.html"
BEGIN_TAG="-- >>> SWS Web Control (auto) >>>"
END_TAG="-- <<< SWS Web Control (auto) <<<"
PORTA_PADRAO=8080

azul()    { printf '\n\033[36m== %s ==\033[0m\n' "$1"; }
ok()      { printf '  \033[32m[OK]\033[0m %s\n' "$1"; }
aviso()   { printf '  \033[33m[!]\033[0m  %s\n' "$1"; }
erro()    { printf '  \033[31m[X]\033[0m  %s\n' "$1"; }
fim()     { echo; read -r -p "Aperte ENTER para fechar " _; exit "$1"; }

DESINSTALAR=0
[ "${1:-}" = "--desinstalar" ] && DESINSTALAR=1

echo
if [ $DESINSTALAR = 1 ]; then echo "  SWS Web Control - desinstalação"; else echo "  SWS Web Control - instalação"; fi

# ------------------------------------------------------------------
# 1. Pasta do REAPER
# ------------------------------------------------------------------
azul "Procurando o REAPER"
RES="${REAPER_RESOURCE:-$HOME/Library/Application Support/REAPER}"
if [ ! -f "$RES/reaper.ini" ]; then
    aviso "Não achei o REAPER em $RES (instalação portátil?)."
    RES=$(osascript -e 'POSIX path of (choose folder with prompt "Escolha a pasta de recursos do REAPER (a que contém o reaper.ini)")' 2>/dev/null) || { erro "Cancelado."; fim 1; }
    RES="${RES%/}"
fi
INI="$RES/reaper.ini"
[ -f "$INI" ] || { erro "Não existe reaper.ini em: $RES"; fim 1; }
ok "REAPER: $RES"

# ------------------------------------------------------------------
# 2. REAPER precisa estar fechado (ele regrava o reaper.ini ao sair)
# ------------------------------------------------------------------
reaper_aberto() { pgrep -x REAPER >/dev/null 2>&1 || pgrep -x REAPER64 >/dev/null 2>&1; }
if reaper_aberto; then
    aviso "O REAPER está aberto. Salve o seu projeto e feche o REAPER: a instalação continua sozinha."
    while reaper_aberto; do sleep 0.7; done
    sleep 1
    ok "REAPER fechado"
fi

DEST="$RES/Scripts/$NOME"
WWW="$RES/reaper_www_root"
STARTUP="$RES/Scripts/__startup.lua"

remover_bloco() {   # remove o bloco do SWS Web Control do __startup.lua
    [ -f "$STARTUP" ] || return 0
    awk -v b="$BEGIN_TAG" -v e="$END_TAG" '
        $0 == b {skip=1; next}
        skip && $0 == e {skip=0; next}
        !skip {print}' "$STARTUP" > "$STARTUP.tmp" && mv "$STARTUP.tmp" "$STARTUP"
}

# ------------------------------------------------------------------
# DESINSTALAR
# ------------------------------------------------------------------
if [ $DESINSTALAR = 1 ]; then
    azul "Removendo"
    remover_bloco && ok "Removido do __startup.lua"
    if [ -f "$WWW/$HTML" ] && [ -f "$DEST/$HTML" ] && cmp -s "$WWW/$HTML" "$DEST/$HTML"; then
        rm -f "$WWW/$HTML" && ok "Removido $HTML do reaper_www_root"
    fi
    [ -d "$DEST" ] && rm -rf "$DEST" && ok "Removida a pasta Scripts/$NOME"
    aviso "A interface web (Preferences > Control/OSC/web) foi mantida. Remova por lá se quiser."
    fim 0
fi

# ------------------------------------------------------------------
# 3. SWS instalado?
# ------------------------------------------------------------------
azul "Verificando a extensão SWS"
if ls "$RES/UserPlugins/"reaper_sws* >/dev/null 2>&1; then
    ok "SWS encontrado"
else
    aviso "SWS não encontrado. Instale em https://www.sws-extension.org (sem ele a setlist não funciona)."
fi

# ------------------------------------------------------------------
# 4. Copiar arquivos (extraídos do fim deste arquivo)
# ------------------------------------------------------------------
azul "Copiando arquivos"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
LINHA=$(awk '/^__PAYLOAD__$/ {print NR + 1; exit}' "$0")
tail -n +"$LINHA" "$0" | base64 --decode | tar -xzf - -C "$TMP" || { erro "Pacote corrompido."; fim 1; }
for f in "$LUA" "$HTML"; do
    [ -f "$TMP/$f" ] || { erro "Arquivo faltando no pacote: $f"; fim 1; }
done
mkdir -p "$DEST" "$WWW"
cp -f "$TMP"/* "$DEST"/
ok "Scripts/$NOME (script, página, QR code)"
if [ -f "$WWW/$HTML" ] && ! cmp -s "$WWW/$HTML" "$TMP/$HTML"; then
    BAK="$WWW/$HTML.antigo-$(date +%Y%m%d-%H%M%S)"
    cp "$WWW/$HTML" "$BAK"
    aviso "Já existia um $HTML no reaper_www_root; cópia de segurança: $(basename "$BAK")"
fi
cp -f "$TMP/$HTML" "$WWW/$HTML"
ok "reaper_www_root/$HTML"

# ------------------------------------------------------------------
# 5. Iniciar junto com o REAPER (__startup.lua)
# ------------------------------------------------------------------
azul "Configurando início automático"
mkdir -p "$RES/Scripts"
remover_bloco
LUA_PATH=$(printf '%s' "$DEST/$LUA" | sed 's/\\/\\\\/g; s/"/\\"/g')
[ -s "$STARTUP" ] && [ -n "$(tail -c1 "$STARTUP")" ] && echo >> "$STARTUP"
{
    echo "$BEGIN_TAG"
    echo "do local f = \"$LUA_PATH\""
    echo "  if reaper.file_exists(f) then SWS_WEB_CONTROL_STARTUP = true; dofile(f) end"
    echo "end"
    echo "$END_TAG"
} >> "$STARTUP"
ok "Scripts/__startup.lua"

# ------------------------------------------------------------------
# 6. Interface web do REAPER (reaper.ini)
# ------------------------------------------------------------------
azul "Configurando a interface web do REAPER"
PORTA=$(grep -E "^csurf_[0-9]+=HTTP" "$INI" | grep -F "'$HTML'" | head -1 | awk '{print $3}')
if [ -n "$PORTA" ]; then
    ok "Já configurada (porta $PORTA)"
else
    OUTRA=$(grep -E "^csurf_[0-9]+=HTTP" "$INI" | head -1 | awk '{print $3}')
    if [ -n "$OUTRA" ]; then
        PORTA=$OUTRA
        aviso "Já existe uma interface web na porta $PORTA com outra página inicial; não mexi nela."
        aviso "A setlist abre no endereço com /$HTML no final (veja abaixo)."
    else
        PORTA=$PORTA_PADRAO
        while lsof -nP -iTCP:"$PORTA" -sTCP:LISTEN >/dev/null 2>&1; do PORTA=$((PORTA + 1)); done
        cp "$INI" "$INI.antes-sws-web-control-$(date +%Y%m%d-%H%M%S)"
        LINHA_HTTP="HTTP 0 $PORTA '' '$HTML' 0 ''"
        if grep -qE "^csurf_cnt=[0-9]+" "$INI"; then
            awk -v l="$LINHA_HTTP" '
                /^csurf_cnt=[0-9]+/ && !feito { n = substr($0, 11) + 0; print "csurf_cnt=" n + 1; print "csurf_" n "=" l; feito = 1; next }
                {print}' "$INI" > "$INI.tmp"
        else
            awk -v l="$LINHA_HTTP" '
                {print}
                /^\[reaper\]/ && !feito { print "csurf_cnt=1"; print "csurf_0=" l; feito = 1 }' "$INI" > "$INI.tmp"
        fi
        if grep -q "'$HTML'" "$INI.tmp"; then
            mv "$INI.tmp" "$INI"
            ok "Interface web criada na porta $PORTA (cópia de segurança do reaper.ini feita)"
        else
            rm -f "$INI.tmp"
            erro "Não consegui configurar a interface web. Faça em Preferences > Control/OSC/web."
        fi
    fi
fi

# ------------------------------------------------------------------
# 7. Pronto
# ------------------------------------------------------------------
azul "Pronto!"
echo "  1. Abra o projeto do show (com a Region Playlist do SWS) e salve."
echo "  2. No celular/tablet, na mesma rede Wi-Fi, abra:"
ACHOU=0
for IF in en0 en1 en2 en3; do
    IP=$(ipconfig getifaddr "$IF" 2>/dev/null)
    if [ -n "$IP" ]; then printf '       \033[32mhttp://%s:%s/%s\033[0m\n' "$IP" "$PORTA" "$HTML"; ACHOU=1; fi
done
[ $ACHOU = 0 ] && echo "       http://IP-DESTE-MAC:$PORTA/$HTML"
echo "  3. Ou rode no REAPER a ação 'SWS Web Control - QR code' e aponte a câmera."
echo
echo "  Se o macOS perguntar se o REAPER pode aceitar conexões de rede, clique em Permitir."
open -a REAPER 2>/dev/null || open -a REAPER64 2>/dev/null || true
ok "Abrindo o REAPER..."
fim 0
exit 0
__PAYLOAD__
H4sIAPAL+2oC/+y9W3MjSZIuNq/FX5GD6toGqhIoZOJCECzWLKuK3c3dug3J7p45VTVsEEiS6AIB
NBK8TS3X1uzITHqRrcnsSDKT6XLmyEzHdMxWL2s6Mu3jqSf9jfkF+gn6PveIzMhEgmRfdmx1pmum
SWZmhIeHh4e7h4eHR+1h7eFfvu5dfBH1BtHsF/8s/+r6b9nver3RTP/m+6AeBuEvvItf/An+ncbz
3gzN/+LP81/Y8U7mw5NoI1hda3YazdVmu9ZabbcbQWvlFz//+8/+3+7Xu97X0YH3dDKezyYjr+r9
esfrTwZRbXTa+wnnf7vZXDL/g0aj3fxF0ArBdfV6c7WB+d9shu1fePU/5fyfTSbz68rd9P3/p/+q
Ve8vB1Hcnw2n8+Fk7C3yw8kkns96M8sX3rQ363m9g9lw5vW8OJqPhvHcG0+8fjQ6HfVmK4TYO50f
T2be3nFvNIpieTWeDMeD6MIrD8f90enHfxhMvGk0wo9efzKPvFKuYbJfqcKamwezyDs96Xnf9sbR
qAckTrxJgg3ARIA7iz7++4k3SBEqH8/n0+7Dh9uvu9PJbN57OB31Lvmldjw/GVVqAnmKtiL0ov/x
351E6NUg6cXDee9gFAHMuOedRDFan0Vo7eth9bNhxYvY/x6wGA3H7wXU09Hwu9PIGydYKpVG82g2
Bu0i9Cnytl/HXjmOUA99mJ7OewPQaD48i2beSW8YewPtJ1uq1LytuO8dRv3jXm1lZTTp90be7tZr
z/zbIN3e946iWn8yPhwedePTg3Lge0HFln26s/16b//Z9g7KlgfRwelR7SiaD8eHE5Yr7ZYqtXhy
OutH3SPWLf3uL0t4XapUuie9ef8YL8q1+5U3D9++fVeqeEC0VCsZ2K83P99K8ChlCFuyuH43w7fB
5HA4isoOLrWa9AK/St/NorEVNBhpUPF7/iPdX3NsOe5DjOTssNePvHMwUXkW9abRrDYcDys/ALB2
4fB03Jc5AYhsp1xZYZfNR3RvOKlNptHYNgby7qPBfelzBcScHZS0yvAQE2SOOvPjaIzxnZ/Oxt54
OCLrOjBRGVAPu4A3KJfu90ztw25/NImjbPPDWTzXrxgasGGE2gTQPTLD9+Z3b2dvx+8eYPAGkxXL
N1qbMwItsVoy2v34dHa4f2/wYOOLvb3X9+IH96q/whP+KONXxeBieiMA2JnkpfkgIA8x08tkEvCj
781np1El03Opbbtu/0mP2H35jU6xVFLClra/DSQlA1/+MPbhjByYuS2k+WFgprPhZDYcwILuqoh4
KBDx/34v7nnlYC2sBe1O7aLiPfaCeu2Cv1b5rtoI5GkWxfNJnu9mvfH78nDqjnvP9w7IedN0lnJ0
7tXcQTKF5pPx6clBNCv3wIzJw0HCkj1vY8MDal5vPGAFPLQ7mYEKEnonxeuZAuFigVUL7zHhmb8f
bXiNIFOzkR/Kph1GrzfoTUU2RrF3NpzNTykby1/vPve9Ly4x0apf+d5X8n70ZHKBv1+c92aR7z2b
9N9HswqYot87Ift4H/9pBNvW0vWr7Z29LzefgzIfvNJZBGxm42hOqXcej/jrmNDvVc/4tzY8Ophc
yNMJm+BfA2mEf40mk+kBhDD/hjYcHMn30/npmL975wOBORqdl7yr/MgOY9MB6JeTSEeEf1FWy2/K
21KlO5qcY8gqyUTf970zmejTHji/bHqUmeGUNYCgk/AsO/E4FZdOpd4ojnQMcsjKI2ZKRgCdAwsg
S2GOUS+9fVtyv05OOZWNXNy6iPqvZ5N+FMdlViNLlIZTVVwl6erD+GA4fjg8NO98rwXDULVOyQFL
NeNDxUdjX7kkopb5cOXLf6aoKxCBxw0CEfzW7x3AeuiNjiecsQn3dQnlmBbFCXrSP52AB0HTyXns
lTZtIWiymtcteQ+9F72+V4rG9a53OOodxRv4kJWZ1AAZiXsvBiokhvv2HhTzomRNO2sJKD1E++UM
yPKbe+fvHlS6qrH5qbIgQh19M3XxI+TrRXpp+/VZs5QX6sNpTpVQFN2rZX5AMmXaj8hrmXbyQECd
+3icG/2zCK+wX0AXkEgfUpuM8mY4fZe8cMRmEK7eqxn65z+11+7VwlZTvi9QJAG6IUTIfCN/vrkr
9ucDL3gnkkZ6NpyCbfuQaJwVRqqjSDmVA2aEFSFIWQwfJsDVUgUo9iksOJglOivsdC1DIl5mGO+i
pk3/7YZ3af50hYL9/Cj56lI0KYR+sIThGRRx5/twGstETCbg0PciR1ARRU47FnwzJGEiAsyJIHz8
Ebr8r8Tw/sHWnrGJUlsv7RlZM5WB5v3ggu8D8wjemQ1B+dPZaEF+HpwOR4NyxhKUxkCmu0K4Dc9o
VYUCsLAN1y1VLJEAGl+wFhuOj2qgMQqXS2aVcy/u3ovxE5NTKDy4eOdLI74Y6xnR/N4n8wDUd7Pa
dzNa4GWA1iIJApP3wogsCDSBjgyM7Ynp4ddQyCjbbNYhsNv1laPDC1rcQGtxFakLxnSZCExZvSKV
sGg7RElZmGzOhj1qzqCT/Ra631qVBSr3I64A9qKLeXl+gX5fYkqgnvbLBZS+VQjzc/SBBU6iHmxg
GGIzQkgrYlj56xLFQJ/j2knvotzxvTJfnqNr8/MK5H8II+syqTOY9c4TQI5SHfXiOdaK/fcAVl/o
A2tltGzfoIalBRaCs5SJ+piMIiT6ZJ9wVfmHRb87xQBUMtyzYhWdLlLNqhTL0O3XFp70f3IaR/v9
3tT7C1h+tOVU06Qok1H5StgWJmxWOnJKbMjPe1oCMjD56E6CZNXjEGMBgRV34Mr1Wh0kx881/tSF
rv0O5YwCeK/jdK6/jqXMwqTLYGyhBwQq8MMEMv85PFXaziwwIcp2tjZfb+1444//K9fztFtOZ5Di
NfAnJ4QDxmnG/L+4idez6DDiqjgidc3cefhq9+lDNvnY2xwMvMcA3wH4sBgEJ93BDDYKjIV0SfzY
K3HJbZZk9WZSnXrYUMdM/R9Mn5ekA1f0dHUMhbmyS6sfQZivom/JrqmjBybZtcSqZamUMTd0ZtF6
vat9zn3BBIqoCZq59/Hw91EiAobjZPo3Dd8d4++gWa/kqkHejVzJgV7K34dYP8zKAvQhjH5MFm34
PpCu5IHMJ/MeoQiw+/niucKTC9uetpEKKkJRWZWvQuEW1m81MMmU49prcukr2ORXwfDq3MwOPY0E
4gnYY9cet98ul3wz81lH7s3FuzeX7zD89UU7rQBdWlwXHCVLvQrIR5KyH/x4WfzR/el0ocgAzT+7
f9+S26GMDT466pCi7WKy1tqcku1QfraWzp6nqnG9AlcmFjwxPKCpO5ITJ9N2s52RNSB9sfDPNZoz
U3bY4r2Bpz8TTSROUszbvtgD0By+QK/kcGh3Mji4pnCiBE6ng97c+sjMwnNACVGmUjU62OjXn3d9
0n+1fxH7v43F/d/g5/3fP8n+72pm/3e12enUGo1WPVj7eZr8Ge7//oS7vrfd/23WV8PQ7v8i9IDz
vxEErZ/3f/9l7P/aHVXZV8tuj1bMNqe3Ex2x8muzFcjlEQAt2wrGhmfM4mEtrNXlzXQ2ORsO9LPn
ZXYU9ZW7WZh9U32+/XTr5e5W7WSgH95gL3X8zrs2sEExO4B7WOu8kD1uj5aQlF7eJ920HvfOoiPx
/6ZbxnA2q1du3lWgJx//KcZWhNejgw/2cXQynchGTw9mks/Nuv6wN/OFhvw1+/iPF8OT3kN+5oYS
0JnTNPJkN3k+nClY2FDfASDsp1nShG6qx9hKtq9itDTFfu8Af42TbXHZ91Ywr3e2X2xt72x6X239
q9SzjT7AkV0xPfC8oObtcJudWHu9j/+eizzuUZ9Fv/fKm+K1oDFYuHuP9zunY+5ky679dNizUPFv
kh1lZaSJsdz2z8/P9znhPNqIcczhUAfSt6fj+cSEAOgCvGaBhjXvVgtor3iRXPId7J5Fh73T0Tz9
2s2imzTaMPQpXctuJUYMLA82cDb4n+5tv3qp++qACIAGnt16/2LvxfP9z7afbxXsvGuJJ1ufb7/c
39v8nCWA5ePHjxfmQhmTclLhJ1tr6+UzqeOZWo8ePVpWC59srd2/3n69v/3ixdaz7c29LeMRF1cT
/+h68GgYnt40PF3ypujxCVkSUqG3rttOXToGD4cndBgkLB2fgAGO6W9/b+ae9b0+/WLr6V/vb7/c
29r5Svbz4JdQD1ccHZ2CkWMTcAFBM+RuIPj2/4RwsQTa3EsrS+1WYe14ODZRGdgNPJuUCsIwbhGI
sbO165Y2S5PPo/lOpPEXr7FSL+fCNl5v7n3hfd/AjcXID4JwIN4c2fHZzqsX+7t7m9hWfC3be1/v
7n+99WT/6auXezuvnqefdKgrK0sLiM/YYgRG4u6AUnn7GWgKImMS94TaRrCWpzNsrfSPhwPx74wm
vcHuefx0csJi8Q8NENnc+fWX21+92v0BtRe247FE+oyxHdNlgSDTHxD0Mbg55MPUHRTuzp7PhvNI
0fK9wXWYnV+LmUzEBLfDrsAtD67BR7a/fkTsxUswy/PNj//lx3/9CgpsQPU4pweh680mEsl1MuW2
fvzxH72T0wG1A30GwBMGW+UnGM/hGEptNPoCwrN8Eh/FLu1EJ22kQ14YwpQI4wxZpWrGN0Lgb+7y
p90WLG1+tb37qqtu2VSmMyxKHcqHk6F1psLM8HoINeNv/F9NtVopt0OXdazrFv05dzYof5yoq5yC
Lbn+kh3scs9oRDzFi3n0bEi/2WR2WUZp+Jhc+tBvxN0yNFFAD0uOhHwsXuEG5CJxuPOcsDDL+VKo
YOe1gIx//Lt/V0hDsTYYYUirorDLhbvQBS1s7exgnKyTnxpi6B3Nemcwy6RhYlzomSqaq4bjdsHA
89PpAtPF+n5x0HZlzOOS+25/3xQXA8PdMzqduZxrSi0GUxzgF3deUoOBYN+OU/rgOefHA0lT2XLv
u7cMdXEUTMWtWrIsQNZiTNx+dAFjJS4fmsCB5bqDkmXdRg8eSuhADq/S4itrwtheOF0dR+dux+lI
P51pTEPS+zSswXLvQZYFtfI+N7ad+qZVRFy5tQ2EaJGJjT+/N6R4KRMMlXhEfqtYhf529iuhrCh1
tzL6Ydo2VsYBHdYVdllHE38Q9CJDLm6AHI1OI4MCJ2aplIRCEL6xFN6OPwEOGrEDlBweyqDDdgWe
RSTrn6VgRFGBj99/q3WWSwHDsj5L314ObMt6yqORCuwZA0ZlklkreOXMrKn8tKLAQL61NMCaJNlU
/AIrjczOr8aCJrO4MMTUndPfLwzUhvUUB3+6YUnC5Il0zcX+FHD2jwstdayLskAiHuXSZi6899uP
f+CKFD+djVet0dOxkMqUBJVaqVK4L2SWoSDgraAXgVFJ8zqNh0/DG3zaMFztmTXz2+ULxLclR5kv
Cc4rfUarB3suXA1Put6rqV1532rJmxeeb4uXwG8hc2B5vy0tLH/fYgWL2KARwuEykLJqt/Z2/Hb8
LJpOsGr6Ht2/YXGcR778ckIfBeMAUQ9hmX30ASbS2TCWAD4MWnTB9R4fZKvL+BZUBvh284l7yNHs
ZAjHSg2S4Icbss+3tve+hCPl2ab3+vnmb59v7+55z17pmgb9qM2mUy/ujc4mP4XRir7EkfVJxWVa
iFE2nkU++MYMYFzk2CgEV0SYejeLiQVJXSQ+EKv3GP99UhQvZ+PiYg2MS8QpAC+UU5zHjgIrlM2O
lBz4HuNw44LoQQ2M5m9Km/uVggnMcMHB8q3j4cCNoh4OigWJAkG0c/2iaTzbJjByIOEwYHXnS36z
2Ol6jW6HYQRCOQ9pIOFM/ZEbmU4n2MkLUQiBEzV4qy3qPHmVtDO18PNUfbT7Fy/2dz5/uW9ZnRSu
VSs6/HkuESCF9MW8UaNyYtb/XW8BNOQpQqHfBHSyWC8sNPtZ710ROClMbR/F0x6DRM4ww9WTU/I+
pWfzmyVcxHhpX8J2lxT4TlRxPHecOwVc8B3dIp+WPuUgyN+lT0vp39+UljOaMdy5xLYtid79Dvve
ebMyYw9qyLhWpKpMkAx981bsQyCRfikGxd4Xg9JXYp86Ab4VdR3l5+rS+WrR9W1LAj89xLBr5mrx
RC2aNabzabj8EnHywS2JuPE+T1zR8lVEMDRBCREHdr6Jo+rqxoCOnIIW0eZaef1e/zjSmNjFeHoY
dbPJiTpt4P3T/iY1xOrb5OSbxDWJaijd+6J770VXYsOvrEnNmoJ+jrEETi2ase9wwE6+jTDHsCUC
CylxLYg6wloSvyKv/HQ+Gz3YNZs52HCApOk5h/tu42sw+sQ1WdOeGceILbMc25cWv+kkjj/+w1kE
babKfYaQnDMRFVPt0W2QUn2zca3OZECLKbeRDyPK4haNj7nzsWRbaJxgZoh7G6IdY2aN3cMdo1zM
dLxgtdcM/4qGUQCU0uuw5qLe+wX21C4IopzdWl7sAGrk4J1TqD85lQG86/DyD7KHdrCk/vjfwoOB
LnD7Cc6rs+zgwVyOZvOfxB46ji6eTkaIcutneS2Jja3f4H+FqX6k56XMGkvAcX6+pK6Jyn1Eo9Yv
PpN/Gf9nzjdy9149vLD/wZI2gCuFa78j+v/JSHGZNMnEI6eR9NngvwQ/jJPM6/78RW+G00guDAm+
56aGCciTiLaFA4BgtWG8czRmkDhsxdnReGsMq0IlpMRh9UkF5wwPzIxsmw1pFKUzHg+Buqjo5hKS
viiMZcnMGUosoPKG8THbNOhYHNIx5s/rTkVYz/SPOUaw++olfzOMDZsTZxLWeoLNtmjG+Laq7Dpj
3EvcnOEC5sudbWxSYAFD2TZ29oZ1FxULtiE9EITrjTH+Pe4EewcQszy1ii0qbtJqTD5sFKxMeLSY
QbM8feTbHVCCwnIMs9+cm966mMOPiEVTxOf8AdiBuz36Y+cYulyOM6xfnk+U+/FevVafvrl3D6fA
7vXffeqcRelX8gdJcpPm3j3Mlt9gtvS7B5eM30sixCvFEwd8WB5XlkGrNQ4Ba6yHjQrPYXAYDOem
Csq4LvD2pTmEJ8o1dYvJc2L+vPkd984eVD5RG0jgqC+mzMNi84//MD8dTSqus/UYWnHh9ManpalO
qVK3xLMbpQEOA12WcJTDL6kNYD/E5zFff+o7nN8vW4QrvkNlma7bsZmszwhRxQO7o+H7JVqU6syT
XZ+Sn1N5xgARqyr9BjVXM+dCFiCkkfap0sxIgcIB+/RDafK+1BUQPnuNatgjlk5fgY9INV+6mkBN
GcR18OraiLr+GsEK9+IJxMzJEDNyfOQnctWeH6wnByVemDDZI/VESNgHbSNCgET4A/QanDBsVKQD
3dqchxpxoR4PErtm4W2CUtjf8uDnhT5cjNCoeB//d7BfBG/MGXxNXYiLj/8wHgwxmXswfPh1IrG7
EwvRfqYjw8al4CwPTDdZApVsMAlmw2nMnRAIplI2mgQyplRzjQ/3wFZqN9iFaMExctUPQuw3ZBr+
9c7VBjNhFsCR1erfbhTFaVt3J6X/PJKTYVocB1wKCo5tbHvvIC6bopWCcgOx/cvceRCtUvVmNdE2
DOvOKSfDBzbceJDzTAjfvLkrv+xyPMvHCysPMLaSA7N24Jeo7JKpTCR0joOJ9Q/phRa1hNAPQKU3
VzB4EvXHP68cQZAIBDMAOl9mNTlY7Iu8tD23T0oSPi6CSQaiWFAIBGBVWaw5q6m+FnnJZTCcdfYd
/sQblZHj09HIPb6ZHkEp8DSZyQpPvP5h6Z/oH9vta8LDC0XPijNUlEHsqYgg62mw42Wf7fiQC0rd
N/fid37JIGUfhYHy45OXYTKnzOA4hndaQU92YpHSB5pGZgGPip/9kogx/cZx0fMdlR9h/Dx99WLz
5bNXu8Z/yVfqyJSVI6WfESIiCV+Wat7e7PQ7hvqMhlwzTjRcB/HEg6Fx7ag0llwdhpIIU0BRPmH3
CU4bnL2meAr+0z8JWKZXwWG3E26rSCG4c+dGzpS8lww900DB5DyDlIaL3nvKbYASy4va7iFUzdve
23rBuKLEg1Qe2yA2I8ArEvkFMcf3BeFzNCDQdu+k5hnnNopNBuJslu6eTeic72l8ArzXP4XN1T8Z
OLkBrLczNcip9wcmOOb5ZPIe28lpcWuloQJnI35R9lbsg3Ois8g34UTdmC0pan7SL4liInalffrr
6KvLOO1KaRUZuCVVXm79Zm9ZPWjCs2X1Xu9sfXVde08h95e29/TLnf0nm7tbz3IQVKeSzyUPD7cU
YE1n8FkGV/BZBjeBMD8a7ZJTCiCw5P4rbKDvfY4t8BevXu19sbu19deClFH2DL4Eu9EPmpleCXi+
fTk5vxZ8Cnr/1WefObix8q7G2t2q8kun7uS9iRJT9iB/JQNvH0g9ZT2JDgTzaaoJC6PfG2+faI8i
C83Sy8KwHXSfFeciyIWbrcP5cdIMYZcPx5WVrLtbz+en2EEtLSCorlEbw7c3OToaRWa2yHLMRV9M
7iBvB0vdF3DI7b8am5plp49JoI2WtlgluQbSpa4Awv7fGZj1y+2d6BClj8tB/rC3+q+meBwlfV5W
uRpUVhzXvZMq4DqsdSSIuJsOhhod/OHW3z2enGMDMJ6Mohfx0cIxcRMPlep2mPs2nKOS30b/9vRk
uht9J+eoc2PdG4+hUvvRX6FIWbKOaa/SKvYve0LZ4hfN7bK6bGJxoV9ZGJaPrUOEuoKogPaVYYpX
q5wVdCUZLHI7FpoQzapAKNS6Szszv1zvlaVuATPbFXflFpxGrDJsJgsAPXCpOA0m11Tn7M4MdpIM
oojwRWSJ3w+nZSx2K7fsL0qU00lHo0DHqMKD4s4sc+ophblq41LNBG0ooWGkgA8lrwuD6KNZRsXa
BoFecrBUNa+rYkCwRNDRgk1LWGVhSoguc/qRC5nOyIbrhnXJeHAvUEei4KTzdVWykSk/MIDz43/9
dPvVDzN28maGzaPBgBvxfy5yxcr1sZQYimgcc6ATgzWJoIRtuC2xd7LtD29KVUuDtLXJ7Eh3/xfj
QQvj9dj1X58ydNnE8/VsKsPkUY6FmCMVvmdjNo33T0I4TqUGQZWegxawknsa5FdSv4IcR7EHLWDo
0nIVr6CJZVd/BO3oKaNPmBzCG338g5xL+IrdlO9yuNc0bhM32pCMQZpDkWYrN0vlcEWNlM/EgTsq
D9EkO9HJ5CxK8E1HxiQo6090E83hQnYH82zg5QPS/YJC+5I5sDhl4PWHLBRamoMGRDmLuMjCaf1j
jo6nvg1BMb+xUhCnaCpWcjp/UUNIQyKGbFtFERNLSViWtSc99qa6DbEqdpjcpK+y3S7aPl62n2kT
sP0VA6DUqUUW7H/8R0TTSlA2OPpX3paulBiXPY1Mzko54zT8veEtMF1vWDNTGu/Poj03VuE6Wpak
+P6coY/MKaeVxadgqvG06j7Ean/IgHSmlpEyOJiCdHQJta7V6LByGV45U6unlKhwRxtlZkBBHCgS
u9BYVUn02DhWy9kVOj75xnhRK0b+1NRuK/lAslcevX9DBi6kAWiG5pgB5hCepTMD0vJyntYVPJcx
DqMgL55mwclPmVJG9ju7kzL2RX2XfC9JLxfom20zQam0bWXhL6XbGpl6E3H412JUZColinvzIyK3
Xr167cE9sLv1+ZdwezB86+WrH754Zz6bv45gWvEP8bzrn8J++qfsLjmpgI6j/nv98gQh99guxE/d
vav7BQmCpqcHYIPjJRsY38YSH7R8nwPjK2UgWCwyhauT4lmTeMZ8gZKZNTadj4DckO/Xxr7S45mJ
dx1PzlPnRnaKO0l8mMXEEoshV9mzXNlpaottsF6ah0hfyS83P9G1PbcyyU/XJoBZWaDAtUDYpAuB
z1kQmVxN9nTU2VAPScFw+PiHIxxJo6+Nbxiqgbf9YX+UHHSIsQ2JNA7e7OMfpkOj4NJMUtfKXcrE
TIJHHEM1y8L8orhvdsaKWOdZhAOw0VKZm2cZ5QqskOh7SMKByGl82ZVIo0+yeRSltFjlyeoq0Sz8
VlnwLUscgHELSkVZfwRLytFid8tVlxW06kPLZumlJxiSKS6r1KUO6gxra3nwdu6U4wJzW8Dk7nx+
32TeF+7gx5k+mWLyKxtHpcDeR5dityWMq7uJFNp/o7HWqJmrIxuZadtF25H57Epzdf84yzytInz0
9Lg3Pook8sHUdhN47kSjj//BM5G234lp3pW0MjCzGf6rQScPewc9hn/x2Le4bhGmw0BtPPVkzxzG
zPC0lt/jima6dVsmHYzghJAXPe6M+Uouqryc6IA0k9rAPtYd/MUylDaEjRaDw1I+SboLtzXXAGWG
PEoIh246MmICHhNZA2VDb4ys4DG6sXG32ziqAkSAvg6H6a7GGXBVIx0wb7VzC+bpMhWV4XjLw0u1
JQj+nt8G+l7Qye/qODl+qE6MIWDeo/wFEuHl/CI3CalU0DuC6qZKRrAv1rhJjeb3oHQfPNkE36U9
eO9p497m6sR4MjhwJq5DNshT15OsoEWn/pz/5+f8Pz84/4+9/wX3b/yc/+fP4V8mh8Qv/vnm/zX5
f1qrjXbu/pcQiah+zv/zp/j36JfPXj3d++3rLTl1/XjlkZzQHsHc2ihN59UnOyW+g3LAr5NoLpvt
iKaebyDT/WG1U7Kvufm8gTwZ0TmP3pVssPdG6Xw4mB9vDKIzhCtV5cFngAkS+VZjGFgQPD6yvs7k
gQ6CjfEkB7Q3nY6i6snkACZRFYZaFS+qyBLL0k5Dl1Gcq3jbKvPhfBQ9Ni6WRw/1ceWRcZzGsz5A
wYde+xalHz3U1/w+v2S5LjmD7s5q9eCoe7ce1Q+DYB1PUyak7t4NVoO1oM8XcpbmbtgLB42QzzBR
5t27hyH/x+fB8KR7d63Xq/fa6wKv1+dGNKoMWv3DQxY5mgDgYW+1OeATduim3bv9emMtPOAzLikY
d+9G7d5qvb6+crVy/wOiKLBm7NbXp70Bo1bxF640qCLtKB8OGJY2q+LN1QrH3T+YDC7ZleNoeHQ8
7wb1+r113nFwNIPpPejCXi6zl5V1Cesxz+xGZR0ezRnyjZ53kcBjEI3ZAWZarh7CDzm67MaXcCee
VE+HflXHU1/4sHKOJpH35XbJ35kcTOYTX5I8+3FvHFdj5m8RUmAM3w/nVeUUGGL9eXeMiNv1hRe2
5Lw3rR6jEyN2pKrowqc+jnlicDwnde4CkQ+DYUwR2D0cRRfr/IFRYNoD2Ixd1Do9Ga87xMBhjof3
YXUNL8QZT7P0NGYUC48cwup+mDrxHnLjFc7j+w9X7mq5pC1B1A5IUJ9eIMPnFK2TXOfaGAdQnpkg
thu08JlkrsJAPQJikmjzygKucT8rgS4HsNNvwOLDwhCScSppGfLNYiG+tSN9F4JaO5/eltDNZrhi
T4/FilwEJVOhkva5iT6HSccTNpzj6HY3wGvsEGNDTevKLQZXKzVIh2j0wSFKiKowyefkACThIeBa
0IxOMsyJOVVR0snoM/qrezplsGQvjkABnBEiPzhw+8hPNC2HQMxvnZ37TeBayYxNB2NDpKqWMWpB
a91MNHas7nFMybbnxwhoEuQiDPr5rDddmCaCWvISKWaR/3QYAzEEiH8wDXRIo5SkVoIYsmFdMDyN
2XIeuELBSnL0wZ3QIoQpCPKjpOKGtJ45/CQz41uoyeHhZdWeG5U+VQ+i+Tly9qwLV1YlVq17ALqS
OutHvamOkZKmSlklhJFZRmJ0+QNIziKK14UhaKCw38YQtMKiIZBnID7EIrwK5wZkRb8LHzMPDfM5
TiB7CBIbZVinmZtuOJ65yDUG71F0OO+CG0CWGFlqPjjzcMbKixVzE/dGRHPc1DIteQcfFsQs+kQ/
ltuXNTSxDPeE5j+GE2WTuxAXkQfqioc7AvMfZx8SvjnCnTjr/FFl5rsRFsFVFahxNziceSH+M7+V
VYhmIiDCHMsHg7AeNm8nKYAEfOAoAZkm5VXgZqeLNGdk2yF0a0rQsF4gixPEwAheR2e3i1+j14ia
zXXmzwFEBAlSQK/TMyOaZIYTGjxMtEj0yWn/uNpTfQOP75Dp0fjgdqOrZ74+YHMSULsHwnZjXqcT
4J4S9FiLGTbP6AGXF4MCpp9QcM4vu7VOy+WZkOxuoUJ4f1joCXj0aLIo6I8mFB9UL0uVTu14Mhp4
3GkdpWARzQ3emEfr2ENHAsWMcJodHfTKYavl2/9qjRZkeiLOxYz8TbnuvKviOi6KY85d06L8YASx
trxQPTDVFZ/ks2EtVvaxPDnBxjHZrAft+5cSqeGVkdVdDdtuuwneqdCA4kRYzvv4j9vUdw/mY4Zg
fVAubVzJm5ec3/qmebWik0y3/2lK8K8PlKDdIGGm6mWXWU8S2yd5D1N1gnkMvhU+48hMxkdZye7K
brUrdDo23enYMvp66QSEURqGYdt+tzLTfHUML+AAkfcBe9OGZmH/eIkEvVZk5qUw4cLot6RxpnOw
qBiXyLoCKUm7g8H5rsBtFAlcI2kcihiRsKilE6qirOoVOmA+XKdGOrdRI2Z4awNIuw/JxG7a16I3
MjL1MGyGffvZyJhrjAKnmMdB9LNv2IncKyWdI2UNMdI3HegXzJD55QdLFU4h5bUFg3f9BhJZ/s5K
YYv5FBeNRIMPyPkq67BGTnlAcq2bb9XJ4SGlULVBmI4cxsThCnKQUrfRSrQg7iI8MfEPCydteIqn
pEuB4yiap3LvcHgRDdZlutTXhZFlhSazq541+uphI+xYChohvdCDFe7nOKpKfkDA9cvy1wP4z8/K
ce8wqmI29qoibc1srrgyVf6i3PptOQjq95bIxlrQQbJMGHxVUG7991UJ+eu2rkw3JfWgI2mphu23
PS6y8ybZrQ33Rbs/OrGQX4oYSOd/3taj7Zix1ts/0j6SVr/mEuqa7uhiyqhYM8Cc1e6a0IVVuKar
yecn83H8Pays1LpyFLyZLRbcj7GXxABdai91jL30o0whB1FGYyMz0IdF40snIiNmpjgvh7l2CL8M
FqM/cB3j6kLXNGWHZHSzFmBmnetM0kIbdf0GbXJlcPdqsv/1YZGRZA0VH2M/9n23nqd+Uv0unWFG
JYK55CnVvPUfoxZJ6w3+8/a2nm/iwBCSIG0+wx8aAzV/aNI3Vbo4T9djttfR6bjHvETJeuHjv0WU
EyNwB8y8rSYO3tH/Mpz3DHSMo7WzYNNhTIQluiOGjcKhF2l0XjntFfpvbLCMf+eaeYK6vJinIevN
ZnivQvssV5apssTI8kzpuo9CFck2t66XkGTKU7rG3ZJxEOmvEm4DhaCXnuJvjpHHHyWxBY2PSMCw
dldfyDdWc77wcf0WjisSxawq6wvGop3euugsXknp6TXMIWNV3aLN/AQz0yhrN6qwu4WVvKSeGM5A
xJjJgRrOu1x16Jvw6lbGtafJLlzS4jFDtyvxY4ogSUvxhQ6aaHNR30JUq8GVFXlLFO7FoyOpc6+S
sY2LdHdO4IainPA/LgIe3k/SzA84OxjhMIXAlDvGcUgUcUWn2B6W40u8zUfyBNx27mD9YrrbCu3k
MQOfl3rs9aInLtAPBc60MHUAdUOrbaXsgtOH00/A0/nkqCpTQZ0vOcGZdZzQGAPkvIOklVV9Bp7w
Xk8eE9luFvfms1WK9uua2uuu8G7nCy+6mmyvxDLNOn2pRax+kTLjrOkSrJr3sj7I9sjhy8RyJsy6
+ynfg7ZTwlqiGYxC91vOkKKe157krQbXa1NIoQz/ItCcCnoaQfSPlzIpd5FmveF8kUdTAZ/j0cST
nvbDMmSGAztLOdAwuHJQlmXWF4fFclAnax0s4R5LnAJmCA3ehTywpgTMDuhSb7CabosrLiNUXGZf
M4Raz1mtRdoeu1662fXoodkL5E4Rfg2GuI96IHt02EkD/skbo/OwYYY32U+UgCiNNzqCj0WBymd4
fuMYJShhSgmc6Lk8P34tQTAGYlKHpcxAlx7/8e/+TdF3+MGBivNEr7hFLl/BIAE5VHpsYnSSqso0
pcfVardafSSz/bG90wNUkmcHXhYiRVgCEldw2MAt79GBAIeRTMiPHh48fnQwSwt+xqsRzLElTB9T
mo/PhZSKDGrZNp0OFRBDIiEf27sZkHjvQMl2kGKu48yh4QPY2YAwUk6IqPoVJP/7/8MQwt5ckhJC
yxdXhgIvWcocTTy62MwYmZeH7hjRDfn4j//df8Sxo+2n25s72qSSDZAYKl56PJ9AqKStS51rkXgp
pPjj3/+D6YHNm3GrHtDgSHpA7+bt+vD3/zdu4tyxPXjMRMKz65B+9NDQv2gq0ZZMGVtcKaXHm0en
vZmcHEjSnv7x7/63DLNnpioFeinHJOkqvfR4L584pIirEp2xdBImi1synyYCY7ISuY/WnmuSc1sS
mhl30aLmTZnylJJ8OehRCkotk5nFZrEj78W1JVM5UVnphHaGUr4+lXVlMpy6zCw91te9WZYRCup/
PvkhzLz36unmDjLH4pKK27KDM6edsVT9kCM4F3xLR0OTDVn0zJMuBB//8X/4t+lIZARudgaY4NfS
4//3f/k3/4W3aQ6nzLLca1Fbseg+siEUDx96e6eSSIFrQs+cJULMpkpFCWo3RzdhKg/NwMe0mYcf
/3AWwdg9Gk0O5JYWMX4Zo+HmvirjgNDGYxxGs6tVhFW/evnZ9uf2CdYHc3nPk6t3Fi7eWXdiW4Gv
ZOHRXKNJYh0TKPIc90opsC9ePX+2/4KXnmDLYH1Z7mlA0zuhZMhltkqPRTggfgDLYL0iykDdFAzl
KpXlCa0JVW9Y0aSqSF9N8shZV3NplDmmKDRe0du2cPJ6STYHBqlSX2RKLCZvYDEGzmeKLeZqYDEJ
WkHSzXrQLq1cra84Y7OFQ0c4hpOODRwJcJ7SGeAxbYyvuXjw9Ab3m+MyzyQLo/2uKT+rwbpUndqT
wnqkBuo1+WN3PtOrjkpalJHHe7JNAcNz05zBcc+QCHj7QguYRhB9y30lLbOeGYkPmkwPYevIO3jV
1bQpcgc3wih6JxPJUc2DHhCv6jPGKTesCwvv8aokiPJ8dYKT+rVNr5VTJN1PpDlEn6H7NdhxuBPc
fP1E0xJjXgwm/VNmyWde+a1RxD+fXG7ziHAlMy5f7m0/d0YlOcVzeIKbXsUUHx6WfzmMP5PUQXjl
/c3feJLBCdHoSilP/njh3HwszmrF6Dj3CczfwMzB6ZiT/Jd78gUF2vwcEyhftuspNCENu7drjupU
arB55RCv3CJfL0nT5qz4sfcr/PdAzvQ/8HDIt+I8xOhKt+Alw4fSW9sjpsf7gF2uS0neqpf1LOQG
ZI+9KzjjecYlqiQlY769oizMJ/GLuErveW9xLuwtDrV7b99C2lD6wbrX9OY2vDxF5hT7wv3yWQre
EOGsgkRJmA/9qIzkdeVa5SFSB5VPMGNEQvJEC6YD/FK/wlk8/OraV2N9NZZX7IHLGEmm5gLmmIzt
7CzzBl7DJfhT4DqT12bzk0HJzGk8rRvmEhCuLFh3ZAFvu+e5p/Te+3U5B6wjYirxaFpNUsEKPloi
HQ1T6gNyVphAfAngmnVxeTGEAp2TyNYoud96joopeVcKyWJDODyx/iv9S17j4m/kQ5iT0OUPODKD
t5pssyvMMzQJobyrCtkN/VnxHEnmpb1jnzDdy8KAK87NVPr9QzIHDAE/KauFKDUlzJcu3qdJst5S
ydJX8RxF4yMc2NDD2wqJkiWRE325GMiIClwHMzxT0LiVsCYZEIwFat9lWxMS/8VfeL90aITuy5PQ
mr2XR7Jcwgdnvd8PcdwV30rFhq3FQTqIlSio8fQYZyDLA/mQjA5zf23hrHy5HDNvqVoGaU9ncgTx
Fn1FwZqYTSZbZInL+VL6TSnBl/uUGMN1c8qrHNdMBlOWkhV1TdfnXMY9NdlOTaH1FQe18Y2IeeMs
StifLfFldgSGPPO47gI+uQXkkxxo2vjyOgs8Fi5OyaAjUcZB0fFJxaFBkmKOSsIk+8N94hWbMsBw
8M2IjbJ4aRa9dQNltIBd0i6Y64//1f8sDPXxv+cIGSxs1RR5ZaORwf7KIdz8ZvTmWfToxCvxbRYv
0aE1m+ivkiefYjB33w8GW8za85wH9MeY9iVcaNF/jxNIauxy03WXK5LysLJsYgCOTo2KsBl0j9k3
SwSIhFGLAJFFhJTmX8sECGdtRm5wrWiksx16M+2TgZYitekpToslcmCaKIUHXvaNXjqPsWPiXY/D
lvsMDV2RQS3ZfmeacCUcy6YW1n/6vwQcR0JAmjx6FobF3KYghARzn63QzHRn8bs0aTLOlbnUreRz
lMBAKGU4zQFY4plf7I7Facc1SaupIENjJpxW+xbRD+WS9K3iFpLodk2KnitlZeUnZbMarNR0OYjS
vyxb4S1ty3dVQjAGmH4E8liMW1qxEM/rSbYdyYyiAcKRPsjNSXIFrjm1bI4zFl1YmzU3EV+wzRAD
3MCYqjosZxgsSeEG7h/KTRxEdAj7MzPmeDflV83nOXynWTH19aP0LUhoeNpY9oZf8SK1pcGL5mtN
jPtKfhmQZONhPUXRwoN+uKjA4jDocyzSD+sL6wljxw3XDVcIUPMSRsK6rjScBP/IKXmEQ61IB2MS
H02HMCRxzpU5ZWzI9pgJZYd6oyAcMBOrJxNkAbpScdvJf5UrIdwSoluSpQ8XNRSHXCEjMGbkDZJB
lf0JHNqMtPdYIefHCm8ePKg47Q3Tloamx4J2F2kjcfSXmW8//gekaeylhj1NJ9dIUsPpgzI4Pa2V
nCzTVWG6jsBoUD6nTDeJVVwSLXz75YbcYmOlnthrHEG1faxu4JL7cldOKExmm8jBVhLvP1pPrJEo
a40wl6tojudisEmKuXJJY6og5YdiP7Ph9WuKi49X18PphDAVZeSuq8wIsoXKj5w2ryquEWEURWLw
pOVAqR52cGoaiIi8HpOvcEIINvBBhCw1Q1rXes0vWpMYl25JN4xLSRMAbJ37+QFL8PuVmb148U6M
EGoBuL1KGVPnQNEUylSy41IuHZQyXRpfLIGvWae65kXdKLfxQQ411P8VfiTImMuNzQQoqahVVrKt
ZLQnNWfaJzgeRArHFE68kl1Fl4uwRBakJcCrCfnMlgUYDtmP5mIAQIgNIuSJkisAqfdYPSW43R+p
GCNVtrPtSpy72jhH4JsniYXg3WtxilgF63NifB+7jfWKrJ3vmbHgpLdXCzGMwWZrSqRBIkiWyASp
/MCR4tZ0SrBP9kUqBaYWq6umU0H64bZUKskmS+lGGsG9cDMmGWUqC6Gc8UGeSRsUVjFmFcwd1Q7D
+LX+retCNpdulS3INlMN5tOeamivd4QLuGkvlR03GQRESLs8+6pdkQVZTz2e0YlYWboZxyfTfLIN
c03j6t32po53U4DJxo0FZPdlKjUbcEkLxEBJy8ju05IyGS8FblN9/QquRUlrbG6CLHBYnJ/P9idj
ekkuySa4AE99W4dy84SuqnF72kRyY/JrDdEwyDEgSYxSI+GXEjwjcU7D8Wm0nls08GtScV5KBeUc
0kRdLns7my+B8Q4yyCamsuPJFB8GZClqBBANQT21difJdTefIZEES4Tv3K/q9Zy/ab7jIJPnVKml
GRmyPlDXeWiyUxv3g2iBxMBJcYdnGJTe2yqRvYmgvDbe9dwS7wwtqL9qXouxhonKjYqxSEkZ1wBn
R7SBJH1CxfUwnaX6LEHJ1pD8DETnTFS29eHCAnP8u2frWeeu0/PkvpFF0JIaNAuavtlKmv3OGire
IcJ2JryXMnXEZyPl5OLCPkN7nJQc5cTdS/g0CB3YWUMlYYszy17dUiXPIQYqaySaHX9nJa1rzLoe
7K5DFcho3mkH71cC+SqbCUp91Gf2+1WysLnKzk5J37hbNCGhLXcliqD8fsj7YOTUUWr4x8bs0EAD
6WKcWXKzlggd7pvTMJEXXbNojXNSik+cFfx6tYK2JQ0ZnK3JJlJiHIijKDs39AsujOhHmpOH2jBx
wz/yGvV63ZjQaa4fd7I9RtB73eRmSzuuAH/FbEvAG04y5q3bRcoybGNt/YY3pyNlu2elmhLBsukv
E/ZGr7K5s6S95o3tMdZUGrSHWnXF6qamSzOSeDC4kDYQd4hDSv3x7/7HXK42pmj849/9T1kU8x7B
PDoWg5ybMIGRL07ouMmjVa9nNzCSvPb5bb9EiTLDjwxzVvMFi8qwleyykCr9aHNk7pOT6gnN7Xxl
95xpkxmDRzIG6y7Hw0ODFNx9CCeqo1n0HbIkb+09tGL1IdnY7lXCrHqItFryzrjmF1Psprszibng
OtyXGaAqU9QYA5hES/3EksOsOV1SEj9LB5uE91c2fVfX5OeqpAtNhonTY3AMc8YrI8o1n2MXHIqt
2YplO0vXFLbZWNVsvt3kURKXrzuC3FzQ0k1SqCL4dW7jEDJrTdcH98H1sMNgdamf7N2Jj/h7rhnf
C8MVrd8ULObNe+FY4wcUg9TGaORttLK4hsVUr4msTOxr69S11SWAo1LQKsUs2vxloa8og0GmOvyZ
5RIJVspuq8m9k0pEoWFmn/NmYpnzPg7Nojy5ZpKHNSHXNTjakgVo2iR0rwWIuwcjnh15KwrC6Y71
pegOaWYy/jI3FT644s3KfyuOk22oAsFsfD8DvBE328LlPxJrYdxBtVJu5yw3jbHevWkm2ylbSpL3
CRdVcrb4k1d7cjdggbpnzMwTiRspR9jXPok/Y47JsVCUq0M60GeOf02prIE6ifz9IAYaS9LDNsJB
zT08wPdlXq5nwYgNWzDQ5rAoyXKlyqbA724OmCHLM3VUlHpwIpEdKGsu0i5nfAuyTcjelVPjH+8e
iQhGh/O7mNK6LjJjSYuHQ1DIolfSU6klUorT9iS2i4lMj2R6pd1ZUSNeSRAzwkupY6mXpc5NtFFk
r4hCsp/geW8sZU6ZN98+YCzEf2WfTYTVu3R+nskELaB0dOabca5kJx+yfAivGC659SgVjZDtjHKs
w4y62pRgv4rdZDERPvbR6hSrOuSoMwAxGEfDFZGQkEtcD5cBTkcmfzfd5FBIabpf4zz3Pc192jOR
QYgKQfociFS5aEZTftPtaX25aSb7yiLeEmaZ4F2+2bzhWt8GMHUZBZOav5RZ12l7KX6NmFA1qgna
gfRUbyuTbYJBegEQE2fk6EkUOS74j0Pu+ggsfianZ6aEeggyJapSJEslG7+3OLpZ4Z7CdiMGK74j
2zPN2+i4ikvD25t1Nr+ormzyUzWB8/l1cNLVss9BMDRMdGfBXiItgos5vp7a2bI4V7LGtbkHwBHp
55L6vjYZM5tlKprT3uM/mJZlx9Phi6twfbHI7bpnbf7vV91kbgzqP6CuuRWk4VSV9Z7EZpA+ZPSF
kES9q0pu9EnjHCWGcWSDG2cm3CS2ZHT8UqCl88TBZHNOTqqHJi7/oWbz+jn/48/5H39Q/sd2GPyc
//HP4d93M7nQOKo+33669XJ3q3Yy+BPnf6xDhObzPzbq4erP+R//FP+eTqaXcmoVWewqcEEGYRWZ
JmDGve4hcBQJxj/HITOEjR7jYrbXW1vPNvc2vc9fPPlCz+VJ6MoQwf6TGULqcBcYskjOp3H34cMj
3GV0eoBQthOcYIgiegIewgP43Uyua/GwTvek2dh4VaJBbWVlB+cAYwWo93gNEGQv19LixpxZX29f
O0AOfMR1MiEE2uSdSZKKG79hHK3gYsbhIYziuVyF2uNeUzQ7GSJbxIApr88QTMBM2z25uAZARjgS
TQsWPRlIgoJYKiFUpotNt/teFqWYuz8GF7k65+SUgYPwAg3l1nNcbI8lEj4ZonK1hRs1sJ6H9/oY
cfgS0wIYbnPjQQ4XtIhVFxditSIU0JRDA4sCOjc47Uf/HFh42rkVJ6yhZwfoIWiP/XsUOuHRHKRu
jFM6y+AQqtsB6dNL7IawEj/KHjmwSfgLASO2PX4Tog/ncYbb0NwlogjIH0CcYVS4dimWLOVo/gQn
TjylyDwWvIEaeMxeHgAaxJPD+TmH2nAO8lxhzQXWQb0hGWpGphkr+8RyU9TKyt4X27ve7qvP9r7e
3Nny8PfrnVdfbT/beuY9+a2398UWHM2vf7uz/fkXe7KG2NrZ9eB3prN+b2f7yZd7r/CihH3I7d0S
P6xsvvytt/UbnJPY3fVe7XjbL14/3wYwQIdhvLe9hSXI9sunz798tv3yc98DAO/lqz3v+fYL3Gr6
DIeHfGnUVFtJq3mvPvNebO08/QKPm0+2n2/v/VYQ+Wx77yXb+gyNbfKgyd720y+f47TJ6y93sEW6
5aFbK8+2d58+39yG+xS3Zr1Ei97WV1sv97zdLzafP09H6ckWENl88nxLob38LSruwEAmyulfT0Ed
4PDcZ0UshPHH1m+2gPDmzm999hm02d369ZcohI84CfVi8/Ot3ZXyDd0G3XHp5tYL4oW+7n75ZHdv
e+9LeHs/f/XqmRBzF/cmQKftrq88f7UrFPlyd8v3iLs0DBAgx+46/37y5e62EEauW9j58rXsVmIM
v0bXgeMmqj6TEYP1z0ED2V/t/JZASQMhsO99/cUW3u+QaDLimyTBLkb+6Z5bDO2BEfacPnovtz5/
vv351sunW/z6ilC+3t7dqmA8tndZYFub/XoTbX4pXebAAyv9c3t3xXKlL6PlbX/mbT7DzhrQNoUx
vrvbhheEZE+/MOSu/Wzq/dn++5ex/msurv/Cn9d/f5L1X6dw/ddaWw1/lgp/Rus/bs//4p8x//9q
q1U8/4Nmo9lu5fP/B63g5/Xfn+Ifrq/z9mCE68IMK4ODGVcWskhAKC6t61O5UoyWeqOKFQFXZE92
n9nvXrn3vsft+XO+xVVdAhFOTcZzjsVmR+hyuhRAniTs1Pt0jY5ouD86MgvMv7TrRNzp85gXmVYF
1OsREwxygYM4GeQ/wUWEE11rvdE1pt5k1OeJk6PoXZkLUKw/E2BmITqcpMvPhxW5J/X2S98fsdRl
Q4WLXb2B8CdY8QLKT7norVbv/PhlL4H82JVvMSLff/H743Gx61+F9JMsgbVzt1oFG/x/ioWw6cBP
shZW/v2pF8ScLT/pmhgAf6JlMSDdcmVM/1jB8lgA/GQrZED7SRfJch3qT7dOBrifcKmc6exPsVoG
wB+1YJYLZ71XiDZjEqLzyew9cyvKy43cvxWrYrHFipOuc6pGbLVyv32eKF5I7Tg+PaHcOYcIG/Fw
36XHm5ylEIugkUE3UYtBzXuG6+gwH8e8vHsWi+iP+oiUOUM4DMXZCSV1eUPsOx5j00uxDSQLZEus
P4nUsq82ZzPetqiHFET1IX8wc7FGeiKetwyarI+eUXFS73PbrQ4FITQoBJaIPygnXNLHOLOTXvw+
zsFk/xBHgCDpSwtpR09wGZtEYNAKmLvlpCzjRoSuNFhEoJ9S9p0gPwIFIAItNB0iUlVKq2Oo5xgb
rzMRu4NI903RkRUzol9EIwi55J7aeOmIyoevI43xVRRjJoU5zgOwF9v3LnyM1caJOTTjn5izNPZm
XOa38JEGX0voo/yJd6bMwSUOTcanBz4U3oZexlnTd/o3P5k/UcJUOuJbuVjVp8bszW3NI6e4fjcP
WsxU1+uaGR7t3N68Ynt1MZntA9P3pwz1/nCFwIKVO6DLE95AjFizQ44ZyliqiAkCil2aJJXzIWDi
+OhsgnFCjKZl5LgmYL6OJBAGJRlS3PPCVvsC/3mmRcEIxiCtpLlcnCnRS9CEnEY9xtpLEYGFjEHz
Yxg40GlAaF247ngy12tPwTxy+WZPI7SYYF0gaQumOWtvERqCBE6HJBb0sqQ6PxjOz4fUulNOAapl
9BpxFNFszIEbzo1lPYxM33YhLpjNL8FS6CRKHGETl7w6Bu+mE02CjIaIcKbjcmusbR+5x/TWekDP
XbUco6V9AC/3/IPKyp079l5THmGRe2ntK2CJaHe8CvBK2+9JhCwQO5A/OLx37qDhcg85V0K5ob58
oH/KRaD4eieBbP54YADzI2/oxC8eGNSELj2cFAuJ1Z2D5N1B+s5iZP6474UrFog55amNrMhLIezm
6Jz8dWBY0PLMEmZZ93pnk+GAMukSsEZDxvRwgbEwoCAs5edwo847KJQUhpRyHADcf0dKfOuWuIOP
b759x1g7OwxD/9tK0ot0AiHUljSDErmTuzQbwe97ky+iiz25Hu3Dyp03OGP2bqPE1XPJf1MKzEPA
h1AfAvnSMA/4wlpNeQy0Vss8SK22PmitVfNganX4GJi21syD1Orpg9Y6MA+mVl8eTVsD8yC1In3Q
WofmgbWu8peE244jj4eTVielxZvBO7kPVtZR8pmTxCwPuCjAYsva6VAOYmXLPdHeRWqX67k9fP5m
gCtD5vE3tTwaCrB84WuBip1hDONUWVku3bso+RcV3s4LDKnjj6OLlTssQTGLfCMlpNwp+RZ9KYki
LAnw2ZK/qz8o+TjK4ImgYcwltZ/E2dXjlZTxp2XwgUEK5wruxnIpc6ysw5mgyWjzKknMAAR+7c8v
pziDdzjZn0/2RWFflHVXlx+NJN5nAXZR79Al1IFMK8x7LI3fQyehxxIWxkOfVX0/zr5HJ0lpbYPT
zyaD9y586nKUtIGEEzuGc1VGXpmJSb3glxVIRNgQPF65oS0QU/D+huCxMGhMt2d6tW+bK+uzr9B9
NI6x1HdvLt69uXynkibmIbkNwpY2Qsq/aqhkVSthlxZH0L2dBbZgdW380H+J3fEZj6jSUKQ9Q/Ly
kDoP+AvxDC4w/TwSr2J5/9c7nm6+73HNpzSnM0VAssBwDEWrZl9ZBozok0N1dVnxpRR1H+LX0PCC
NSg9F3BlPfRPRSaVDQMgtebpiSGQGAOH5N3h2HIIjoQyVYCgXVvJTeyEmnw4gtaDblMm+Qa/vxGf
zm5ktXZou821bI22hOjVGHdI0JEkwAIfxThQTam8R4yGyDtpbleBUT7qTY/Nk+OKWeA2OLv2CbEM
RMBT0JB6lT3ZrPS7N/Xq2rsHuMbeKkkzhaFnzYXy+dKb1X/lfXLv3v3aw+6DalHVUKumL5qqNu5g
GYHo8LK5Snoc8TwMFhPICTFQiQLPVJ83xzM1IAYpSgTKeDiyogO+sZ7ecEIiGr5RW7ha8C9Z4fRt
LWYhtwb+gEGN6lbpIoVZ+S3jSz+8VEEM8MJvnHZXmH76cZx8tBMHH+97nbdvxXOnjY0XIbBdHnSb
RfQGDSiEmg4rY5LQScYETNbdY1KDKB/5Zib05pJhEssXczEEVjSsELT9RVFlZ5uFqKsu+gdhbR5P
Bt43ZA5tp1z5psLpp0smPXEufjiHbicQmUOc31T0xaF1wnvvk45SltOgtALSXgXkNciv0+Ne8gLJ
7sQvhSQZ6pbVS+jVMWWAGwKYuVIIN6jnAQeYODoTul4Hp4x642+HeNtIR0dpI/ZcOkvQO979OVSZ
pbKE1pusar1PPnn7ZHj0dqSV3h7iJOKHsmGIuw6TVDGmVfM+M3xXuGzTvC8g1NXVh0ydhR5fXXmC
wEwQ+OSTFYezoXi4wByLLw3S5SQdPBnPLB85stVlET8ZA5dvcmUzgGpYSYmcn/feR+qqE1mJO5mE
Jc5JaDvRzCIhkeaWqeCsnpi6nB10l4pg7iV9Yf9U2mYmcblgGooyoThJtUxQbdbVt1CsD2IPJbzy
8xe//qJSs43walbj+LQa0zdLnHPzvu+IIIdgoDeIMVbvJWW7rwI/9larQWAlc1IZhvnKHeRLDdZ8
uD45g/GzwZ/e2pWPD40mH8KO/Ay1kHzARXN4aMpnU0g/dOp8aMurptRr4ANbCery2JFW2gKsKXWC
Bl+Zz6v6uS4fWvIhFGAd+dzWGmt8FbTkZ1BXsNoK7oHiy4781L/rAixcZelQOmlqhiE/NAR+qK8E
/aApNRqrfAjX5Gdd63W0laaQpCE9D5umJus02wE/tEmeUP4O1lb5oRWSrs1APqzJz7AhHzokfrPF
z41QPrQa2kq7uYrHVn1VQPJn2JE6qyEht9pSZ00+B/pBILdDvmo2+XejGfBDR3Bpt6WtjnzotLSV
NaHSasBetAL+3ayTyqAb+7wqpGy1OwIylA9C/k6bhGlLvWa7yQ+B0HhNXrXbCrAprQQhB5YLJWmL
wFqNDusIlYO6MMSqDEJrTZpvsskgEEp3hDnaodRoNQJ+WGPvO6var0BbacunUGi1RkHsrdbZ/2C1
gT6jLdZZk/6vNlv80GniVdAkPwcIteeHNZIyWJNXraa0JcPWaSrFwjobNW0FgsCatBLiLmu8WuUo
4pZ2+dCWDw2SMuiQuuhQW5BgJ8MmWSgQigUN9j6ot5RiWJezztoa6zRDoZ4QJlyt41UY8GfQkp+B
jEso8ENhcXCqtCUsDn7Dq1DYNWgLWAzHFReVIhAdM1IWRUwiYyWYmpRycYpKOTj3sRxM7Nz9qL8v
EuobSlAakFRh1lgwqi6x+0XQQUEFfug3/GZFt6gO1O0gTsysES21amYXj+fIWbHpd4pMTLsoi/pS
Czlzxj5r+Yu4JqtU+blvYPOXmqfyvAFVauzKTLFGapiacp3Ccjmj023rEWFXVlZS3xK2LnWt6gtU
fdO3BSDD5RQZpp6/5nd8mQahDwbHWAd1mS0+BDefQubLNfWwZLDjuOGtrdHClSy3POEVcZvZUN8k
vxW7p2e0zBlT+ySAeheWduK7yhOUq8DAaXV0Bq/qxehMRoyUGB4W1aK6L3j9mGfvlnx75AyLNFSI
Dz+a9os+yriIUjavNlycxTfFr4Z2G4F/N1GZ6rgSe3ojUaRvTMl3byzAd7TInZIH6oZoesb+yJrc
xnFox+oRpnrqMjQ+DHEyI2PJm5SP3onXUHkxrYtDK8V1wxvrgrbLGm4sVlZ3pWXXtJNaz/TJnRIc
VpEJIIIxl6WhfuLdTIDd9xrwmCA3i4NmFlSYgHLN7+XwQsILlsNrJPDUeF8OKQCkTgLo+nIw+x1a
odE+uXukclHJnB0AZ8omJe5k5rH5y3zJTEyH/ZM27xzApH2fIiE/XcGUAn+00az7pWdcHswnE9CH
RrMm4RRutYtdxLHYdXFa2XeFROJmM6ql5y6eYLLWdZ8riHVBORz3R6dYRBcsuqRpY/Bb+5g01qAM
630QMePyAd6EdhlGWexLe9/2eAdhTOlcqELMQpSuBtsrtpWoi+G1WmJ4vXIYFuiEoVUFP1LQ2ym3
RIjkRcjw3cp1ciMvNYqKu6IiLyhseXzKeFy8UkpkPwHFXDuy9DLeJ/piDJmMkpb0fsbRfJeDk/ia
DReiROqd2VbGKTRRjH/sGw7ONxoLZGJRTPDLOTyjScAI+gvvaMx9uNSzIuOaW5fi3CoW5HB3xqai
MaZcB5y3zaQ4TIMuTkOBZ6HzlaSlcl2R4igH144i6/YwnO/L1hgWvshE+emcx2c5iWq3sIlE2O0f
DBUxh9sXaZVl/FRUpqxvBj/nU8M4yiF+BgHpSHLfSZxqpGeq+2Lv1V8nDktFKG9BaXuGkzJfci5F
h1kcX7OVhQuvDIC8wSislTZzrd0opNs3A7yxTHikwFJetd8SQhvGdhpuVlw0Mm0tONrD7kKUwnXO
cXXXkPHjSOIzPNkQTKW8RGMxNJBOYZNb1PEMi5vY8QA7Etf1AJv9fxuq0T+eGC+3jbfAJmntfQ2t
CHHshJHskhKyIH4Zx4dP19il5/rdrTcnWZckfbx//6WidP9+1zqHZlFkhKTgmXb2hG1DUlJnm9qb
Tq9SEOcTd5oXAQlcIE+EEkl1escmqDp3aw4lCLSj1cz07cX94XB+MFLfDD0xVai2H/ofzZn6RT2o
4schdoB/BKgUXFAHuADg6LdxPzew7G50Fqs11phfQf/meroJ1cxlt4ILCS4EOE98L/Ry0D1BrwKd
AVzec1XOBTjXzb54nZZj1yC4huksfUOBuAR8cWzJOpurc66BV7kk98X5xcBW+lTo46KjRlxCAq5J
cE2A46Keq3D6VuiTCNeY3wD/sYOoRt8BF9h0NCzHrkVwrUNNW5q1j67fmJUpllUoslMlSziJIx6O
dXYaNsdGyYJKUL4zomTfQDUyVItqiYNTxiSZfXvZ2FcLSyQkLGVnf5/RCrI1iy9Df/ggNBL/bo8i
niT1qXUbMqHFMKbwAZ1W5X1QF5M0bfTNXffpQfBuw8hHpCMRjytyJvuEzhUCk3IZ6W+kqxuIU3Yh
VYpM0mtInhFtt6G7bNUmpEemF3sdu6fXscce9q1ABV4dWRBQS9mCzbVPzLbWDUMnUuKmgTM263ie
+Bm4MxEWjGh43YjKmgmq+24vXXbJyjZAQSuu3jDUqsxqPR/GaqUiS8SDcEmR0A9NkaEkWAOs+/CB
Mhwm1KXKNRyRGoOo7Ouazq7EFFy2yV7l3feE2a5kFko/iLfsHn3CXnww77iJnsZqU6PJ2uZra9IZ
s+/Lvc+qHRZk/I1EHau+hvnYl5MGjIZkZGRktCEuW+uNx7Kp2Z8cjbFRHBsgurklF1TH1DtmH2J0
eQOjGaJ8PxGh3JSh99ChsPIBuavidyr/zDROt8OVzMW9pcUjKBlbzVm/BbnN5etkaG7pF15b1Z3D
uYrNaytmxqRonZW3wr1LZuxzQqcYHGoNMTeC1m6C4erh06NjMQGtAXZCKyZmemouNlaMGyu/XSj8
bAaAF+sxm6/dzizYMMvvXuVHh7E2uJ1Mh2fBcJZbVSxX9qeyn3WjR85IwoR7CeQq+3pfF5yyrZqA
55YiY4GmkrOJad6bvrRZdWop52TKMjLQDKYVPaZxyZW/kYQqubUqSWmDi/PwIAPfzB606hS5B5vy
bzfShq1bVm9ooUuimit+I3am8vWImUIGJ3rmBoxCYmwbY900KImxeBKPZy7+U17zXGIn28f7FBV0
LJQXSU0nnAkpk7CYwSSKKTsRLQJta+MRAz8PTGRTcWeHDNbUOa/xUwnmgJUinpVYRlZlpJSzPmt0
vVezox5l8feLGf9RgVDiqZDmjAg00eLJ/ObTQNKt92ZQAt5nEpHbo8xQ50Or+gXUEGNTkOVWbp+I
fWeNxuWQvjWLMDWEsAZKJ7fEh4XFXYxln1whxhGPGim4FFJYAKnv1E0Wmd/SEjPLPBvfZE7vaHyT
Kj9RrNnAeu2AJ2Hxo0ONVdD630R9/fiNRSi2EQaHk3Sl+ex0ZkUorMVYjiiJHycJSjZjIJf5mt74
6rox2/gmPMHstBXTypicGso/PuMNmLHxH40ucdvqUDyAZ0ONAPiM4W49zoNj7wDRsyYYAGvwie64
qNGZelfFJdCtKNPevXsXGha8sYt71k6oIXMoSamXUl+jJoTMI54mw+Lj9Ag/mEXVivZ89VruXMBo
cvSwR0EwOTKhCtQt9vQg8LuEzQIlFo3lDCH13Dx+OIsfHh1ihxThwVCkWr02HRzaRTSN9321BRkS
zPz7ME64nta4A4kY8E3Ig+x/c7da95q5sMOuPBeOsmvKJWFddo9bvgmV4CKXkQord3AyV3bvZQ/Y
1/iBgCvLkGtBHJvkmlMiKuSHxjNI0IBv4iPWZJdX9nJXiSEXy9h09030A9fUHrfVg6ZumstmOVer
oewoy044m5OVLL+2BEPZ4q4Tw6bERwjuGskgO/y+hmoEsokv9TqyxdySrWU+tmTjm2titiTxA4gu
AEAJiGDUgYRhBBK5IJEK8sg4jYD9DmVrWvCX7fOGhAsQtKy2iQIiHQBQdspDWaZ3CJXxDqGs1FdX
Zava1+iMUJbgXJ4HEvkgm+2yzc2lfSiL84A0DFbFa8DKEqERSISEBCUQOQ03aUiEBklKCHUZLX5l
OAYiAXwN+QjADRwUiTKQHXUW5FCEDaEAS2uYBv8K5IOMKL+2JExD/BDCRbLLzy57Gg0igQAyjrLz
z3EUj4SEaayuyTa+xJlIjINvAlok+IM+FE+qoU8AKKSS8Al6WDwhi0RgyDhKJMuqOECky6sSNECi
EWHxjHT4gwOFYAUOCrGReAZP+rjWkTAJItKQEAsOioQbCNbSyJqEPZA+/Eo8wpYMGQclJJtqtMSq
RFYIH65JKAThs3vyKHEXZMEwFAaV0AsiLMElbZmJdaFhS6JjJKyE1OVf0nlxFkkQikxozqNAQyOk
yxK8If4kYSUSpEPhEEgMioy/zD9xCJHOYVNmmJBBUGfDMqtlzqyK/OBXkQt0UdGxRLYRz5UEcAju
4okSgMJFpA15JySskHwSct6G5L5A5ICEsEjgFWoAoEwuiaSRucDOhw3hVWF2KS3MKPwkYysYSlyL
yCKRfyIR6gz/SHwE+yIzXXkZkm5cU5qFpwkIkLrSkISAhWYMZC4Jl4iok2nqaZc6BiuZZDJjhAMo
hkF0GTsRhxqBFJpRVHqLMA4T2SbiSWZfvW5luJBDo9ZEPDWsABKhJEJDB0KlUMNKUX4VesicE3mk
/kAVVGuqCgBQhKzINgnskagoIidsIXJS5bzMPm/NCDiZkTK/ZKYpn3miM0RwNRLWr4eGK0UhUCaq
MFPdImJmdc0oq8AEdVkx1mrKXO0Y/aAyS0KahDdkznXW7GwUBSAaTKROIzCzwxP5IOJCp5YIG5Uh
DcP1yseCl+gHiUoT8aTKpGn4kQJOlYnwO7UAAKqmaFn1pJooMJNM59Jqx2g1ESkyq1QeSXd0wq7q
7AYNRf2thWYGiZJT9S38JRKt3jCqM1S37qoROCKbNd5PBYIAFMEijJGoeBXLoibDRI+ICmkaXWMU
bSPRdCpeW0JDmZdrVlEps3TMXFWLotk0ZoVoCpE6IvREsqZ6lkKIk79t1aRIUVXkoVXfYrGoKVM3
Il4EnM57wUO6KEKuIcZQ06pJlRIiDlW9No0uE7GsyooyRFWbSBihv5gHzbbKGtIwMIpQ9I9ookAR
sUpIpJzaPI1Ew3dWjXLUsNC1uspAdnlNrQ4j9ESSi6SVPnYCIyJFlBrnfcvIWLHCZK9AtBPVKS2D
ptF3KjYbIkADIyLF1lOrT5SjVG4YHWtCW1UCtzR0Ljk4oV4SLgNSi9wcZOZxR5r2uryJxSe3anYm
Gou7ETL8oe5AiJLtaOhCo17zvjKRH2g4OcDx3cysiXSBI4jgvqQjeloQ6oB9NixwsHdnEiDYTfeg
4i53uNBTdzRPM3kXvwvu/z//ze/CAAvji9+F93u/g4zizdz21Kzt2b7TXd2verP6TgIYwsTokYkk
zC+TRgS6zuM64xzfBHWt0bQTSWSFCiMJDZVgUeEsmVzCr8JFcHAohIZCEKUtZqUayFaWq96pt42h
oEpbrIXVRMqKbZEAbAlA0TYqT7yWkQEKv5HIPv0RGDktJq9Md9X1Mv9ESdnOthWyjnLL6hWVtNaU
NFZXYFcNgmXbElSmskhf7VdYd8Ar9UU1iOQW2SnKSu0t6Yz2wxrZxsxtGI3ryGL5kL6zbXS0DTH7
19pGiSmFqKZUdjU7hrIyudWWTUdTjONO0y4ZWh27XpKZahoKlTECXVclyiGwlm2gQa1rRs6Z1UFg
JLauPqTx0FJDuUgIIQpVhEjg8GIYSpMqEURaipiWRYvit2blgGhusfzUCGlam0TVdyJzhcQNu8gy
5uSqkeGqkG3jzXTqhCJjhboiHBuJQPPqVu6KtBD7PUyXkAkjidaSNYma6oFdlwbW0FDFo62tOWi0
zWyq2znUtJpRsWpam8XsqIaJ/A3sOlHUqMbAdyy6uhRuGYqrdhG+FzXthVaFyaxYdRguNAwnWkiM
64bRiWbpq6ZAK1kUrVqEhG1D27ieDAhT5btq7XnhsCBZvtcTdpSZUrdDa5aeznRuGBaVamuhsYVE
5IlKDRPJoKqrYW1dsWZ13KSr0hll4NAMvOFsa2+ps0AMLKGaMLAunK0Q04EiPCre+tXVih5byex2
pjF4xnffuX9hzs0YZSBnSi9YQj328YJbHi4x6JH5frIBQ2e0eFfLGZ/8SXzkbhBtcHtIHGJ03Yof
FiV0ayjZ3eX+IMv4uACoyjuX4LWnf9Yf8q+KH+Y2jABhcWdIOyKhhVRt9U/jbIRJxAxBUZLXaJzu
+K7I0bOiDeFE6Tk6vijkqkg57vcG9FLiBiT0ktFEqTNQzvrE8/3oYgp9PZ4nxDuapksyLMg26lfp
Gft8JU/iaTOASTylsQWkhK5noqWOphK8tIjxmzy8d+kgLjT1YKGp2yCI+4+IJJE6mmrMoDOuFlQy
uDx/+qmaKcfRNQ5G16e6yLnW/7sv1fbTasp0eSRTVp7KJgtPhSuPb2yUlPdLSTQ6aXnz1DBbfRlI
wq9ZQLofUrS7Z0/Vfzl+j+OcY4EkFiardL17cclPgVcWQin3kSorRjI47nChV/bLwohtZAo/KGSw
PK+m1LLO1yvZB+ojDGzOM58KLD4eHs7VHpWbmcumcc+ZBJbZXCRUZAjsIg4b2n2cE4edLJyC8stA
Z+aJeVfXdysm9ccCtMcbiwTKTAkTJPijpYNG17zQgNDLQqnEUxwq5/qT6BCJyobROJkumgDOEWEK
MNk/yQ9FupViSWXqYmXBfiVJERQOQ1gnxfIy2YgEaG62WZ/TmyUj+u6dOYYx3Mh/uo0A9KtBmpKF
Tf6tuLTSqPqsXCy7jw9YocLdwFYrE+efrQNwubj6Jfgukc9+PUWyCLKmbVlGA6eyy7hO0pRkG+SN
A/3duzdJ8XcJ3gXZND6Nl7d9LbET8BsbzmmSPIyNYTXI0LbgnIIGHuVrPlqgpehwqe+lUTt2L9nI
IZOaiAtgEyt7M2FR+c1dQkgEi+lZVlfhVxp+fpc7aJolzN0ETLbNGLNjcohlNwj16B1U2fHp+L3d
8zPZjGKZoOPsvqbEDNmNSjF0EEhvTBtfIk5lS9E5j1zTnGDWCcCyl1oxrZfU4VE9bcEcw9PKaSXu
AfMEO3eID4fRaGB2iCfY9UeGEXNEIxv6AdsKaaY0q+RhksPRiYNTN4lss4qDIjXYkrPOpojaAnIj
fGFsibH4pLRvA1bMXrPCMyByuRISCMZDcjxMA2MQVMOMVOMk2j4hvx6l5llqnjVum7DSKy//74qr
By2GUrTdm1fyLvcvLQJ7vr28iMcyXBV18m1dyTFSgxFdWVzSNK/FCKW4YOtcgxGL8EDKdRihDA+o
NK/FiOtLOoRXr8UIpQitsay50P+AZSxXlGvLi3hSpkGsr8FIXEJYyeGYzVKM0ByWYFxIXtMci4TX
Id3kqLVuHjX6HLgaBaTrMIJHDCtdnAe6hkb4zgavfH2UAbJ9sDRqyDmjwCmjA20xCuUcuS8e8LXl
GDXBJA2f6+zOcgKwCGbIcqRJo6ZgfQ0fESM6YuCuum7U2Nyaz8XydaOGUaWzRmjUdEiWQgGN1oSP
Gle+Toa6H+hAOxiJSwUeriC8ftTAR52U3PCbEHhw5SIN8E4RrOqDXBEvRSEt01rACI5TurWD1nKM
GmDbjt9op83BeQTPRRajRtseRNPHVU49PGZo1BbGCZ0yyp3FfOSbF+AXOq5cen/Ai6ZD7qww+MDd
tJSPTP8hnuoJW0kRh4+SMiqeEoyanP0YNWwoXMdHQAHyAbMbhNTOoUKLFHeR5uwPTWt8xJH1hrSW
UDpLo84SGslGxFqY9k38d2uNbO9uM2oYfhJFyEiSrfpgUYeMq6SRcH+CdUKyDI04J+qr18qjjoOC
jlrC6E6RZJhMay3BKOlXkJdHzSJ51CBnA0ki2jKNOazu8lHTb9rmWnhs+c1Mc0GWs1uLnE0XZmbU
WkWj1pLkGD6ZOem+eO86GQK4KBiM2n4zdAcW77BBSS0iPVvFI2jUcvq1gNHqMozoUoSU1FLEiH7M
tTW3OdSF37BpJwkoC4d2s+2wLYh841wjZxOGGQ+gQtYzo5HRay3lo6bpPjcsRNGlzdUdFMzsB8lW
3YkUZOYaEVyYa2GWszGkBZxNBDipw7rDR5zWYWZqr2XlUXNRHhG8O/uDW2C0VoSRcDZ5v5HOSDra
A63myOwEBTnn9AGbCs1WDqNkupu51hEEG06/MnotaBfptcatRo3FaI2Y5sgAEPJNt7kgx9mtAs5u
ZWU2eaFYZvNt0HZpRHHgMgkJkEVhQffnR629OGq05VNWTqQoW2plZbbo8MBAWiVGIGUQ5jDKTq5F
a2Q1QyOOSJ5GDdG0drovs4+aGUY2o9aiwAhzEjKZXHJG7gO2HJuZ6RhkMWoWjFo7N/ubRbO/TZKs
6iC1klGjdOy4GLUz8kgwysuj4GYa1XOjFhaNWoejBnLU2+kccRSdo7RcGjUWaZQbtTBcxCgMbyEh
ye7OZDe6n/PBSImEJzMSsrkoIcPOjZzdaORo1FxGo5RtDI1aZL1Gtnc3aRExDxq+VpMAh5Rkru53
aMROLPJRI8dHSrQFPmpkMAqLMGpmRq0RLNG0DkYss4jRasb4sLM/QdHSKMjSaLUAoyBDo8ZqAY3W
cjRqF2HUytlHSqO8fSR85HB2vWD2Z2V2WCCzw5zuZ5lFzl6w2BqFFluY4exwbZGzm2FWiwS3wKiI
j4LVDEauEL3jFZsiwkQ5dFjEZaIipZYbskbrZnSWmbQZeegrT+Wn/lpWPK7dzNbN9q2GrH0bjApo
1GzeaNK28mo2KBBGQZhXaqtFSo3FHLbmDMmzdWPtRqWWF9jNYJlSczEKmoVqtp3BqFGgZpvtLEb1
RYy8HEbt5jI+uoXAzqqQoECFNNduxChs3oKPvGYOo6BThFHQyGDUCAsw6tw4as0cjQhmAaOwfitT
pFnPjJoI7PyoNW5U/EE9N2qrRaO2lkHAzjValGsurKwpQm20wNk5pVbE2XmMspxt4hv3TLpxjaWw
6eLqNpNLkqYVZ+8kqbg5VMRjZHOb01y2Kbb0bFnXc/Kq0Vc8NkkB7DFTpgIc8GhaDzvEM7NT4u6j
+BkIYSZHCPYdVk2OgbnJNjKwjno9BjjQQ591ST/g/r9e9P9G0f+bRf8vLJkHaEmaHpviVj7CEXQn
RHZ6giR3EDZ4urI14gaX2OOt+0l3ygktJAF9JmWS/YKj9dzBWnUKSJCPbPH/LnRe28ZwtJSnKMfM
QHM6kiOYiG8CkBDACLyKScXDAa9tsvpN2cPmeWPP1EVpXCLBsTMvnHb0CGsPp8bGrGKbY0zCwsvk
KK/UT87XLlZOjtqynD1+GrbSHa2kSgajO9d0eumnBwR83ysvQ+Z3IUlkxoS4MGUTYpvmTCCjG1cZ
2iA5TP906ua1zuNqc03NcZsJt9wZOfHD8a8uRx3fQoZdITUHwZs7JO4YjpFf1aWA7Rilyb3azphk
YbSVIWUDuOBzI8i0b+O9kguA5PKDhwgJ01dAQN4wpQB3Le1+bCJ5TPR09mRrciRXnhZiiXRzzw2V
1vgJ3pGnRzC/uW7r5BvlPdlsfNN696b5zmYPiXrYAE1yVyeHafVMpHuKNk2LnS8UukdKi0o0Ggwy
YJYO9+yshGuMJfW5JmnN12IC8SDM1pIjr5KNyHsiu6+83yHwvGch/mt4jA3Hc5AvFbJUiP8a+K+p
pcIwXwpHpJ+FKBE28V9LSwH3Z41mvmQTJRst/NfGf6taEllDnjXbaWp1EFWSmaa766Nhmh/cuWuD
uPnEz2fzPiHzL77iE80aNmQa4QPf4AZgTy8s45WERxNzEldIt+T0bqJJNQ+FbjL3xqLr3JyIn5qk
iJ96ZQF313wDZyMGEsfS65oifHMkNyfxaiOTEysL0tzmc5jfyS7YJJfMutTqcsdCYWZxc8BgMTeD
BjGkURg4hzvYdwLs+kszNlwf/mYyIZ5M3XuDGMKlsaMaZjI/mWZyivATXkg+ERNAIqU37Pl8VKik
iQlMjkCRNKafGojh5r9IstPZLsrJbSoVO1ScO/Z4nGYX0JwGuHFkGB/zIlObWMIGCdh4gYL8FCuO
apaMF1JSgwd9fWtq67sk96MtGmfy/gAHhJa58QnJJ5wG0Qi3hLJa6KHJA1SEAUmtmIf3h++QFdKW
y+CEmZoth7CZamGPzLjuo/W0vMaD6gin3Xpz1+miicRJwoSlMzZGuCxPDwobrNzXnK0Je+1rss0b
QkIXUXjnL/Y7B1kuyVHmlV5ekMa2Se3eHVPuzV1bwfTMprvS0rh6x++4KWSzw/rmbm6YDZCU6fc1
TcydOzroy+njZjwyF8zZCxb1fgmjCr828dImjWCSmtI532QTRYwNd1LIRb0TuaEtFnHclRYOAsyj
gGsK3tOH1E+Zx/JBI/MMQVxJq4XMGJFWSx+1WvqcrdaYOe/tfDCiTPPMZGYKUtqK5nku9nQ9m+nI
4crBJFcUT2XnTaY05FTFS4JTpwotU7iT5qAubEyuiXORfnM324fcLEnaxXTB//F5tbIw3rtUaGxy
66lN7XHn2v7nWO8WNMgx7w+hw0Kj34cWC+0voUcut0sG3mKKF1glP9Htnhs/2b/0hnBE3Mk8FZun
4JaiJF1MmnxTlqcTXi8pVWFX7EcnSMCzb28pk0vS7C1TtMLZOTUyTAka2BrzeIi7zwEJ950h2cyA
MqOXcyfoXWlyRBJXl0mCECcZqQEo1OxR4wrUAa4nHFOBiqZD7KG5AS2N5+MlXvYCMgRtw7qZDi+Q
+xV90yvS0CB0fW0lQwPn9m9NlyP5fNlfrg+M4ZiapXUwlsQFjuUeL+TZ8pOP1VB0obnv7QQjz2jo
S7ueSwt6pmD/poLVwIUo6i8FErhAbMSpvW/eDiXJY8YyMWbsBXC844nLzvGRLDvFvnHXqGrIaoaY
12kdi2bMD4UJvEzZfY5HZtEYlyGa9i8qK1mnxF15qwmkRvyCmYIbRfHz9wxqzRjxwk+pIeMIjG/T
xzsCENNdL5ushuk7s9ak+VD0Ge+cEunnVFKQF2c9zaaTdDBZs5dx7RyzQiUIripGXHdhHS9reNuW
5OXeCJPn1dyzWFPZ51U+p+D0Sne3azkQduFd/FrPT2QbyX5y2juYzOeTk4UeZMpnO7PsU0rjdsFr
eXUbSg+Z+NChdCPLCuYxR3nTVvjgW5DkQajt58mZJcW3YqRmS2eJYYEKx6TdrtpuJ8zjxox7exl/
kM4mI5XmuU9lSMFKElw96HGpIbm80jvZuDLBsRKsg8dzd4anQEA73KeKDEuj05Oxt1qYe08bttM1
N1vZILLWjTZW/TVLdjz6On2rZu4lg8nikmTtXshzARQvVbk9Mh1yKaLLuqJSCyTbzPvILNWUbL3F
z8l1M+Jjzl696fiVY/itAtVn5n45ImLJaK+HzN1gZlwrM03fpsrROPP0lsUn0Tm+dlXrZzCiCjkw
fguryc6j9IbzogHUmyTn9lZGy9R+yrqakTtlzZqk+NJUb84xAN80GOMCZ+pR13+ySMJfObdIbtUC
9x7JJPnWoleXsfG4vACbCx35JdcS4VdbfjXq+ovbGbzjvIrDL1LIb5ji2BKyNfymVsJ+bsvUQ0xm
U/8K/VbHwPLboYLDzWcNhce6frudAOr4q3X7gDiJ1WYKzl/tJA9tvxMmD7iToZ224K/VDc7NaljX
VjoCC5+aGdj+WicDHgEmYdIRXGnEwPN22gu/w9imeqZdhoRk2uZWkbYfBtVw1fbStuf5QRguNIqX
CQmwIycvGexVz3TYBJ6n7dUVAQZSdRaw8gMzPi5meNk22HWqcObdKUAEu02koI4x8W6bL9wCay7Q
x5dQHTvGDp18CUZrJ0zCGqH5AFDtdiHK2FpGuC8QhFMRl/PU7YVYhdJDbFqR5q2Llrrgk/WsuBf1
pkb++w3/pU/8z3n6jbf0m9QrEMQLcyoni9PbYcoqfqltVpkjs5kscrnAumZzJfUN7V+IV2X/ciV1
XqB2ok4v3RdUf+dRKsZ4SS4WDMXbF5BMRl4USDRzeoxAyhdpFs5L/ZOI8C82XPDaKcsSzo3r2iHp
z0ZvCn/Kg8DH70v8lu9ycvZyo4qU1NY1o+8usu/uyDGl2YkrvnVVIpdbaA7v6OASyviMqZbnclk6
EkfOcaCO3UaC74Hm3DUAVekJfg8GuGJZcHwwuHy3wZVz7wBHhi8qvvy+rFRShWjvXL7j3vJjfufu
+MlaGDwo7FxZnSjL5xFPVpPw+IZtRt1nypc2qob2tzEa1rD1epEc+JSjvIWmRk91Ja+CX4Oewwor
uYeTLFFUxx5/yyNhHLSHWMrBHYvTprmbWLgQTbKrL+SeTDzxutblBuqF5CnO3E/n40rOSiY1qdmu
FeDlenW1YtBLM1Cn+RSCllk+m1tk2CQEx8KyLpuZtea9IHCs8IZ6MI55r49k53t6OmP6Hk001Eux
+XQ8mUw/FaSs8WYvLbcXe76pwuSUPLbuv5Lv6Xlmk+CWPyW3LT7Iq7q+rct99aY6E+Hq/+wrrRPo
zfVeScvXbWX7qp7+MK9sTcmla16ZWvxW8vRayhtxF2TqBgsFXrdICTzzyvREftlX9bRRfWXRlrL2
lUGcL80rW6IeJBUtWfjvtrinxLQfSkqWukGsbl5Z5C2tlEgJavrK9jewY6glEoDmlR1EO4Zp+/Lu
1rgnTdUtrVJGCCyt9Dn5YV/V0w7oK1uvbscwHdHAjmFKlbodw5SDpDZwdwJWklnAK5WRlPpizrTl
k8NUOCTz3RUtOrVWNG6Aq4PzYd/eNGN3wfRY7fFkNvw90wKP9JkZH3CR36h4DWWwYSIIXWmU9Ve6
LUa80vT6/f+vvWvdbeM6wv0rPcU2gaKltZS4om4WTAVJWhcFitQIjDZF0RK0KCOMJFIhRYtM0efo
c/gV3BfrfHM5l72JSgW0P/YAtpZ77pedOWfmOzND/OZ8MIyi2b2e6K+I/lvoPJLPxtYIuSOs2360
fnZXEj/AGZtIRMPa4O0BYlAAebSpTnhjbaac5Jjscz0y6Wm+E9laOMtePk8t+Wl3EheN7dzxMxV+
gtYHKsFwUpmV0dipBMBG7+Q5qp5kL63WmoJOM0ijHyvnjMuxIX+eYfHzmsMXh2+qGWH5GuCqEIAV
fkCn5OvavkG9aD9W/fZCVqWZdX54eNgn9+/T6zUbdf5p3sXH1b1fEoMkXeqBlNnVSrpqFzra6g7D
mpndCWUyWuQ4jvzyFKTnablSmTxgfj3/QskpCs4dc8gLVFZfecqUe/Zm1uON54T8xFOxqMVSXanJ
jpMp2fXkMveJcs8Ie6XuORYTdY+rs5YVOHyvFzL0nifr8VA4+h8NheOg4UbBVRcwHs/FiuPmuFaZ
DwdsMQ+4szVJm+gGszDILrFyJ78T6ZVGPmSdfuT9psgl57fWO8ew8hLbtmkK2GYwTX7jETbQbzT8
foqrE5b3JxM/nYoAigFKgol8YHSl2GaQs0rVdxsJw9j/QAUbq/jsjHJoVKfgflLcSSbOhcm4KOZX
lVTgBNnc6VVUZgdVFhNbnlW2zoQBasmwK4/jqzysmbCrwwIv0NVUHmkGJ1SaA1rGEBfhGlWgri7C
SCsXpwXvJWa8bAcOQbfWLm5NcQJesxQHSX8Tykw97QS6WjL8FAudfZ/ysC9BB//rPlW2O+5a3O3N
++SOqTCQMmEzX5Nb3nst1W/g7RXxC3iC4NUNdwpiUmoE1RYqohUcyHEDrz/EA4vrWbVh1jZ8GMwr
y4ClaGem67aEqvW+W3kC2NaMjTbniQThA4dp+jGKLyiperGr3g31aA1C+7qPmOP9NyxQCdYjir5U
AY/sEzw64peVMNvah5dO68H2SA+l8noZVs02WVrm5iLRyfCeokhJ6FbOa6j26YD8wPhzt28XUbaT
qBtUHFKq0P8GvWWsQEq46itGybEevP9lR2zzREC4rrnqElChgxeLEvzrt3+GNHx0rWIBvM2cs4wH
CFEeGBwzLkK9VZHLgoA3KiT47orhA9SHJPmGRBETc8Gh+udeL6kMKT7HVYexg4e8nII8eXWedWXq
vKaGFafuF1Pnj7enkCev7UMKZ4YfgEbeg0gQz/1OZZ/yXn29bhT2gl/FNuQNbaguoLodtf0Pq0Y5
e1ZqWA7YOU+/kSqCUk2SL0jnCGVfr/uOfMyM2ZPiZIolrCobkjSlK/Ixue7mjH2+ny+vFGK8y/65
72X9EdHd3TZg0+L6NVUygLl/nPitxnSYDTvGtNngIFg3S/HvYRculEbx9Q05VJN7VgKvs+sAXxQI
vBXFPRYZJsrb3goq9KnWlSlWQZNWO/3KFMWaHk+1c9TN9487L9LVzkn3kJ4ueq6rsztQ0Z8V+gGJ
45J9Z3n0OaneyEX6guhiB+LYgwPKAwgQyGE6JczLH5YjHqRObQNeYED25O+jzdVke5Jr49TxoJvP
0csr4o0EXkkZTMIdyPnHJf3gk5qBS8ymajevTiziVyZ1qgyFl4hMqV6oNWXo8htyoHsLWI4smwl8
ZZ4mKZWOcd7V5bRL8tWVCvSx8HNZ+ER+CYRLdB6AWJRGkHv6bNjRpig4pfbgnhLaWukYm3lbwPm5
vdhOouN0yvUu3+X7GbgvRsQv/nszfpRqThpswjRrNsZzs7g+Z8YqAbLjv0NVYfgikg+TpyayvDdN
vv/2j98JOlI4EoXXlCN51dWmfKkF9TiGRi6xokF63uIPVWYH9q/GYw/h1G1f6pHmi06FEjzePFUK
tVBcWaDFi6Zqy+S2+syob24Cq3fxIeDufj6IKShQH0h8N6Pk8Ovmdv4Dvu3BNWjCh/mEHW/ZktNz
wCISiekhQIsZjifzbI3/BzShNJpweHKPnSVYN+18sGEBnbtnYSC4919kbzADU2a+j2PW9/xyYfZB
mQIb0qentHj0YTS5YcW54PWvbtg3IlptFgnZfCKPCCmqSEcVWlAM36s10dpVzC42eTpoRDvdo7MO
Orbb26WMMCS9m/PTSwYGM1j5ThDIqoTDrws11swqtld6tyrx13CwXICCEJiW9Al9uQdyUxDw3owj
GJvu3FlnxJ1PH9hngQwAr4bl1A8SJwGrw3kA4EF2Q4lCcpkBGXw6KKjL4QUNBL0BJTgw7A425Di8
8ESridL34jIOZdzRx8dJWZck06ROz4kl81XCB2wdDdAvM8SFRb5BuXp2WM4tW94djGGal5kHuitl
ISEOTNgL8ZrbNgWqXlx5YEOty/vFJAI/ZtLtQx6ShezCWceFmXhHdDhQneoqoSXC04V2kRPO+RXv
GnzkA75CIpFTuq1AOdkWIlXMJhqBdVXWjk1ookuO+kJ/6AfrG2Vgu4moITEoGBA98yPyxBbHj0u6
ykHtnxevA27ZcNhwdnNPMPFdSwqJTbprncLI3iqc4Cm2kQc6nnzLqrMfHTXfOuORisA11bQubfNs
t7xFBF8P4098vwAU5ZcCxmITnWJL/ZIv1507DCahib4yOJbdwZtECCz6xVeK6Odsbnnk2hOTIpen
nCo/z8/79C9PeAMCVjS/PmeXfOeFx06ofvS1W0lv5jMYuFSz58gQ1gwHuwAKrW/fzW4C3Cz0LDeM
rB3P5DMdfZhNaF9Kim+nBNbDjuJ6iY7eQUY8lXOY+S0GoeZC52qF1rLsB3uRADVd4lfMTGqNfmsu
5VeOS+lrgpfr06F74nMCWYTtNXA0O9sxil3b5WAXAkYezt4PMZpD+YLFlDSG/Pxpy2KrBN9uDpzh
WzKlGiwhwogc7006xDEv+CwycYC+0YINlw8FYkw5ieqfJ4I4znC99lwkA25vtJCk5b6S1pxU50tc
URsK5TNB3LlTVHl0iReC1JegIpFCGwcgYAZL4RsCgUClwEtDV7xCsGFw17b6vHM/r5vLrbBp0URW
vlZGumUDhJu4I7Vz7OwdB5HYLgR3fKjhxX4O3GD7LjQOVkOkts435H1TarJsfuzr3LJvBVsGe9xr
ym8swoAqja3Og1EoTbVfbprkCQ3/hc2OcN4Qunot4bbDQj3P8l2Vlq9fH9EyfsUltYvk/3CRlAla
eY1gJdG96Ec4u6TbiMJzSi5OedNt8u9/JVOl7/SY3tI5lR+mfGDlMSF51CunHhAj/umq/IpnIy2u
P46zl3t55Wt6STHVqTUCsoSKCi6qK7ioruCirgKK4M4KFtCxdj+5EOj1Ez2gYBDpIvozbKU2nrrN
ZvZ3tNrYsjufgMX3tURpgt8LTpz263RqoCPYD2sv6QYIbkU2JyAo7kFEw2cHWpMCEMc5Q/az7Cfb
uVDHRg9KQrrNJHWwuQA6QSznl1dy088l2XcWTcgty4cJieAJ83hH+0Q2ZfHzinZx+37N7dG5QBfZ
SL/1qrkvRlC+xC+mqtjDxrz9xtijxtjjxnpP4rwp95GkyYVOFrOdxoUWo8+ao182RsOjXvh1YdwJ
3Qxal1fn6ZZGtxh92Bzdb44+kgZ14k+x7z9F7EPZeYHtf9KVLJXBE9eKLJSAHpViDxvz9htjjxpj
jxvrPSnlTbmTWCuDmsUiK6VYahR91hz9sjGaVopGB4tl1bBYZKXUF9m18a2N7jdHH7kGbbhYoh0a
3cR9ygn26XSasxz3kk8f6RAFlnrd2cF5N3yVXjMmjiKIAdPsIpW31UBnBOEsNUeHg4St2JB2GX+K
R9QjnCRYD8+wcF/aC1ajoW0d2O45dGLpYCMTsL1gJK1kJzL+xjTrlSLhO5PgN9xlpuP8bB4d2Un2
+kOS2pVNaAUkZadKNq9qeZgTsQN7pSWRWNQs1hyerNqvkGZTSRXlW98GFfIEyhEppp34oOiarnih
mWUf7PcFqjXJs48Lu/eiXN6W2xXs/ERV1uEVbDq+ngUXy/2FZ3WrYm1OeUI6vHfYbxhyHi6o+mlT
3Tj04aj7zgZACGqFlUDSS/9DxB7ojzSb1D+CGqjLoJLujddEr3zZNmzjU4tjHAwE4pr9VdQ2OzgU
OoAT/egdy+yjl26cypYGCiXEYkqYenPzxffj6SQyJexFApTlmhYKJGUz6hjt0vZprSmGgdUejN+I
BJG/ccvE3QB0gGjeSUNElw74Dj6V3OG1ZjZwrJDfyg1959oIAk51a+RsanniUGkZyfI9k/GEfN++
MrlSIWWQUs1/WsGnuK3aOGrLYnlJVeIO5RyqSzWTpN9ZytcucPXr08f8i08fD/dVvfTBVOwsEsso
+lBfuKseGd+VIdUli9hnS+rQGPtrCDeBUsEmWiFNnaA970kDcjU+F5FRpmPnfOexDm9bbBjZWsWO
/lYNFjCZzhxwip1AYwLVH5sJVe3aScr5IATzt2smMJiGxtEeHiYN2Hgd6UdMaeDoDGkuCbILINEl
wDclai6VpNTmgO7SmyGtrU6l9ZXMr0mmynThO+OuZeyuz0HUtreCtWsAocYc+uUbBOrqkjMNuTnv
JpJGrvDUttfKV/eM/EjWwQoNq0klJi24k1wByo3LZJDXSMahmhwhIXhWwV7NLzXFpcXR4iyYTNmh
T5Hc5TlxaQgHyRJzQKnfu0KndpDp1wMIicXqmlyHGiQ748xMmNHzZ9nnhQkv1234+Jp+6m8aU2L2
6WcE6HXWMN11xsK24Kk8rmDxxVFpJhCg7UyfYceMitFPauqS/YMpPE+3OgElmnJFhA0GwKreZ6UM
o8XlZFJKzm/LidW1bzG1vA6S6zAGvxD5CLbQFmZ9CiskBh5qvvilJa26I175PqvBkWIfXPHaNaWE
JrTmlCIsS/W9gpoYZKrbajbsQq2ueMOp1cQvkVT52EDpaMZoXZ1qP7m8tiWdPdpr9w36H27GR/6z
Cn5azrKf0mngqHQTZ6ZWUgGjUI1csMQbUOfN6XjGlMub/XXPPAaP0syNCCuKqrcg12hejrPWugtu
9CWMrN7PZ+T0M25Qw6HFLZ3SVrh2j0xZ/imUzxO6wholiNmv2tCGNrShDW1oQxva0IY2tKENbWhD
G9rQhja0oQ1taEMb2tCGNrShDW1oQxva0IY2tOF/H/4DY7eqyAC4AQA=
